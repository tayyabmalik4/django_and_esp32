<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <table>
        <thead>
            <tr>
                <th align="center"><img src="{{ public_path('admin/company/images/' . $logo) }}" alt="" width="300"
                        height="100" />
                </th>
                <th align="center" style="font-weight: bold" colspan="2">{{ $companyName }}</th>
                <th align="center" style="font-weight: bold">{{ date('d-m-Y', strtotime($currentDate)) }}</th>
            </tr>

        </thead>
    </table>


    <table>
        <thead>
            <tr>

                <th align="center" style="font-weight: bold">{{ strtoupper($reporttype) }}</th>
                <th colspan="2" align="center" style="font-weight: bold">{{ $report }}</th>
                <th align="center" style="font-weight: bold">{{ strtoupper($area) }}</th>

            </tr>
        </thead>
    </table>


    <table class="table text-center table-bordered">
        <thead id="tableHead">
            <tr id="tableRow">
                <th style="background-color: #0714a0;color:white" align="center">Date</th>
                @if (!$metersName->isEmpty())
                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Steam Flow Meter')
                            <th style="background-color: #0714a0;color:white" align="center">
                                {{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Gas Flow Meter')
                            <th style="background-color: #0714a0;color:white" align="center">
                                {{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Energy Meter')
                            <th style="background-color: #0714a0;color:white" align="center">
                                {{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Water Flow Meter')
                            <th style="background-color: #0714a0;color:white" align="center">
                                {{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Production Meter')
                            <th style="background-color: #0714a0;color:white" align="center">
                                {{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach
                @endif
                <th style="background-color: #0714a0;color:white" align="center">Run Hours</th>
            </tr>
        </thead>
        <tbody>
            @if (!$meters->isEmpty())
                @php
                    $grandSteamTotal = 0;
                    $grandGasTotal = 0;
                    $grandEnergyTotal = 0;
                    $grandWaterTotal = 0;
                    $grandProductionTotal = 0;
                    $totalRunningHours = 0;
                @endphp
                @foreach ($meters as $key => $meter)
                    @php
                        // $count = $meter->count();
                        // dd($count);
                        $steamTotal = 0;
                        $gassTotal = 0;
                        $val = 0;
                    @endphp
                    <tr>
                        <td scope="row" align="center">
                            {{ date('d-m-Y', strtotime($key)) }}
                        </td>



                        @foreach ($metersName as $flowName)
                            @php
                                $steamTotal = 0;
                                $gassTotal = 0;
                                $count = 0;
                            @endphp
                            @if ($flowName->meter_type == 'Steam Flow Meter')
                                @foreach ($meter as $flowMeter)
                                    @if ($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id)

                                        @php
                                            $steamTotal = $steamTotal + floatval($flowMeter->total_consumption);
                                            $val = floatval($flowMeter->total_consumption);
                                        @endphp
                                    @endif

                                @endforeach
                                @php
                                    $grandSteamTotal += $steamTotal - $val;
                                @endphp

                                <td align="center"> {{ number_format($steamTotal - $val, 2) }}
                                </td>
                            @endif
                        @endforeach

                        @foreach ($metersName as $gasName)
                            @php
                                $steamTotal = 0;
                                $gassTotal = 0;
                                $count = 0;
                            @endphp
                            @if ($gasName->meter_type == 'Gas Flow Meter')
                                @foreach ($meter as $gasMeter)
                                    @if ($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                        @php

                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                        @endphp
                                    @endif
                                @endforeach
                                @php
                                    $grandGasTotal += $gassTotal - $val;
                                @endphp
                                {{-- @dd($gassTotal . ' '.$val) --}}
                                <td align="center">{{ number_format($gassTotal - $val) }}</td>
                            @endif
                        @endforeach

                        @foreach ($metersName as $gasName)
                            @php
                                $steamTotal = 0;
                                $gassTotal = 0;
                                $count = 0;
                            @endphp
                            @if ($gasName->meter_type == 'Energy Meter')
                                @foreach ($meter as $gasMeter)
                                    @if ($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                        @php

                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                        @endphp
                                    @endif
                                @endforeach
                                @php
                                    $grandEnergyTotal += $gassTotal - $val;
                                @endphp
                                {{-- @dd($gassTotal . ' '.$val) --}}
                                <td align="center">{{ number_format($gassTotal - $val) }}</td>
                            @endif
                        @endforeach

                        @foreach ($metersName as $gasName)
                            @php
                                $steamTotal = 0;
                                $gassTotal = 0;
                                $count = 0;
                            @endphp
                            @if ($gasName->meter_type == 'Water Flow Meter')
                                @foreach ($meter as $gasMeter)
                                    @if ($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                        @php

                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                        @endphp
                                    @endif
                                @endforeach
                                @php
                                    $grandWaterTotal += $gassTotal - $val;
                                @endphp
                                {{-- @dd($gassTotal . ' '.$val) --}}
                                <td align="center">{{ number_format($gassTotal - $val) }}</td>
                            @endif
                        @endforeach

                        @foreach ($metersName as $gasName)
                            @php
                                $steamTotal = 0;
                                $gassTotal = 0;
                                $count = 0;
                            @endphp
                            @if ($gasName->meter_type == 'Production Meter')
                                @foreach ($meter as $gasMeter)
                                    @if ($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                        @php

                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                        @endphp
                                    @endif
                                @endforeach
                                @php
                                    $grandProductionTotal += $gassTotal - $val;
                                @endphp
                                {{-- @dd($gassTotal . ' '.$val) --}}
                                <td align="center">{{ number_format($gassTotal - $val) }}</td>
                            @endif
                        @endforeach

                        @php
                            $hourCount = 0;
                        @endphp
                        @foreach ($dailyRuningHours as $hour)

                            @if ($hour['date'] == $key)
                                <td align="center">{{ $hour['run_hours'] }}</td>
                                @php
                                    $hourCount = $hourCount + 1;
                                    $totalRunningHours += $hour['run_hours'];
                                @endphp
                            @endif
                        @endforeach
                        @if ($hourCount == 0)
                            <td align="center">0</td>
                        @endif
                    </tr>
                @endforeach
                <tr>
                    <td align="center" style="background-color: #32CD32;color:white">Total</td>
                    @foreach ($metersName as $name)
                        @if ($name->meter_type == 'Steam Flow Meter')
                            @foreach ($totalConsumption as $meter)
                                @if ($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                    <td align="center" style="background-color: #32CD32;color:white">
                                        {{ number_format($grandSteamTotal, 2) }}</td>
                                @endif
                            @endforeach
                        @endif
                    @endforeach

                    @foreach ($metersName as $name)
                        @if ($name->meter_type == 'Gas Flow Meter')
                            @foreach ($totalConsumption as $meter)
                                @if ($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                    <td align="center" style="background-color: #32CD32;color:white">
                                        {{ number_format($grandGasTotal) }}</td>
                                @endif
                            @endforeach
                        @endif
                    @endforeach

                    @foreach ($metersName as $name)
                        @if ($name->meter_type == 'Energy Meter')
                            @foreach ($totalConsumption as $meter)
                                @if ($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id)
                                    <td align="center" style="background-color: #32CD32;color:white">
                                        {{ number_format($grandEnergyTotal) }}</td>
                                @endif
                            @endforeach
                        @endif
                    @endforeach

                    @foreach ($metersName as $name)
                        @if ($name->meter_type == 'Water Flow Meter')
                            @foreach ($totalConsumption as $meter)
                                @if ($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                    <td align="center" style="background-color: #32CD32;color:white">
                                        {{ number_format($grandWaterTotal) }}</td>
                                @endif
                            @endforeach
                        @endif
                    @endforeach

                    @foreach ($metersName as $name)
                        @if ($name->meter_type == 'Production Meter')
                            @foreach ($totalConsumption as $meter)
                                @if ($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id)
                                    <td align="center" style="background-color: #32CD32;color:white">
                                        {{ number_format($grandProductionTotal) }}</td>
                                @endif
                            @endforeach
                        @endif
                    @endforeach
                    <td align="center" style="background-color: #32CD32;color:white">{{ $totalRunningHours }}</td>
                </tr>
            @endif
        </tbody>
    </table>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>
