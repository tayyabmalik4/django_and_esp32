<?php

namespace App\Exports;

use App\Models\User;
use App\Models\Meter;

use App\Models\Machine;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class MultiExport implements FromView, ShouldAutoSize
{
    public function __construct(string $meterId, string $date, string $currentDate, $areaId)
    {
        $this->meterId = $meterId;
        $this->date = $date;
        $this->areaId = $areaId;
        $this->currentDate = $currentDate;

        // dd($this->meters);
    }
    public function view(): View
    {
        // dd('ok');
        if ($this->areaId != 0) {
            $machine = Machine::with(['building'])->where('id', $this->areaId)->first();
            if (Auth::user()->is_admin) {
                $user = User::find($machine->user_id);
                $logo = $user->logo;
                $companyName = $user->name;
            } else {
                $logo = Auth::user()->logo;
                $companyName = Auth::user()->name;
            }
            $building = Machine::find($this->areaId);
            // dd($building);
            $meters = Meter::where('machine_id', $this->areaId)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }

            // dd($meterIds);

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $this->date)->where('machine_id', $this->areaId)->get();

            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d ga');
            });

            $machineStatus = DB::table('meters_view')->whereIn('meter_id', $meterIds)->where('meter_type', 'Machine Status')->whereDate('created_at',  $this->date)->where('machine_id', $this->areaId)->get();

            $machineStatus = $machineStatus->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });

            // dd($machineStatus);
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at', $this->date)->distinct()->get();

            $previousDay = date('d-m-Y g:i:sa', strtotime($this->date) + (24 * 60 * 60 - 1));
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [date('Y-m-d H:i:s', strtotime($this->date)), date('Y-m-d H:i:s', strtotime($previousDay))])->where('machine_id', $this->areaId)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            $totalConsumption = [];
            foreach ($totalMeters as $key => $meterData) {
                $first = $meterData->first();
                $last = $meterData->last();
                // dd(str_replace(',', '', $last->total));
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }
        }
        $count = $totalMeters->count();
        return view('admin.partials.databycurrentdate', [
            'meterid' => $this->meterId,
            'meters' => $meters,
            'metersName' => $metersName,
            'logo' => $logo,
            'currentDate' => $this->date,
            'companyName' => $companyName,
            'totalConsumption' => $totalConsumption,
            'area' => $machine->machine_name,
            'machineStatus' => $machineStatus,
            'count' => $count + 2,
            'reporttype' => 'Hourly Report',
            'report' => "MRS-9000 Metering Reporting System",
        ]);
    }
}
