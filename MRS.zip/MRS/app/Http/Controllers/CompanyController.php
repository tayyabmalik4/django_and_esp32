<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class CompanyController extends Controller
{
    //

    public function index()
    {
        // dd('ok');
        $companies = User::where('is_admin', '!=', 1)->get();
        return view('admin.company.company', compact('companies'));
        dd($companies);
    }

    public function addCompany($id = null)
    {
        // dd($id);
        $company = User::find($id);
        // dd($company);
        return view('admin.company.addcompany', compact('company'));
    }

    public function store(Request $request)
    {
        // dd($request->all());
        if ($request->id) {
            $request->validate([
                'name' => ['required', 'string'],
                'email' => ['required', 'email'],
                'address' => ['required', 'string'],
                'phone' => ['required', 'numeric'],

            ]);

            $company = User::find($request->id);
        } else {
            $request->validate([
                'name' => ['required', 'string'],
                'email' => ['required', 'email'],
                'address' => ['required', 'string'],
                'phone' => ['required', 'numeric'],
                'file' => ['required', 'mimes:jpeg,jpg,png'],
                'password' => ['required', 'min:8']
            ]);

            $alreadyExists = User::where('name', $request->name)->first();
            if (!empty($alreadyExists)) {
                return redirect()->back()->with('error', 'Already Exists');
            }

            $company = new User();
        }

        $company->name = $request->name;
        $company->email = $request->email;
        $company->address = $request->address;
        $company->phone = $request->phone;

        if ($request->file) {
            $avatar = time() . '.' . $request->file->extension();
            $DirectoryName = public_path('admin/company/images');
            $request->file->move($DirectoryName, $avatar);
            $company->logo = $avatar;
        }

        if ($request->password) {
            $company->password = Hash::make($request->password);
        }

        $company->save();

        if ($company && $request->id) {
            return redirect()->back()->with('success', 'Data Upadted Successfully');
        } else {
            return redirect()->back()->with('success', 'Data Added Successfully');
        }

        return redirect()->back()->with('error', 'Something Went Wrong');
    }

    public function delete($id)
    {
        // dd($id);
        $company = User::find($id);
        if (!empty($company)) {
            $company->delete();
            return ['status' => 'success', 'msg' => 'Company Data Deleted Successfully'];
            return redirect()->back()->with('success', 'Data Deleted Successfully');
        }
        return ['status' => 'error', 'msg' => 'Company Data Not Found'];
        return redirect()->back()->with('error', 'Something Went Wrong');
    }
}
