<?php

namespace App\Exports;

use App\Models\Meter;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;

class MultiGraphExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function __construct(int $building_id)
    {
        $this->building_id = $building_id;
    }
    public function collection()
    {
        $meters = Meter::where('building_id', $this->building_id)->get();

        $meterIds = [];
        foreach ($meters as $meter) {
            $meterIds[] = $meter->meter_id;
        }


        $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->where('user_id', Auth::user()->id)->select('meter_type', 'flow', 'total', 'meter_id', 'created_at')->get();

        return $meters;
    }

    public function headings(): array
    {
        return ["Meter Type", "Flow", "Total", "Meter Id", "Date"];
    }
}
