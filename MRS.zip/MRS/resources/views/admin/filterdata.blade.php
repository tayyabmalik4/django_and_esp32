@extends('admin.layouts.master')
@section('title', 'Hourly Report')
@section('css')

@endsection

@section('page-title')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/user/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item">
                @if (!empty($machine))
                    {{ $machine->building->building_area }}
                @endif
            </li>
            <li class="breadcrumb-item active">
                @if (!empty($building))
                    {{ strtoupper($building->machine_name) }}
                @endif
            </li>
        </ol>
    </nav>
@endsection
@section('page-title-action')
    @if (!empty($meterId))
        {{ $meterId }}
    @elseif (!empty($building))
        {{-- <h5>{{ $building->machine_name }}</h5> --}}
    @endif
    {{-- <button class="btn btn-primary" id="newMeter">Add New Meter</button> --}}
@endsection
@section('content')
    <div class="conatiner">
        <div class="container">
            <div class="main-card mb-3 card">
                <div class="card-body" id="dataTable">



                    @if (!$meters->isEmpty())
                        <a href="{{ url()->previous() }}" class="btn btn-danger float-right ml-1 mb-3">Close</a>
                        <a href="/user/printPDFMultiples/{{ $meterId }}/{{ $date }}/{{ $areaId }}"
                            class="btn btn-info float-right ml-1 mb-3" target=”_blank”>Print Pdf</a>
                        <a href="/user/printExcelMultiples/{{ $meterId }}/{{ $date }}/{{ $areaId }}"
                            class="btn btn-primary float-right ml-1 mb-3">Export to
                            Excel</a>
                    @endif
                    <h5 class="card-title">Hourly Report</h5>

                    <table class="table text-center table-bordered">
                        <thead id="tableHead">
                            <tr id="tableRow">
                                <th>Date</th>
                                <th>Time</th>
                                @if (!$metersName->isEmpty())
                                    @foreach ($metersName as $key => $steamMeter)
                                        @if ($steamMeter->meter_type == 'Steam Flow Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }}
                                                <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>

                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Gas Flow Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }}
                                                <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>

                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Energy Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }}
                                                <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>

                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Water Flow Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }}
                                                <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>

                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Production Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }}
                                                <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>

                                        @endif
                                    @endforeach
                                @endif
                                @if (!$machineStatus->isEmpty())
                                    <th> Machine <br> Status</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @if (!$meters->isEmpty())
                                {{-- @dd($meters) --}}
                                @php
                                    $varToal = $meters->count();
                                    $decrement = -1;
                                @endphp
                                @foreach ($meters as $key => $meter)
                                    @php
                                        ++$decrement;
                                    @endphp
                                    @if ($decrement < $varToal)
                                        <tr>
                                            <td scope="row">{{ date('d-m-Y', strtotime($key)) }}
                                            </td>
                                            <td>{{ date('ga', strtotime($key)) }}</td>

                                            @foreach ($metersName as $flowName)
                                                @if ($flowName->meter_type == 'Steam Flow Meter')
                                                    @php
                                                        $i = 0;
                                                    @endphp
                                                    @foreach ($meter as $flowMeter)
                                                        @if ($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id)
                                                            <td>{{ round($flowMeter->total_consumption, 2) }}
                                                            </td>
                                                            @php
                                                                $i = $i + 1;
                                                            @endphp
                                                        @endif
                                                    @endforeach
                                                    @if ($i == 0)
                                                        <td>0</td>
                                                    @endif
                                                @endif
                                            @endforeach

                                            @foreach ($metersName as $gasName)
                                                @if ($gasName->meter_type == 'Gas Flow Meter')
                                                    @php
                                                        $i = 0;
                                                    @endphp
                                                    @foreach ($meter as $gasMeter)
                                                        @if ($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                            <td>{{ $gasMeter->total_consumption }}
                                                            </td>
                                                            @php
                                                                $i = $i + 1;
                                                            @endphp
                                                        @endif
                                                    @endforeach
                                                    @if ($i == 0)
                                                        <td>0</td>
                                                    @endif
                                                @endif
                                            @endforeach

                                            @foreach ($metersName as $gasName)
                                                @if ($gasName->meter_type == 'Energy Meter')
                                                    @php
                                                        $i = 0;
                                                    @endphp
                                                    @foreach ($meter as $gasMeter)
                                                        @if ($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                            <td>{{ $gasMeter->total_consumption }}
                                                            </td>
                                                            @php
                                                                $i = $i + 1;
                                                            @endphp
                                                        @endif
                                                    @endforeach
                                                    @if ($i == 0)
                                                        <td>0</td>
                                                    @endif
                                                @endif
                                            @endforeach

                                            @foreach ($metersName as $gasName)
                                                @if ($gasName->meter_type == 'Water Flow Meter')
                                                    @php
                                                        $i = 0;
                                                    @endphp
                                                    @foreach ($meter as $gasMeter)
                                                        @if ($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                            <td>{{ $gasMeter->total_consumption }}
                                                            </td>
                                                            @php
                                                                $i = $i + 1;
                                                            @endphp
                                                        @endif
                                                    @endforeach
                                                    @if ($i == 0)
                                                        <td>0</td>
                                                    @endif
                                                @endif
                                            @endforeach

                                            @foreach ($metersName as $gasName)
                                                @if ($gasName->meter_type == 'Production Meter')
                                                    @php
                                                        $i = 0;
                                                    @endphp
                                                    @foreach ($meter as $gasMeter)
                                                        @if ($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                            <td>{{ $gasMeter->total_consumption }}
                                                            </td>
                                                            @php
                                                                $i = $i + 1;
                                                            @endphp
                                                        @endif
                                                    @endforeach
                                                    @if ($i == 0)
                                                        <td>0</td>
                                                    @endif
                                                @endif
                                            @endforeach
                                            @if (!$machineStatus->isEmpty())
                                                @php
                                                    $count = 0;
                                                @endphp
                                                @foreach ($machineStatus as $key1 => $status)
                                                    @if (date('ga', strtotime($key)) == date('ga', strtotime($key1)))

                                                        @foreach ($status as $machine)
                                                            <td>{{ $machine->machine_status }}</td>
                                                            @php
                                                                $count = $count + 1;
                                                            @endphp
                                                        @endforeach
                                                    @endif

                                                @endforeach
                                                @if ($count == 0)
                                                    <td>-</td>
                                                @endif
                                            @endif
                                        </tr>
                                    @endif
                                @endforeach
                                @if (!empty($totalConsumption))
                                    <tr>

                                        <td colspan="2" style="background-color: #32CD32;color:white">Total</td>
                                        @foreach ($metersName as $name)
                                            @if ($name->meter_type == 'Steam Flow Meter')
                                                @foreach ($totalConsumption as $meter)
                                                    @if ($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                                        <td style="background-color: #32CD32;color:white">
                                                            {{ number_format($meter['total'], 2) }}</td>
                                                    @endif
                                                @endforeach
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $name)
                                            @if ($name->meter_type == 'Gas Flow Meter')
                                                @foreach ($totalConsumption as $meter)
                                                    @if ($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                                        <td style="background-color: #32CD32;color:white">
                                                            {{ number_format($meter['total']) }}</td>
                                                    @endif
                                                @endforeach
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $name)
                                            @if ($name->meter_type == 'Energy Meter')
                                                @foreach ($totalConsumption as $meter)
                                                    @if ($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id)
                                                        <td style="background-color: #32CD32;color:white">
                                                            {{ number_format($meter['total']) }}</td>
                                                    @endif
                                                @endforeach
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $name)
                                            @if ($name->meter_type == 'Water Flow Meter')
                                                @foreach ($totalConsumption as $meter)
                                                    @if ($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                                        <td style="background-color: #32CD32;color:white">
                                                            {{ number_format($meter['total']) }}</td>
                                                    @endif
                                                @endforeach
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $name)
                                            @if ($name->meter_type == 'Production Meter')
                                                @foreach ($totalConsumption as $meter)
                                                    @if ($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id)
                                                        <td style="background-color: #32CD32;color:white">
                                                            {{ number_format($meter['total']) }}</td>
                                                    @endif
                                                @endforeach
                                            @endif
                                        @endforeach
                                        @if (!$machineStatus->isEmpty())
                                            <td style="background-color: #32CD32;color:white">-</td>
                                        @endif
                                    </tr>
                                @endif
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
