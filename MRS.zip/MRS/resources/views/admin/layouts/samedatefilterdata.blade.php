@extends('admin.layouts.master')
@section('title', 'Daily Report')
@section('css')

@endsection

@section('page-title')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item">
                @if (!empty($machine))
                    {{ $machine->building->building_area }}
                @endif
            </li>
            <li class="breadcrumb-item active">
                @if (!empty($machine))
                    {{ strtoupper($machine->machine_name) }}
                @endif
            </li>
        </ol>
    </nav>
@endsection
@section('page-title-action')
    @if (!empty($meterId))
        <h5> {{ $meterId }}</h5>
    @elseif (!empty($machine))
        {{-- <h5>{{ $machine->machine_name }}</h5> --}}
    @endif
    {{-- <button class="btn btn-primary" id="newMeter">Add New Meter</button> --}}
@endsection
@section('content')
    <div class="conatiner">
        <div class="container">
            <div class="main-card mb-3 card">
                <div class="card-body" id="dataTable">
                    @if (!$meters->isEmpty())
                        <a href="/user/machine-meters/{{ $machine->id }}"
                            class="btn btn-danger float-right ml-1 mb-3">Close</a>
                        <a href="/user/printPDFSingle/{{ $meterId }}/{{ $from }}/{{ $to }}/{{ $machineId }}"
                            class="btn btn-info float-right ml-1 mb-3" target=”_blank”>Print Pdf</a>
                        <a href="/user/printExcelSingle/{{ $meterId }}/{{ $from }}/{{ $to }}/{{ $machineId }}"
                            class="btn btn-primary float-right ml-1 mb-3">Export to
                            Excel</a>
                    @endif
                    <h5 class="card-title">Daily Report</h5>



                    <table class="table text-center table-bordered">
                        <thead id="tableHead">
                            <tr id="tableRow">
                                <th>Date</th>
                                @if (!$metersName->isEmpty())
                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Steam Flow Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }} <br>
                                                {{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Gas Flow Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }} <br>
                                                {{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Energy Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }} <br>
                                                {{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Water Flow Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }} <br>
                                                {{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $steamMeter)
                                        @if ($steamMeter->meter_type == 'Production Meter')
                                            <th>{{ $steamMeter->meter_type }}
                                                <br>{{ $steamMeter->meter_id }} <br>
                                                {{ ' (' . $steamMeter->total_unit . ')' }}
                                            </th>
                                        @endif
                                    @endforeach
                                @endif
                                <th>Run Hours</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!$meters->isEmpty())
                                @php
                                    $grandSteamTotal = 0;
                                    $grandGasTotal = 0;
                                    $grandEnergyTotal = 0;
                                    $grandWaterTotal = 0;
                                    $grandProductionTotal = 0;
                                    $totalRunningHours = 0;
                                @endphp
                                @foreach ($meters as $key => $meter)
                                    @php
                                        $steamTotal = 0;
                                        $gassTotal = 0;
                                        $val = 0;
                                    @endphp
                                    <tr>
                                        <td scope="row"><a
                                                href="/user/current-date-details/{{ $meterId }}/{{ $key }}/{{ $machineId }}">
                                                {{ date('d-m-Y', strtotime($key)) }}</a>
                                        </td>



                                        @foreach ($metersName as $flowName)
                                            @php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            @endphp
                                            @if ($flowName->meter_type == 'Steam Flow Meter')
                                                @foreach ($meter as $flowMeter)
                                                    @if ($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id)

                                                        @php
                                                            $steamTotal = $steamTotal + floatval($flowMeter->total_consumption);
                                                            $val = floatval($flowMeter->total_consumption);
                                                        @endphp
                                                    @endif

                                                @endforeach
                                                @php
                                                    $grandSteamTotal += $steamTotal - $val;
                                                @endphp

                                                <td>{{ number_format($steamTotal - $val, 2) }}
                                                </td>
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $gasName)
                                            @php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            @endphp
                                            @if ($gasName->meter_type == 'Gas Flow Meter')
                                                @foreach ($meter as $gasMeter)
                                                    @if ($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                        @php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        @endphp
                                                    @endif
                                                @endforeach
                                                @php
                                                    $grandGasTotal += $gassTotal - $val;
                                                @endphp
                                                {{-- @dd($gassTotal . ' '.$val) --}}
                                                <td>{{ number_format($gassTotal - $val) }}</td>
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $gasName)
                                            @php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            @endphp
                                            @if ($gasName->meter_type == 'Energy Meter')
                                                @foreach ($meter as $gasMeter)
                                                    @if ($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                        @php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        @endphp
                                                    @endif
                                                @endforeach
                                                @php
                                                    $grandEnergyTotal += $gassTotal - $val;
                                                @endphp
                                                {{-- @dd($gassTotal . ' '.$val) --}}
                                                <td>{{ number_format($gassTotal - $val) }}</td>
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $gasName)
                                            @php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            @endphp
                                            @if ($gasName->meter_type == 'Water Flow Meter')
                                                @foreach ($meter as $gasMeter)
                                                    @if ($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                        @php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        @endphp
                                                    @endif
                                                @endforeach
                                                @php
                                                    $grandWaterTotal += $gassTotal - $val;
                                                @endphp
                                                {{-- @dd($gassTotal . ' '.$val) --}}
                                                <td>{{ number_format($gassTotal - $val) }}</td>
                                            @endif
                                        @endforeach

                                        @foreach ($metersName as $gasName)
                                            @php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            @endphp
                                            @if ($gasName->meter_type == 'Production Meter')
                                                @foreach ($meter as $gasMeter)
                                                    @if ($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                                        @php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        @endphp
                                                    @endif
                                                @endforeach
                                                @php
                                                    $grandProductionTotal += $gassTotal - $val;
                                                @endphp
                                                {{-- @dd($gassTotal . ' '.$val) --}}
                                                <td>{{ number_format($gassTotal - $val) }}</td>
                                            @endif
                                        @endforeach
                                        @php
                                            $hourCount = 0;
                                        @endphp
                                        @foreach ($dailyRuningHours as $hour)

                                            @if ($hour['date'] == $key)
                                                <td>{{ $hour['run_hours'] }}</td>
                                                @php
                                                    $hourCount = $hourCount + 1;
                                                    $totalRunningHours += $hour['run_hours'];
                                                @endphp
                                            @endif
                                        @endforeach
                                        @if ($hourCount == 0)
                                            <td>0</td>
                                        @endif
                                    </tr>
                                @endforeach
                                <tr>
                                    <td style="background-color: #32CD32;color:white">Total</td>
                                    @foreach ($metersName as $name)
                                        @if ($name->meter_type == 'Steam Flow Meter')
                                            @foreach ($totalConsumption as $meter)
                                                @if ($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                                    <td style="background-color: #32CD32;color:white">
                                                        {{ number_format($grandSteamTotal, 2) }}</td>
                                                @endif
                                            @endforeach
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $name)
                                        @if ($name->meter_type == 'Gas Flow Meter')
                                            @foreach ($totalConsumption as $meter)
                                                @if ($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                                    <td style="background-color: #32CD32;color:white">
                                                        {{ number_format($grandGasTotal) }}</td>
                                                @endif
                                            @endforeach
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $name)
                                        @if ($name->meter_type == 'Energy Meter')
                                            @foreach ($totalConsumption as $meter)
                                                @if ($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id)
                                                    <td style="background-color: #32CD32;color:white">
                                                        {{ number_format($grandEnergyTotal) }}</td>
                                                @endif
                                            @endforeach
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $name)
                                        @if ($name->meter_type == 'Water Flow Meter')
                                            @foreach ($totalConsumption as $meter)
                                                @if ($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                                    <td style="background-color: #32CD32;color:white">
                                                        {{ number_format($grandWaterTotal) }}</td>
                                                @endif
                                            @endforeach
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $name)
                                        @if ($name->meter_type == 'Production Meter')
                                            @foreach ($totalConsumption as $meter)
                                                @if ($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id)
                                                    <td style="background-color: #32CD32;color:white">
                                                        {{ number_format($grandProductionTotal) }}</td>
                                                @endif
                                            @endforeach
                                        @endif
                                    @endforeach
                                    <td style="background-color: #32CD32;color:white">{{ $totalRunningHours }}</td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                    {{-- {{ $meters->appends(request()->input())->links() }} --}}
                </div>
            </div>
        </div>
    </div>
@endsection
