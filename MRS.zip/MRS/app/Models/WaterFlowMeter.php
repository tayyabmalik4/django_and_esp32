<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WaterFlowMeter extends Model
{
    use HasFactory;

    protected $table = "water_flow_meters";
}
