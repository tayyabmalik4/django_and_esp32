<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Building extends Model
{
    use HasFactory, SoftDeletes;

    protected $with = ['machines'];
    protected $table = "buildings";
    protected $dates = ['deleted_at'];
    // protected $fillable = ['id', 'building_area', 'user_id'];

    // public function getIdAttribute($key)
    // {
    //     return base64_encode($key);
    // }

    // public function setIdAttribute($key)
    // {
    //     return base64_decode($key);
    // }

    // public function meters()
    // {
    //     return $this->hasMany(Meter::class, 'building_id');
    // }

    public function machines()
    {
        return $this->hasMany(Machine::class);
    }
}
