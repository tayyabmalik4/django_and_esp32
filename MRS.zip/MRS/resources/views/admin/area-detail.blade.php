@extends('admin.layouts.master')

@section('css')

@endsection
@section('page-title')
    <div class="container">
        <img src="{{ asset('admin/images/favicon1.png') }}" alt="" width="110" height="70">
    </div>
@endsection
@section('page-title-action')
    @if (Auth::user()->is_admin)
        <button class="btn btn-primary" id="newMeter">Add New Meter</button>
    @endif

@endsection
@section('content')

    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-xl-4">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left">
                            <div class="widget-heading">Flow</div>
                            <div class="widget-subheading">(Kg/hr)</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-success"><span>
                                    @if (!empty($latestData))
                                        {{ $latestData->flow }}
                                    @else
                                        0
                                    @endif
                                </span></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-xl-4">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left">
                            <div class="widget-heading">Total</div>
                            <div class="widget-subheading">(Ton)</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-success"><span>
                                    @if (!empty($latestData))
                                        {{ $latestData->total }}
                                    @else
                                        0
                                    @endif
                                </span></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-xl-4">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left">
                            <div class="widget-heading">Meter ID</div>
                            <div class="widget-subheading">-</div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-success"><span>
                                    @if (!empty($latestData))
                                        {{ $latestData->meter_id }}
                                    @else
                                        0
                                    @endif
                                </span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-8">
                <div class="mb-3 card">
                    <div class="card-header-tab card-header-tab-animation card-header">
                        <div class="card-header-title">
                            <i class="header-icon lnr-apartment icon-gradient bg-love-kiss"> </i>
                            Daily Report
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="tabs-eg-77">
                                <div class="card mb-3 widget-chart widget-chart2 text-left w-100">
                                    <div class="widget-chat-wrapper-outer">
                                        <div class="widget-chart-wrapper widget-chart-wrapper-lg opacity-10 m-0">
                                            <canvas id="myChart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-4">
                <div class="main-card mb-3 card">
                    <div class="card-body">

                        <h5 class="card-title">Last Updated</h5>
                        <div class="form-group">
                            <label for="" style="font-weight:bold">Time :</label>
                            @if (!empty($latestData))
                                <span>{{ date('g:ia', strtotime($latestData->updated_at)) }}</span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="" style="font-weight:bold">Date :</label>
                            @if (!empty($latestData))
                                <span>{{ $latestData->created_at }}</span>
                            @endif
                        </div>
                        <h5 class="card-title">Reporting</h5>
                        <form action="/admin/search" method="GET">
                            @csrf
                            <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                            <input type="hidden" name="meter_type" id="meter_type" @if (!empty($latestData)) value="{{ $latestData->meter_type }}" @endif>
                            <input type="hidden" name="meter_id" id="meter_id" @if ($meterval) value="{{ $meterval }}" @endif>
                            <div class="form-group">
                                <label for="">From</label>
                                <input type="date" name="from" id="dpd1" class="form-control" placeholder=""
                                    aria-describedby="helpId" required @if (old('from')) value="{{ old('form') }}" @endif>
                            </div>
                            <div class="form-group">
                                <label for="">To <span class="text-danger"><small id="toError"></small>
                                        @if (session()->has('error'))
                                            {{ session()->get('error') }}
                                        @endif
                                    </span></label>
                                <input type="date" name="to" id="dpd2" class="form-control" placeholder=""
                                    aria-describedby="helpId" required @if (old('to')) value="{{ old('to') }}" @endif>
                            </div>
                            <div class="form-group text-center">
                                <button class="btn btn-success" type="submit">Apply Filter</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">

        <div class="main-card mb-3 card">

            <div class="card-body" id="dataTable">
                @if (!$meters->isEmpty())
                    <a href="/admin/steamflowpdf/{{ $meterval }}" class="btn btn-info float-right ml-1 mb-3"
                        target=”_blank”>Print</a>
                    <a href="/admin/steamflow/{{ $meterval }}" class="btn btn-primary float-right ml-1 mb-3">Export to
                        Excel</a>
                @endif
                <h5 class="card-title">Daily Report</h5>
                <table class="mb-1 table text-center table-bordered">
                    <thead id="tableHead">
                        <tr id="tableRow">
                            <th>Flow</th>
                            <th>Total</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        @if (!$meters->isEmpty())
                            @foreach ($meters as $meter)
                                <tr>
                                    <td scope="row">{{ $meter->flow }}</td>
                                    <td>{{ $meter->total }}</td>
                                    <td>{{ date('d-m-Y g:ia', strtotime($meter->updated_at)) }}</td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>

                    <tbody id="responseTableBody">

                    </tbody>
                </table>
            </div>
            <div class="container mb-2" id="pagination">
                {{ $meters->links() }}
            </div>

        </div>
    </div>





@endsection

@section('js')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.2.0/chart.min.js"
        integrity="sha512-VMsZqo0ar06BMtg0tPsdgRADvl0kDHpTbugCBBrL55KmucH6hP9zWdLIWY//OTfMnzz6xWQRxQqsUFefwHuHyg=="
        crossorigin="anonymous"></script>>
    <script>
        //chart

        $(document).ready(function() {
            loadChart();
        });

        function loadChart() {
            //ajax request
            @if (Auth::user())
                var userid={{ Auth::user()->id }}
            @endif
            meter = $('#meter_id').val();

            $.ajax({
                type: "get",
                url: "/api/getChartData/" + userid + '/' + meter,
                dataType: "json",
                success: function(response) {
                    // console.log(response);
                    const labels = response.labels;
                    const dataValues = response.yAxisData;
                    const data = {
                        labels: labels,
                        datasets: [{
                            label: response.toDayDate,
                            data: dataValues,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 205, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(54, 162, 235, 0.2)',
                                'rgba(153, 102, 255, 0.2)',
                                'rgba(201, 203, 207, 0.2)'
                            ],
                            borderColor: [
                                'rgb(255, 99, 132)',
                                'rgb(255, 159, 64)',
                                'rgb(255, 205, 86)',
                                'rgb(75, 192, 192)',
                                'rgb(54, 162, 235)',
                                'rgb(153, 102, 255)',
                                'rgb(201, 203, 207)'
                            ],
                            borderWidth: 1
                        }]
                    };

                    const config = {
                        type: 'line',
                        data: data,
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        },
                    };

                    var myChart = new Chart(
                        document.getElementById('myChart'),
                        config
                    );
                }
            });
        }

        //end chart





        //--------------Getting Table Data on Date Range Ajax------/////
        $('#filters').submit(function(e) {
            e.preventDefault();
            id = $('#area_id').val();
            meter = $('#meter_id').val();
            dateFrom = $('#dpd1').val();
            dateTo = $('#dpd2').val();
            count = 0;
            if (dateTo < dateFrom) {
                count = count + 1;
                $('#toError').html('To Date Can Not Less Than From Date');
            } else {
                $('#toError').html('');
            }
            if (count == 0) {
                $.ajax({
                    type: "get",
                    url: "/admin/area-details/" + id +
                        "/" + meter,
                    data: $('#filters').serialize(),
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                        if (response.status == 'success') {
                            $('#tableBody').hide();
                            $('#pagination').hide();
                            if (response.data.length > 0) {
                                // console.log('ok');
                                $('#toError').html('');
                                dev = '<tr>';
                                response.data.forEach(function(result) {
                                    dev += '<td>' + result.meter_type + '</td><td>' + result
                                        .flow +
                                        '</td><td>' + result.total + '</td><td>' + result.temp +
                                        '</td><td>' + result.pressure + '</td></tr>';
                                })
                                $('#responseTableBody').html(dev);
                            } else {
                                $('#responseTableBody').html('');
                            }
                        } else if (response.status == 'error') {
                            $('#toError').html(response.msg);
                        }
                    }
                });
            }
        });

        //-------------Min DATE OF TO------------
        function setToDate() {
            dateTo = $('#dpd1').val();
            $("#dpd1").attr({
                "min": dateTo
            });
            console.log(dateTo);
        }

    </script>
@endsection
