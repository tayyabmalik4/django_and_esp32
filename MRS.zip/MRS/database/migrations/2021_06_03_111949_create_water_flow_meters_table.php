<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWaterFlowMetersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('water_flow_meters', function (Blueprint $table) {
            $table->id();
            $table->string('meter_type');
            $table->string('meter_id');
            $table->string('flow');
            $table->string('total');
            $table->string('flow_unit');
            $table->string('total_unit');
            $table->string('total_consumption');
            $table->unsignedBigInteger('user_id');
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('water_flow_meters');
    }
}
