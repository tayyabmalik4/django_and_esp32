<table>
    <thead>
        <tr>
            <th align="center"><img src="{{ public_path('admin/company/images/' . $logo) }}" alt="" width="300"
                    height="100" /></th>
            <th align="center" style="font-weight: bold">{{ $companyName }}</th>
            <th align="center" style="font-weight: bold">{{ date('d-m-Y', strtotime($currentDate)) }}</th>
            <th align="center" style="font-weight: bold">{{ strtoupper($reporttype) }}</th>
        </tr>

    </thead>
</table>

<table>
    <thead>
        <tr class="text-center">
            <th colspan="3" align="center" style="font-weight: bold">{{ $report }}</th>
        </tr>
    </thead>
</table>



<table>
    <thead>
        <tr>
            <th style="background-color: #0714a0;color:white" align="center">Date</th>
            {{-- @dd($metersName) --}}
            @if (!$metersName->isEmpty())
                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Steam Flow Meter')
                        <th style="background-color: #0714a0;color:white" align="center">{{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Gas Flow Meter')
                        <th style="background-color: #0714a0;color:white" align="center">{{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Energy Meter')
                        <th style="background-color: #0714a0;color:white" align="center">
                            {{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Water Flow Meter')
                        <th style="background-color: #0714a0;color:white" align="center">
                            {{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Production Meter')
                        <th style="background-color: #0714a0;color:white" align="center">
                            {{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach
            @endif
        </tr>
    </thead>
    <tbody>
        @if (!$meters->isEmpty())
            @foreach ($meters as $key => $meter)
                @php
                    $steamTotal = 0;
                    $gassTotal = 0;
                @endphp
                <tr>
                    <td scope="row" align="center">
                        {{ date('d-m-Y', strtotime($key)) }}
                    </td>
                    @foreach ($metersName as $flowName)
                        @php
                            $steamTotal = 0;
                            $gassTotal = 0;
                        @endphp
                        @if ($flowName->meter_type == 'Steam Flow Meter')

                            @foreach ($meter as $flowMeter)
                                @if ($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id)
                                    @php
                                        $steamTotal += round(str_replace(',', '', $flowMeter->total_consumption));
                                    @endphp


                                @endif
                            @endforeach
                            <td align="center">{{ $steamTotal }}</td>
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @php
                            $steamTotal = 0;
                            $gassTotal = 0;
                        @endphp
                        @if ($gasName->meter_type == 'Gas Flow Meter')

                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    @php
                                        $gassTotal += round(str_replace(',', '', $gasMeter->total_consumption));
                                    @endphp
                                @endif
                            @endforeach
                            <td align="center">{{ $gassTotal }}</td>
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @php
                            $steamTotal = 0;
                            $gassTotal = 0;
                        @endphp
                        @if ($gasName->meter_type == 'Energy Meter')

                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    @php
                                        $gassTotal += round(str_replace(',', '', $gasMeter->total_consumption));
                                    @endphp
                                @endif
                            @endforeach
                            <td align="center">{{ $gassTotal }}</td>
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @php
                            $steamTotal = 0;
                            $gassTotal = 0;
                        @endphp
                        @if ($gasName->meter_type == 'Water Flow Meter')

                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    @php
                                        $gassTotal += round(str_replace(',', '', $gasMeter->total_consumption));
                                    @endphp
                                @endif
                            @endforeach
                            <td align="center">{{ $gassTotal }}</td>
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @php
                            $steamTotal = 0;
                            $gassTotal = 0;
                        @endphp
                        @if ($gasName->meter_type == 'Production Meter')

                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    @php
                                        $gassTotal += round(str_replace(',', '', $gasMeter->total_consumption));
                                    @endphp
                                @endif
                            @endforeach
                            <td align="center">{{ $gassTotal }}</td>
                        @endif
                    @endforeach
                </tr>
            @endforeach
            <tr>
                <td align="center">Total</td>
                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Steam Flow Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Gas Flow Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Energy Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Water Flow Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Production Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach
            </tr>
        @endif
    </tbody>
</table>
