<?php

namespace App\Http\Controllers;

use App\Models\Meter;
use App\Models\Machine;
use App\Models\Building;
use App\Models\GasFlowMeter;
use Illuminate\Http\Request;
use App\Models\MachineStatus;
use App\Models\SteamFlowMeter;
use App\Models\WaterFlowMeter;
use Illuminate\Support\Carbon;
use App\Models\EnergyFlowMeter;
use App\Models\ProductionMeter;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use SebastianBergmann\CodeCoverage\Report\Xml\Totals;

class AreaController extends Controller
{
    public function index($areaId)
    {
        // dd($areaId);
        $building = Building::find($areaId);
        $meters = Meter::where('building_id', $areaId)->where('user_id', Auth::user()->id)->get();

        $meterIds = [];
        foreach ($meters as $meter) {
            $meterIds[] = $meter->meter_id;
        }

        $result = json_encode($meterIds);

        $id = Auth::user()->id;
        $meters = DB::select('select `sm`.`meter_type` AS `meter_type`,format(round(`sm`.`flow`,0),0) AS `flow`,format(round(`sm`.`total`,0),0) AS `total`,`sm`.`meter_id` AS `meter_id`,
        `sm`.`user_id` AS `user_id`,format(round(`sm`.`total_consumption`,0),0) AS `total_consumption`,`sm`.`created_at` AS `created_at`,`sm`.`updated_at`
        AS `updated_at` from `steam_flow_meters` where machine_id IN (' . $areaId . ') )

        union all
        select `gm`.`meter_type` AS `meter_type`,format(round(`gm`.`flow`,0),0)
        AS `flow`,format(round(`gm`.`total`,0),0) AS `total`,`gm`.`meter_id` AS `meter_id`,`gm`.`user_id` AS `user_id`,format(round(`gm`.`total_consumption`,0),0)
        AS `total_consumption`,`gm`.`created_at` AS `created_at`,`gm`.`updated_at` AS `updated_at` from `gas_flow_meters` where machine_id IN (' . $areaId . ') )

        union all
        select `em`.`meter_type` AS `meter_type`,format(round(`em`.`flow`,0),0)
        AS `flow`,format(round(`em`.`total`,0),0) AS `total`,`em`.`meter_id` AS `meter_id`,`em`.`user_id` AS `user_id`,format(round(`em`.`total_consumption`,0),0)
        AS `total_consumption`,`em`.`created_at` AS `created_at`,`em`.`updated_at` AS `updated_at` from `energy_flow_meters` where machine_id IN (' . $areaId . ') )

        union all
        select `wm`.`meter_type` AS `meter_type`,format(round(`wm`.`flow`,0),0)
        AS `flow`,format(round(`wm`.`total`,0),0) AS `total`,`wm`.`meter_id` AS `meter_id`,`wm`.`user_id` AS `user_id`,format(round(`wm`.`total_consumption`,0),0)
        AS `total_consumption`,`wm`.`created_at` AS `created_at`,`wm`.`updated_at` AS `updated_at` from `water_flow_meters` where machine_id IN (' . $areaId . ') )

        union all
        select `pm`.`meter_type` AS `meter_type`,format(round(`pm`.`flow`,0),0)
        AS `flow`,format(round(`pm`.`total`,0),0) AS `total`,`pm`.`meter_id` AS `meter_id`,`pm`.`user_id` AS `user_id`,format(round(`pm`.`total_consumption`,0),0)
        AS `total_consumption`,`pm`.`created_at` AS `created_at`,`pm`.`updated_at` AS `updated_at` from `production_meters` where machine_id IN (' . $areaId . ') )
        ');
        dd($meters);
        $meters1 = json_encode($meters);

        // dd($meters);

        return view('admin.area', compact('meters', 'meters1', 'meterIds', 'result', 'areaId', 'building'));
    }

    public function store(Request $request)
    {
        // dd($request->all());
        if (empty($request->name)) {
            return json_encode(['status' => 'error', 'msg' => 'Area/Building Name Required']);
        }

        $alraedyExist = Building::where("building_area", $request->name)->where('user_id', $request->id)->first();
        if (!empty($alraedyExist)) {
            return json_encode(['status' => 'error', 'msg' => 'Data Alraedy Exist']);
        }

        $buidling = new Building();
        $buidling->building_area = $request->name;
        $buidling->user_id = $request->companyId;
        $buidling->save();
        if (!empty($buidling)) {
            return json_encode(['status' => 'success', 'msg' => 'Data Added Successfully']);
        }
        // return json_encode(['status' => 'error', 'msg' => 'Area/Buildin']);
    }

    public function getdata(Request $request)
    {
        // dd($request->id);
        $data = Building::where('user_id', $request->id)->get();
        // $data = $data->groupBy(function ($result) {
        //     return $result->building_area;
        // });

        // dd($data);
        return json_encode(['status' => 'success', 'data' => $data]);
    }

    public function details($id)
    {
        // dd($meter);
        // if ($request->from && $request->to) {
        //     if ($request->to < $request->from) {
        //         return json_encode(['status' => 'error', 'msg' => ['To Date Can Not Less Than From Date']]);
        //     }
        //     // dd('ok');
        //     $meters = SteamFlowMeter::whereBetween('created_at', [date("Y-m-d H:i:s", strtotime($request->from)), date("Y-m-d H:i:s", strtotime($request->to))])->where('user_id', $request->user_id)->get();
        //     // dd($meters);
        //     if ($meters->isEmpty()) {
        //         $meters = GasFlowMeter::whereBetween('created_at', [date("Y-m-d H:i:s", strtotime($request->from)), date("Y-m-d H:i:s", strtotime($request->to))])->where('user_id', $request->user_id)->get();
        //     }
        //     return json_encode(['status' => 'success', 'data' => $meters]);
        // } else {
        //     $meters = SteamFlowMeter::orderBy('created_at', 'desc')->where('meter_id', $meter)->where('user_id', Auth::user()->id)->paginate(24);
        //     if ($meters->isEmpty()) {
        //         // dd('ok');
        //         $meters = GasFlowMeter::orderBy('created_at', 'desc')->where('meter_id', $meter)->where('user_id', Auth::user()->id)->paginate(24);
        //     }
        // }
        // // dd($meters);

        // $area = Building::find($id);

        // $latestData = SteamFlowMeter::where('meter_id', $meter)->where('user_id', Auth::user()->id)->latest()->first();

        // if (empty($latestData)) {
        //     $latestData = GasFlowMeter::where('meter_id', $meter)->where('user_id', Auth::user()->id)->latest()->first();
        // }
        // // dd($latestData);
        // $meterval = $meter;
        // dd($meter);
        $machine = Machine::with(['building'])->where('id', $id)->first();
        // dd($machine->building);
        $meters = Meter::where('machine_id', $id)->get();
        // dd($meters);
        $meterIds = [];
        foreach ($meters as $meter) {
            $meterIds[] = $meter->meter_id;
        }

        $result = json_encode($meterIds);

        $meters = DB::select('select `sm`.`meter_type` AS `meter_type`,format(round(`sm`.`flow`,0),0) AS `flow`,format(round(`sm`.`total`,0),0) AS `total`,`sm`.`meter_id` AS `meter_id`,
        `sm`.`user_id` AS `user_id`,format(round(`sm`.`total_consumption`,0),0) AS `total_consumption`,`sm`.`created_at` AS `created_at`,`sm`.`updated_at`
         AS `updated_at` from `steam_flow_meters` `sm` union all select `gm`.`meter_type` AS `meter_type`,format(round(`gm`.`flow`,0),0)
         AS `flow`,format(round(`gm`.`total`,0),0) AS `total`,`gm`.`meter_id` AS `meter_id`,`gm`.`user_id` AS `user_id`,format(round(`gm`.`total_consumption`,0),0)
         AS `total_consumption`,`gm`.`created_at` AS `created_at`,`gm`.`updated_at` AS `updated_at` from `gas_flow_meters` `gm`');
        // dd($meters);
        $meters1 = json_encode($meters);
        $userId = Auth::user()->id;
        // return view('admin.area-detail', compact('area', 'meters', 'latestData', 'meterval'));
        return view('company.forntendlayouts.machinemeters', compact('machine', 'meters', 'meters1', 'id', 'userId'));
    }

    public function addMeter(Request $request)
    {
        // dd($request->all());
        $alraedyExist = SteamFlowMeter::where('meter_id', $request->id)->first();
        if (empty($alraedyExist)) {
            $alraedyExist = GasFlowMeter::where('meter_id', $request->id)->first();
        }

        if (empty($alraedyExist)) {
            $alraedyExist = EnergyFlowMeter::where('meter_id', $request->id)->first();
        }
        if (empty($alraedyExist)) {
            $alraedyExist = WaterFlowMeter::where('meter_id', $request->id)->first();
        }
        if (empty($alraedyExist)) {
            $alraedyExist = ProductionMeter::where('meter_id', $request->id)->first();
        }
        if (empty($alraedyExist)) {
            $alraedyExist = MachineStatus::where('meter_id', $request->id)->first();
        }
        // dd($alraedyExist);
        // $alraedyExist = DB::table('meters_view')->where('meter_id', $request->id)->first();
        if (!empty($alraedyExist)) {
            // dd('ok');
            $machine = Machine::find($request->machineId);
            $alraedyExist = Meter::where('meter_id', $request->id)->first();
            // dd($alraedyExist);
            if (!empty($alraedyExist)) {
                return json_encode(['status' => 'error', 'msg' => 'Data Already Exist']);
            }
            $meter = new Meter();
            $meter->meter_id = $request->id;
            $meter->meter_name = $request->name;
            $meter->user_id = $machine->user_id;
            $meter->building_id = $machine->building_id;
            $meter->machine_id = $machine->id;
            $meter->save();

            if (!empty($meter)) {
                return json_encode(['status' => 'success', 'msg' => 'Data Added Successfully']);
            }
        } else {
            return json_encode(['status' => 'error', 'msg' => 'No Record Found']);
        }
    }

    public function editMeter(Request $request)
    {
        // dd($request->all());
        $alraedyExist = DB::table('meters_view')->where('meter_id', $request->id)->first();
        // dd($alraedyExist);
        if (!empty($alraedyExist)) {
            $meter = Meter::find($request->meterId);
            $meter->meter_id = $request->id;
            $meter->meter_name = $request->name;

            $meter->save();

            if (!empty($meter)) {
                return json_encode(['status' => 'success', 'msg' => 'Data Updated Successfully']);
            }
        } else {
            return json_encode(['status' => 'error', 'msg' => 'No Record Found']);
        }
    }

    public function deleteMeter($id)
    {
        // dd($id);
        $meter = Meter::find($id);
        if (!empty($meter)) {
            $meter->delete();
            return json_encode(['status' => 'success', 'msg' => 'Data Updated Successfully']);
        }

        return json_encode(['status' => 'error', 'msg' => 'Something Went Wrong']);
    }

    public function chartData($id = null, $meter = null)
    {
        $toDayDate = Carbon::now();
        $toDayDate = $toDayDate->toFormattedDateString();
        $today = date("Y-m-d H:i:s");
        $previous = date('Y-m-d H:i:s', strtotime('-1 day', strtotime($today)));
        // dd($previous);
        // $data = SteamFlowMeter::where('meter_id', $meter)->where('user_id', $id)->whereBetween('created_at', [$previous, $today])->get();
        // if ($data->isEmpty()) {
        //     $data = GasFlowMeter::where('meter_id', $meter)->where('user_id', $id)->whereBetween('created_at', [$previous, $today])->get();
        // }
        // dd($meter)
        $data = DB::table('meters_view')->where('meter_id', $meter)->where('user_id', $id)->whereBetween('created_at', [$previous, $today])->get();
        // dd($data);
        $labels = [];
        $yAxisData = [];
        foreach ($data as $result) {
            $labels[] = date('d-m ga', strtotime($result->updated_at));
            if ($result->meter_type == "Steam Flow Meter") {
                $yAxisData[] = number_format($result->total_consumption, 2);
            } else {
                $yAxisData[] = number_format((int)$result->total_consumption);
            }
        }

        return json_encode(['labels' => $labels, 'yAxisData' => $yAxisData, 'toDayDate' => $toDayDate]);
        // dd($labels);
        dd($yAxisData);
    }

    public function search(Request $request)
    {
        // dd('ok');
        // dd($request->all());
        $meterId = $request->meter_id;
        $from = $request->from;
        $to = $request->to;

        if ($request->to < $request->from) {
            return redirect()->back()->withInput()->with('error', '(To Date Can Not Less Than From Date)');
        }
        if ($request->meter_id) {
            $machineId = 0;
            $meterIds = [];
            if ($request->from == $request->to) {
                $meters = DB::table('meters_view')->whereDate('created_at', $request->from)->where('meter_id', $meterId)->where('user_id', Auth::user()->id)->get()->groupBy(function ($date) {
                    return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
                });
                $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->where('meter_id', $request->meter_id)->where('user_id', Auth::user()->id)->whereDate('created_at', $request->from)->distinct()->get();

                // dd($meters);
                return view('admin.layouts.samedatefilterdata', compact('meters', 'meterId', 'from', 'to', 'machineId', 'meterIds', 'metersName'));
            }

            $end = date('Y-m-d', strtotime('+1 day', strtotime($to)));

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->where('meter_id', $request->meter_id)->where('user_id', Auth::user()->id)->whereBetween('created_at', [$request->from, $end])->get();
            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d');
            });
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->where('meter_id', $request->meter_id)->where('user_id', Auth::user()->id)->whereBetween('created_at', [$request->from, $end])->distinct()->get();


            return view('admin.layouts.samedatefilterdata', compact('meters', 'meterId', 'from', 'to', 'machineId', 'meterIds', 'metersName'));
        } else {
            // dd('ok');
            $machineId = $request->areaID;
            $machine = Machine::with(['building'])->where('id', $request->areaID)->first();
            $meters = Meter::where('machine_id', $request->areaID)->get();
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }

            if ($request->from == $request->to) {
                $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereDate('created_at', date('Y-m-d H:i:s', strtotime($request->from)))->whereIn('meter_id', $meterIds)->where('machine_id', $request->areaID)->get();
                $meters = $meters->groupBy(function ($date) {
                    return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
                });

                $dailyRuningHours = [];
                foreach ($meters as $key => $meter) {

                    $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                    // dd($status->count());
                    if (!$status->isEmpty()) {
                        $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                    }
                }
                $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at',  $request->from)->distinct()->get();


                $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereDate('created_at',  $request->from)->whereIn('meter_id', $meterIds)->where('machine_id', $request->areaID)->get();

                $totalMeters = $totalMeters->groupBy(function ($data) {
                    return $data->meter_id;
                });

                $totalConsumption = [];
                foreach ($totalMeters as $meter) {
                    $first = $meter->first();
                    $last = $meter->last();
                    if ($first->meter_type != "Machine Status") {
                        $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => round(str_replace(',', '', $last->total) - str_replace(',', '', $first->total), 2)];
                    }
                }
                $meterId = 0;
                return view('admin.layouts.samedatefilterdata', compact('meters', 'meterId', 'from', 'to', 'machineId', 'meterIds', 'machine',   'metersName', 'totalConsumption', 'dailyRuningHours'));
            }


            $end = date('Y-m-d', strtotime('+1 day', strtotime($to)));

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereBetween('created_at', [$request->from, $end])->whereIn('meter_id', $meterIds)->get();

            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereBetween('created_at', [$request->from, $end])->whereIn('meter_id', $meterIds)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });

            $totalConsumption = [];
            foreach ($totalMeters as $meter) {
                $first = $meter->first();
                $last = $meter->last();
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }

            // dd($totalMeters);
            // foreach ($totalMeters as $key => $m) {
            //     dd($m);
            // }

            $meters = $meters->groupBy(function ($date) {
                return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
            });
            $dailyRuningHours = [];
            foreach ($meters as $key => $meter) {

                $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                // dd($status->count());
                if (!$status->isEmpty()) {
                    $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                }
            }
            // dd($meters);

            // dd($totalMeters);

            // dd($totalConsumption);
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [$request->from, $end])->distinct()->get();
            // dd($meters);
            $meterId = 0;

            // dd($metersName);
            return view('admin.layouts.samedatefilterdata', compact('meters', 'meterId', 'from', 'to', 'machineId', 'meterIds', 'machine',  'metersName', 'totalConsumption', 'dailyRuningHours'));
        }
    }

    public function currentDateDetails($meterId, $date, $areaId)
    {
        if ($areaId != 0) {
            $building = Machine::with(['building'])->where('id', $areaId)->first();
            $machine = Machine::with(['building'])->where('id', $areaId)->first();
            // dd($building);
            $meters = Meter::where('machine_id', $areaId)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }

            // dd($meterIds);

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $date)->get();

            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });

            // dd($meters);

            $machineStatus = DB::table('meters_view')->whereIn('meter_id', $meterIds)->whereDate('created_at', $date)->where('meter_type', 'Machine Status')->where('machine_id', $areaId)->get();

            $machineStatus = $machineStatus->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });

            // dd($machineStatus);

            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at', $date)->distinct()->get();
            // dd($meters);

            $previousDay = date('d-m-Y g:i:sa', strtotime($date) + (24 * 60 * 60 - 1));
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [date('Y-m-d H:i:s', strtotime($date)), date('Y-m-d H:i:s', strtotime($previousDay))])->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            $totalConsumption = [];
            foreach ($totalMeters as $key => $meterData) {
                $first = $meterData->first();
                $last = $meterData->last();
                // dd(str_replace(',', '', $last->total));
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }
            // dd($totalConsumption);

            return view('admin.filterdata', compact('meters', 'meterId', 'date', 'areaId', 'meterIds', 'building', 'metersName', 'machine', 'totalConsumption', 'machineStatus'));
        }

        $meters = DB::table('meters_view')->whereDate('created_at', $date)->where('meter_id', $meterId)->where('user_id', Auth::user()->id)->get();
        $meters = $meters->groupBy(function ($data) {
            return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d g:ia');
        });

        $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->where('meter_id', $meterId)->whereDate('created_at', $date)->where('user_id', Auth::user()->id)->distinct()->get();
        // dd($metersName);
        $building = null;

        return view('admin.filterdata', compact('meters', 'meterId', 'date', 'areaId', 'building', 'metersName', 'machine'));
        dd($meters);
    }

    public function addMachine(Request $request)
    {
        // dd($request->all());
        if (empty($request->name)) {
            return ['status' => 'error', 'msg' => 'Machine Name Required'];
        }
        $alraedyExist = Machine::where('machine_name', $request->name)->where('user_id', $request->userId)->where('building_id', $request->areaId)->first();

        if (!empty($alraedyExist)) {
            return ['status' => 'error', 'msg' => 'Machine Already Exists'];
        }

        $machine = new Machine();
        $machine->machine_name = $request->name;
        $machine->user_id = $request->userId;
        $machine->building_id = $request->areaId;
        $machine->save();

        if (!empty($machine)) {
            return ['status' => 'success', 'msg' => 'Data Added Successfully'];
        }
        return ['status' => 'error', 'msg' => 'Something Went Wrong'];
    }

    public function updateMachine(Request $request)
    {
        // dd($request->all());
        if (empty($request->name)) {
            return ['status' => 'error', 'msg' => 'Machine Name Required'];
        }
        $alraedyExist = Machine::where('id', $request->machineId)->where('machine_name', $request->name)->first();

        if (!empty($alraedyExist)) {
            return ['status' => 'error', 'msg' => 'Already Exists'];
        }

        $machine = Machine::find($request->machineId);
        $machine->machine_name = $request->name;
        $machine->save();

        return ['status' => 'success', 'msg' => 'Data Updated Successfully'];
    }

    public function editArea(Request $request)
    {
        // dd($request->all());
        if (empty($request->name)) {
            return ['status' => 'error', 'msg' => 'Area Name Required'];
        }

        $building = Building::find($request->areaId);
        $building->building_area = $request->name;
        $building->save();

        return ['status' => 'success', 'msg' => 'Data Updated Successfully'];
    }

    public function deleteArea($id)
    {
        // dd($id);
        $exists = Building::find($id);
        if (!empty($exists)) {
            $exists->delete();
            return ['status' => 'success', 'msg' => 'Data Deleted Successfully'];
        }

        return ['status' => 'error', 'msg' => 'Data Not Found'];
    }

    public function deleteMachine($id)
    {
        $exists = Machine::find($id);
        if (!empty($exists)) {
            $exists->delete();
            return ['status' => 'success', 'msg' => 'Data Deleted Successfully'];
        }

        return ['status' => 'error', 'msg' => 'Data Not Found'];
    }
}
