<?php

namespace App\Exports;

use App\Models\User;
use App\Models\Meter;
use App\Models\Machine;

use App\Models\MachineStatus;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class SingleExport implements FromView, ShouldAutoSize
{

    public function __construct(string $meterId, string $from, string $to, string $date, string $areaId)
    {
        $this->meterId = $meterId;
        $this->from = $from;
        $this->to = $to;
        $this->currentDate = $date;
        $this->areaId = $areaId;
        // dd($this->excelArray);
        if ($this->meterId != 0) {
            if ($this->from == $this->to) {
                $this->meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereDate('created_at', $this->from)->where('meter_id', $this->meterId)->get();

                $this->meters = $this->meters->groupBy(function ($data) {
                    return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d');
                });
                $this->metersName = DB::table('meters_view')->select('meter_type', 'meter_id')->where('meter_id', $meterId)->whereDate('created_at', $from)->distinct()->get();
            } else {
                $this->meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereBetween('created_at', [$this->from, $this->to])->where('meter_id', $this->meterId)->get();

                $this->meters = $this->meters->groupBy(function ($data) {
                    return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d');
                });
                $this->metersName = DB::table('meters_view')->select('meter_type', 'meter_id')->where('meter_id', $meterId)->whereBetween('created_at', [$from, $to])->distinct()->get();
            }
        }
        $this->machine = Machine::with(['building'])->where('id', $this->areaId)->first();
        if (Auth::user()->is_admin) {
            $user = User::find($this->machine->user_id);
            $this->logo = $user->logo;
            $this->companyName = $user->name;
        } else {
            $this->logo = Auth::user()->logo;
            $this->companyName = Auth::user()->name;
        }
        $meters = Meter::where('machine_id', $this->areaId)->get();
        // dd($meters);

        $this->meterIds = [];
        foreach ($meters as $meter) {
            $this->meterIds[] = $meter->meter_id;
        }

        if ($this->from == $this->to) {
            $this->meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereDate('created_at', $this->from)->whereIn('meter_id', $this->meterIds)->where('machine_id', $this->areaId)->get();

            $this->meters = $this->meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d');
            });

            // dd($this->meterIds);

            $this->dailyRuningHours = [];
            foreach ($this->meters as $key => $meter) {

                $this->status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $this->meterIds)->where('status', 'ON')->get();

                // dd($status->count());
                if (!$this->status->isEmpty()) {
                    $this->dailyRuningHours[] = ['date' => $key, 'run_hours' => $this->status->count()];
                }
            }

            // dd($this->dailyRuningHours);

            $this->metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $this->meterIds)->whereDate('created_at', $from)->distinct()->get();


            $this->totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereDate('created_at', $this->from)->whereIn('meter_id', $this->meterIds)->where('machine_id', $this->areaId)->get();

            $this->totalMeters = $this->totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });

            $this->totalConsumption = [];
            foreach ($this->totalMeters as $meter) {
                $first = $meter->first();
                $last = $meter->last();
                if ($first->meter_type != "Machine Status") {
                    $this->totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }
        } else {
            $this->end = date('Y-m-d', strtotime('+1 day', strtotime($to)));
            // dd($this->meterIds);
            $this->meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereBetween('created_at', [$this->from, $this->end])->whereIn('meter_id', $this->meterIds)->where('machine_id', $this->areaId)->get();



            $this->meters = $this->meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d');
            });

            $this->dailyRuningHours = [];
            foreach ($this->meters as $key => $meter) {

                $this->status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $this->meterIds)->where('status', 'ON')->get();

                // dd($status->count());
                if (!$this->status->isEmpty()) {
                    $this->dailyRuningHours[] = ['date' => $key, 'run_hours' => $this->status->count()];
                }
            }

            $this->totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereBetween('created_at', [$this->from, $this->end])->whereIn('meter_id', $this->meterIds)->where('machine_id', $this->areaId)->get();

            $this->totalMeters = $this->totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            // dd($this->totalMeters);
            $this->totalConsumption = [];
            foreach ($this->totalMeters as $meter) {
                // dd($meter);
                $first = $meter->first();
                // dd($first);
                $last = $meter->last();
                if ($first->meter_type != "Machine Status") {
                    $this->totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }



            // dd($this->totalConsumption);

            $this->metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $this->meterIds)->whereBetween('created_at', [$from, $this->end])->distinct()->get();
        }

        // dd($this->metersName);

        $this->count = $this->totalMeters->count();


        // dd($this->metersName);
    }
    public function view(): View
    {

        // dd($this->meterIds);
        // dd($this->meters);
        // dd($this->dailyRuningHours);
        return view('admin.partials.databydates', [
            'meters' =>  $this->meters,
            'metersName' => $this->metersName,
            'meterName' => $this->meterId,
            'logo' => $this->logo,
            'currentDate' => $this->currentDate,
            'companyName' => $this->companyName,
            'totalConsumption' => $this->totalConsumption,
            'area' => $this->machine->machine_name,
            'count' => $this->count + 2,
            'dailyRuningHours' => $this->dailyRuningHours,
            'reporttype' => 'Daily Report',
            'report' => 'MRS-9000 Metering Reporting System',
        ]);
    }
}
