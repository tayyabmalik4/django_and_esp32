<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-left">
                <ul class="nav">
                    {{-- <li class="nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            Designed and developed by Hunch Automation Pvt Ltd
                        </a>
                    </li> --}}
                    {{-- <li class="nav-item">
                        <a href="javascript:void(0);" class="nav-link">
                            Footer Link 2
                        </a>
                    </li> --}}
                </ul>
            </div>
            <div class="app-footer-right">
                <ul class="nav">
                    <li class="nav-item">
                        {{-- <a href="javascript:void(0);" class="nav-link">
                            Footer Link 3
                        </a> --}}
                    </li>
                    <li class="nav-item" style="font-size: smaller">
                        <a href="https://hunch.com.pk" target="blank" class="nav-link">
                            Designed & Developed By HUNCH Automation Private Limited <span class="ml-2"><img
                                    src="{{ asset('admin/images/favicon.png') }}" alt="" width="40"
                                    height="20"></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
