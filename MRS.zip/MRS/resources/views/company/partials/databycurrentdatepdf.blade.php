<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        body {
            /* background-color: #000 */
        }

        .padding {
            padding: 2rem !important
        }

        .card {
            margin-bottom: 30px;
            border: none;
            -webkit-box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22);
            -moz-box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22);
            box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22)
        }

        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e6e6f2
        }

        h3 {
            font-size: 20px
        }

        h5 {
            font-size: 15px;
            line-height: 26px;
            color: #3d405c;
            margin: 0px 0px 15px 0px;
            font-family: 'Circular Std Medium'
        }

        .text-dark {
            color: #3d405c !important
        }

        table.table-bordered {
            border: 1px solid #0714a0;
            margin-top: 20px;
        }

        table.table-bordered>thead>tr>th {
            border: 1px solid #0714a0;
            padding: 0px;
        }

        table.table-bordered>tbody>tr>td {
            border: 1px solid #7FFF00;
            padding: 0px;
        }


        #tableHead {
            background-color: #0714a0;
        }

        #tableRow {
            color: white;
        }

        #tableFooter {
            background-color: #7CFC00;
        }

        .particulars {
            background-color: #32CD32;
            color: white;
            font-weight: bold;
        }

        #report {
            border-style: none;
            color: #0714a0;
            font-size: medium;
            font-weight: bold;
        }

        img {
            height: 120px !important;
        }

    </style>
</head>

<body>

    <table width="100%">
        <tr>
            <td><img src="{{ public_path('admin/images/favicon1.png') }}" alt="" /></td>
            <td>
                <h3> {{ $meterid }}</h3>
            </td>
            <td style="text-align: right !important;">
                {{ date('d-m-Y', strtotime($date)) }}
            </td>
        </tr>
    </table>

    <div class="container-fluid">
        <div class="card-body">

            <div class="table-responsive-sm" style="margin-top: 30px">
                <table class="table text-center table-bordered">
                    <thead id="tableHead">
                        <tr id="tableRow">
                            <th>Date</th>
                            <th>Time</th>
                            @if (!$metersName->isEmpty())
                                @foreach ($metersName as $steamMeter)
                                    @if ($steamMeter->meter_type == 'Steam Flow Meter')
                                        <th>{{ $steamMeter->meter_type }}
                                            <br>{{ $steamMeter->meter_id }} (Ton)
                                        </th>
                                    @endif
                                @endforeach

                                @foreach ($metersName as $steamMeter)
                                    @if ($steamMeter->meter_type == 'Gas Flow Meter')
                                        <th>{{ $steamMeter->meter_type }}
                                            <br>{{ $steamMeter->meter_id }} (Ton)
                                        </th>
                                    @endif
                                @endforeach
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @if (!$meters->isEmpty())
                            @foreach ($meters as $key => $meter)
                                <tr>
                                    <td scope="row">{{ date('d-m-Y', strtotime($key)) }}
                                    </td>
                                    <td>{{ date('g:ia', strtotime($key)) }}</td>

                                    @foreach ($metersName as $flowName)
                                        @if ($flowName->meter_type == 'Steam Flow Meter')
                                            @php
                                                $i = 0;
                                            @endphp
                                            @foreach ($meter as $flowMeter)
                                                @if ($flowMeter->meter_type == 'Steam Flow Meter')
                                                    <td>{{ round($flowMeter->total_consumption) }}
                                                    </td>
                                                    @php
                                                        $i = $i + 1;
                                                    @endphp
                                                @endif
                                            @endforeach
                                            @if ($i == 0)
                                                <td>0</td>
                                            @endif
                                        @endif
                                    @endforeach

                                    @foreach ($metersName as $gasName)
                                        @if ($gasName->meter_type == 'Gas Flow Meter')
                                            @php
                                                $i = 0;
                                            @endphp
                                            @foreach ($meter as $gasMeter)
                                                @if ($gasMeter->meter_type == 'Gas Flow Meter')
                                                    <td>{{ round($gasMeter->total_consumption) }}
                                                    </td>
                                                    @php
                                                        $i = $i + 1;
                                                    @endphp
                                                @endif
                                            @endforeach
                                            @if ($i == 0)
                                                <td>0</td>
                                            @endif
                                        @endif
                                    @endforeach
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>

        </div>

    </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>
