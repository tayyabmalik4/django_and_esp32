<div class="app-sidebar sidebar-shadow">
    <div class="app-header__logo">
        <div class="logo-src"></div>
        <div class="header__pane ml-auto">
            <div>
                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic"
                    data-class="closed-sidebar">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <div class="app-header__mobile-menu">
        <div>
            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
    </div>
    <div class="app-header__menu">
        <span>
            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                <span class="btn-icon-wrapper">
                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                </span>
            </button>
        </span>
    </div>
    <div class="scrollbar-sidebar">
        <div class="app-sidebar__inner">
            <ul class="vertical-nav-menu">

                <?php if(Auth::user()->is_admin): ?>
                    <li>
                        <a href="/admin/dashboard" <?php if(request()->is('admin/dashboard')): ?> class="mm-active" <?php endif; ?>>
                            <i class="metismenu-icon pe-7s-rocket"></i>
                            Dashboard
                        </a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="/user/dashboard" <?php if(request()->is('user/dashboard')): ?> class="mm-active" <?php endif; ?>>
                            <i class="metismenu-icon pe-7s-rocket"></i>
                            Dashboard
                        </a>
                    </li>
                <?php endif; ?>



                <?php if(Auth::user()->is_admin): ?>
                    <li class="app-sidebar__heading">Management</li>
                    <li><a href="/admin/companies"> <i class="metismenu-icon pe-7s-diamond"></i>Company</a></li>
                <?php else: ?>
                    <li class="app-sidebar__heading">Area/Building</li>
                <?php endif; ?>

                
                <?php
                    $areas = sideBarBuildings();
                    // dd($areas);
                ?>

                <?php if(!$areas->isEmpty()): ?>
                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <li>
                            <a href="#">
                                <i class="metismenu-icon pe-7s-diamond"></i>
                                <?php echo e($area->building_area); ?>

                                <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                            </a>
                            <?php if($area->machines): ?>
                                <ul>
                                    <?php $__currentLoopData = $area->machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li>
                                            <a href="/user/machine-meters/<?php echo e($machine->id); ?>">
                                                <i class="metismenu-icon"></i>
                                                <?php echo e(strtoupper($machine->machine_name)); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <li>
                    <a href="#" onclick="logout()">

                        Sign Out
                    </a>
                </li>
                



            </ul>
        </div>
    </div>
</div>

<script>
    function logout() {
        // console.log("ok");
        Swal.fire({
            title: 'Are you sure?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sign Out'
        }).then((result) => {
            if (result.isConfirmed) {
                console.log('logour');
                window.location.href = "/logout";
            }
        })
    }

</script>
<?php /**PATH C:\xampp\htdocs\Hunch_machines\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>