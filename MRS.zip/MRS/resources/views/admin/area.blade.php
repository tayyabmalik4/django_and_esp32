@extends('admin.layouts.master')

@section('css')

@endsection

@section('page-title')
    <div class="container">
        <img src="{{ asset('admin/images/favicon1.png') }}" alt="" width="110" height="70">
    </div>
@endsection

@section('page-title-action')
    @if (!empty($building))
        <h5>{{ $building->building_area }}</h5>
    @endif
@endsection

@section('content')

    <input type="hidden" id="meter1" @if ($result) value="{{ $result }}" @endif>
    <input type="hidden" id="meter2" @if ($meters1) value="{{ $meters1 }}" @endif>
    {{-- -------------Table----------- --}}
    <div class="container mt-2">
        <div class="card">
            <div class="card-body">
                @php
                    $i = 0;
                @endphp
                <div class="text-center text-primary">
                    <h6>ENERGY & PRODUCTION COST ANALYSIS WITH REPORTING</h6>
                </div>
                <div class="text-center text-danger">
                    @if (session()->has('error'))
                        <p> {{ session()->get('error') }}</p>
                    @endif
                </div>
                <form action="/admin/search" method="GET">
                    @csrf
                    <input type="hidden" name="areaID" @if ($areaId) value="{{ $areaId }}" @endif>

                    @php
                        $meterIds = json_decode($result);
                    @endphp

                    <label for=""> <span> <select name="meter_id" id="" class="form-control" hidden>
                                <option value="" selected>Select Meter (optional)</option>
                                @foreach ($meterIds as $meterId)
                                    <option value="{{ $meterId }}" @if (old('meter_id') && old('meter_id') == $meterId) selected="selected" @endif>
                                        {{ $meterId }}
                                    </option>
                                @endforeach
                            </select></span></label>
                    <table class="table text-center table-bordered">
                        <thead id="tableHead">
                            <tr id="tableRow">
                                <th colspan="2">REPORTING</th>
                                <th>PARTICULARS</th>
                                @if (!empty($meters))
                                    @foreach ($meters as $meter)
                                        <th> {{ $meter->meter_type . ' ' . $meter->meter_id }}</th>
                                    @endforeach
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="particulars" style="border:1px solid #32CD32">FROM:</td>
                                <td><input type="date" name="from" id="dpd1" class="form-control" placeholder=""
                                        aria-describedby="helpId" required @if (old('from')) value="{{ old('from') }}" @endif></td>
                                <td class="particulars" scope="row" style="border:1px solid #32CD32">Flow
                                </td>
                                @if (!empty($meters))
                                    @foreach ($meters as $meter)
                                        <td>{{ round($meter->flow, 0) }}</td>
                                    @endforeach
                                @endif
                            </tr>
                            <tr>
                                <td class="particulars" style="border:1px solid #32CD32">TO:</td>
                                <td> <input type="date" name="to" id="dpd2" class="form-control" placeholder=""
                                        aria-describedby="helpId" required @if (old('to')) value="{{ old('to') }}" @endif></td>
                                <td class="particulars" scope="row" style="border:1px solid #32CD32">Total</td>
                                @if ($meters)
                                    @foreach ($meters as $meter)
                                        <td>{{ round($meter->total, 0) }}</td>
                                    @endforeach
                                @endif
                            </tr>
                            <tr>
                                <td colspan="2"> <button class="btn mt-2" type="submit" id="report">REPORT</button>
                                </td>
                                <td class="particulars" scope="row" style="border:1px solid #32CD32">Updated</td>

                                @if ($meters)
                                    @foreach ($meters as $meter)
                                        <td>{{ date('d-m-Y g:ia', strtotime($meter->updated_at)) }}</td>
                                    @endforeach
                                @endif
                            </tr>
                        </tbody>
                    </table>
                </form>

            </div>


        </div>
    </div>

    {{-- ------Multi Graphs ------- --}}
    <div class="container mt-3">
        <div class="row" id="graphs">


        </div>
    </div>



@endsection


@section('js')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.2.0/chart.min.js"
        integrity="sha512-VMsZqo0ar06BMtg0tPsdgRADvl0kDHpTbugCBBrL55KmucH6hP9zWdLIWY//OTfMnzz6xWQRxQqsUFefwHuHyg=="
        crossorigin="anonymous"></script>
    <script>
        //chart

        $(document).ready(function() {
            loadchart();
        });

        function loadchart() {
            meters = JSON.parse($('#meter1').val());
            meters2 = JSON.parse($('#meter2').val());
            console.log(meters2);
            meters2.forEach(function(data) {
                @if (Auth::user())
                    var userid={{ Auth::user()->id }}
                @endif
                var chartId = data.meter_id;
                $.ajax({
                    type: "get",
                    url: "/api/getChartData/" + userid + '/' + data.meter_id,
                    data: "data",
                    dataType: "json",
                    success: function(response) {
                        // console.log(response);
                        var dev = '';
                        dev +=
                            '<div class="col-md-12 col-lg-12"> <div class = "mb-3 card"><div class="card-header-tab card-header-tab-animation card-header"><div class="card-header-title"><i class="header-icon lnr-apartment icon-gradient bg-love-kiss"></i>' +
                            data.meter_type + ' (' +
                            chartId +
                            ')</div></div><div class="card-body"><div class="tab-content"><div class="tab-pane fade show active" id="tabs-eg-77"><div class="card mb-3 widget-chart widget-chart2 text-left w-100"><div class="widget-chat-wrapper-outer"><div class="widget-chart-wrapper widget-chart-wrapper-lg opacity-10 m-0"><canvas id="' +
                            chartId + '" ></canvas></div></div></div></div></div ></div></div></div>';

                        // console.log(response);
                        $('#graphs').append(dev);
                        setChartValue(chartId, response);
                    }
                });
            })
        }

        function setChartValue(chartId, response) {
            // console.log(response);
            const labels = response.labels;
            const dataValues = response.yAxisData;
            const data = {
                labels: labels,
                datasets: [{
                    label: response.toDayDate,
                    data: dataValues,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                    ],
                    borderWidth: 1
                }]
            };

            const config = {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            stacked: true,
                            beginAtZero: true
                        }
                    }
                },
            };
            new Chart(
                document.getElementById(chartId),
                config
            );
        }

    </script>>
@endsection
