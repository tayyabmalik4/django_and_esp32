@extends('admin.layouts.master')
@section('title', 'Dashboard')
@section('css')

@endsection
@section('page-title')
    <div class="container">
        Dashboard
    </div>
@endsection
@section('page-title-action')


@endsection

@section('content')

    <div class="container">
        @if (!$areas->isEmpty())
            @foreach ($areas as $key => $area)
                <div class="container">
                    <h5 class="">{{ $key }} @if (Auth::user()->is_admin)
                            <button class="btn btn-primary float-right mr-3" id="myBtn">Add New Area</button>
                        @endif
                    </h5>
                </div>
                <br>
                <div class="row">
                    @foreach ($area as $building)
                        @foreach ($building->buildings as $data)
                            {{-- @dd($data); --}}
                            <div class="col-md-6">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <h5 class="card-title">{{ $data->building_area }}</h5>
                                        <div id="exampleAccordion{{ $data->id }}" data-children=".item">

                                            <div class="item">
                                                <button type="button" aria-expanded="false"
                                                    aria-controls="exampleAccordion{{ $data->id }}"
                                                    data-toggle="collapse" href="#collapse-{{ $data->id }}"
                                                    class="m-0 p-0 btn btn-link">Machines</button>
                                                <div data-parent="#exampleAccordion{{ $data->id }}"
                                                    id="collapse-{{ $data->id }}" class="collapse">
                                                    @if (!$data->machines->isEmpty())
                                                        <div class="row">
                                                            @foreach ($data->machines as $machine)
                                                                <div class="col-md-4">
                                                                    <p class="mb-3 mt-3"><a
                                                                            href="/user/machine-meters/{{ $machine->id }}"
                                                                            class="mb-2 mr-2 badge badge-focus">{{ $machine->machine_name }}</a>
                                                                    </p>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    @else
                                                        <div class="row">
                                                            <div class="col-md-8">
                                                                <p class="mb-3 mt-3">No Data Available
                                                                </p>
                                                            </div>

                                                        </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @endforeach
                </div>
            @endforeach
        @endif
    </div>

    <!---------------- Add New Area ----------->
    <div id="myModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close">&times;</span>
            <h5 class="text-primary mt-2 pb-4">Add New Area</h5>
            <form action="" method="get" id="addnewarea">
                <div class="form-group">
                    <label for="">Area/Building Name <span class="text-danger"><small id="areaerror"></small></span></label>
                    <input type="hidden" value="{{ Auth::user()->id }}" id="id" name="id">
                    <input type="text" name="name" id="name" class="form-control" placeholder="Area/Building"
                        aria-describedby="helpId" required>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </div>
    </div>


    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="mb-0">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                        unknown printer took a galley of type and scrambled.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>


    {{-- ---------- Add new Meter ----------------- --}}
    <div id="meterModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close1">&times;</span>
            <h5 class="text-primary mt-2 pb-4">Add New Meter</h5>
            <form action="" method="get" id="addNewMeter">
                <div class="form-group">
                    <input type="hidden" value="{{ Auth::user()->id }}" id="id" name="id">
                    <input type="hidden" name="building_id" id="building_id">
                    <label for="">Meter ID <span class="text-danger"><small id="mettererror"></small></span></label>

                    <input type="text" name="name" id="name" class="form-control" placeholder="Meter ID"
                        aria-describedby="helpId" required>
                </div>
                <button type="submit" class="btn btn-primary ">Add</button>
            </form>
        </div>
    </div>

@endsection

@section('js')
    <script>
        $(document).ready(function() {
            @if (Auth::user())
                var id={{ Auth::user()->id }}
                // console.log(id);
                getChartData(id);
            @endif

        });
        // Get the modal
        var modal = document.getElementById("myModal");

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks the button, open the modal
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            $('#name').val('');
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                $('#name').val('');
                modal.style.display = "none";
            }
        }

        function getChartData(id) {
            dev = '';
            $.ajax({
                type: "get",
                url: "/api/all-areas",
                data: {
                    id: id
                },
                dataType: "json",
                success: function(response) {
                    // console.log(response);
                    if (response.status == 'success') {
                        console.log(response.data);
                        @if (Auth::user())
                            var is_admin={{ Auth::user()->is_admin }}
                            // console.log(id);
                            // getChartData(id);
                        @endif
                        response.data.forEach(function(areas) {
                            if (is_admin == 1) {

                                dev +=
                                    '<div class="col-md-3"><div class="main-card mb-3 card"><div class="card-body"><a href="/admin/area/' +
                                    areas.id +
                                    '"><h5 class = "card-title">Area/Building Name</h5><p>' +
                                    areas.building_area +
                                    '</p></a><button  id="" class="btn newMeter btn-secondary float-right" onClick="addNewMeter(' +
                                    areas.id + ')">Add Meter</button></div></div></div>';
                            } else {
                                dev +=
                                    '<div class="col-md-3"><div class="main-card mb-3 card"><div class="card-body"><a href="/admin/area/' +
                                    areas.id +
                                    '"><h5 class = "card-title">Area/Building Name</h5><p>' +
                                    areas.building_area +
                                    '</p></a></div></div></div>';
                            }

                        });
                        $('#areaData').html(dev);
                    }
                }
            });
        }

        function addNewMeter(id) {
            // console.log(id);

            // $('#exampleModal').show();
            // Get the modal
            var modal1 = document.getElementById("meterModal");
            modal1.style.display = "block";
            $('#building_id').val(id);
            // Get the button that opens the modal
            //var btn1 = document.getElementsByClassName("newMeter");

            // Get the <span> element that closes the modal
            var span1 = document.getElementsByClassName("close1")[0];

            // When the user clicks the button, open the modal
            // btn1.onclick = function() {
            //     modal1.style.display = "block";
            // }

            // When the user clicks on <span> (x), close the modal
            span1.onclick = function() {
                $('#name').val('');
                $('#building_id').val('');
                modal1.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal1) {
                    $('#name').val('');
                    $('#building_id').val('');
                    modal1.style.display = "none";
                }
            }
        }

        $("#addnewarea").submit(function(e) {
            e.preventDefault();
            $('#areaerror').html('');
            $.ajax({
                type: "get",
                url: "/api/add-new-area",
                data: $('#addnewarea').serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status == 'error') {
                        $('#areaerror').html(response.msg);
                    } else if (response.status == 'success') {

                        toastr.success(response.msg);
                        @if (Auth::user())
                            var id={{ Auth::user()->id }}
                            // console.log(id);
                            // getData(id);
                        @endif
                        location.reload();
                        modal.style.display = "none";
                        $('#addnewarea')[0].reset();
                    }
                }
            });

        });

        $('#addNewMeter').submit(function(e) {
            e.preventDefault();
            $('#areaerror').html('');
            $.ajax({
                type: "get",
                url: "/api/add-meter",
                data: $('#addNewMeter').serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status == 'success') {
                        toastr.success(response.msg);
                        modal.style.display = "none";
                        $('#addNewMeter')[0].reset();
                        location.reload();
                    } else if (response.status == 'error') {
                        $('#mettererror').html(response.msg);
                    }
                }
            });

        });

    </script>

@endsection
