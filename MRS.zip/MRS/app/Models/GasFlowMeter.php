<?php

namespace App\Models;

use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class GasFlowMeter extends Model
{
    use HasFactory;

    protected $table = "gas_flow_meters";

    public function getCreatedAtAttribute($key)
    {
        return Carbon::parse($key)->format('d-m-Y');
    }
}
