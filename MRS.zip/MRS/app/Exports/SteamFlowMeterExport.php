<?php

namespace App\Exports;

use App\Models\GasFlowMeter;
use App\SteamFlowMeter;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;
use App\Models\SteamFlowMeter as ModelsSteamFlowMeter;

class SteamFlowMeterExport implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */

    public function __construct(string $meter)
    {
        $this->meter = $meter;
    }
    public function collection()
    {
        $data = ModelsSteamFlowMeter::where('meter_id', $this->meter)->where('user_id', Auth::user()->id)->select('flow', 'total',  'created_at')->get();
        if ($data->isEmpty()) {
            $data = GasFlowMeter::where('meter_id', $this->meter)->where('user_id', Auth::user()->id)->select('flow', 'total',  'created_at')->get();
        }
        return $data;
        // return SteamFlowMeter::all();
    }

    public function headings(): array
    {
        return ["Flow", "Total",  "Date"];
    }
}
