<table>
    <thead>
        <tr>
            <th><img src="{{ public_path('admin/images/favicon1.png') }}" alt="" /></th>
            <th>{{ $meterName }}</th>
            <th>{{ date('d-m-Y', strtotime($currentDate)) }}</th>
        </tr>

    </thead>
</table>


<table>
    <thead>
        <tr>
            <th>Date/Time</th>
            <th>Flow</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($meters as $meter)
            <tr>
                <td>{{ $meter['date'] }}</td>
                <td>{{ $meter['flow'] }}</td>
                <td>{{ $meter['total'] }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
