<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEnergyFlowMetersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('energy_flow_meters', function (Blueprint $table) {
            $table->id();
            $table->string('meter_type');
            $table->string('meter_id');
            $table->string('total');
            $table->string('flow');
            $table->string('current');
            $table->string('voltage');
            $table->string('total_unit');
            $table->string('flow_unit');
            $table->string('voltage_unit');
            $table->string('current_unit');
            $table->string('total_consumption');
            $table->string('status');
            $table->unsignedBigInteger('user_id');
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('energy_flow_meters');
    }
}
