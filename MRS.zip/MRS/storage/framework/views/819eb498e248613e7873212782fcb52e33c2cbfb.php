<?php $__env->startSection('title', 'Daily Report'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item">
                <?php if(!empty($machine)): ?>
                    <?php echo e($machine->building->building_area); ?>

                <?php endif; ?>
            </li>
            <li class="breadcrumb-item active">
                <?php if(!empty($machine)): ?>
                    <?php echo e(strtoupper($machine->machine_name)); ?>

                <?php endif; ?>
            </li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title-action'); ?>
    <?php if(!empty($meterId)): ?>
        <h5> <?php echo e($meterId); ?></h5>
    <?php elseif(!empty($machine)): ?>
        
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="conatiner">
        <div class="container">
            <div class="main-card mb-3 card">
                <div class="card-body" id="dataTable">
                    <?php if(!$meters->isEmpty()): ?>
                        <a href="/user/machine-meters/<?php echo e($machine->id); ?>"
                            class="btn btn-danger float-right ml-1 mb-3">Close</a>
                        <a href="/user/printPDFSingle/<?php echo e($meterId); ?>/<?php echo e($from); ?>/<?php echo e($to); ?>/<?php echo e($machineId); ?>"
                            class="btn btn-info float-right ml-1 mb-3" target=”_blank”>Print Pdf</a>
                        <a href="/user/printExcelSingle/<?php echo e($meterId); ?>/<?php echo e($from); ?>/<?php echo e($to); ?>/<?php echo e($machineId); ?>"
                            class="btn btn-primary float-right ml-1 mb-3">Export to
                            Excel</a>
                    <?php endif; ?>
                    <h5 class="card-title">Daily Report</h5>



                    <table class="table text-center table-bordered">
                        <thead id="tableHead">
                            <tr id="tableRow">
                                <th>Date</th>
                                <?php if(!$metersName->isEmpty()): ?>
                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Steam Flow Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?> <br>
                                                <?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Gas Flow Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?> <br>
                                                <?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Energy Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?> <br>
                                                <?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Water Flow Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?> <br>
                                                <?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Production Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?> <br>
                                                <?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <th>Run Hours</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!$meters->isEmpty()): ?>
                                <?php
                                    $grandSteamTotal = 0;
                                    $grandGasTotal = 0;
                                    $grandEnergyTotal = 0;
                                    $grandWaterTotal = 0;
                                    $grandProductionTotal = 0;
                                    $totalRunningHours = 0;
                                ?>
                                <?php $__currentLoopData = $meters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $steamTotal = 0;
                                        $gassTotal = 0;
                                        $val = 0;
                                    ?>
                                    <tr>
                                        <td scope="row"><a
                                                href="/user/current-date-details/<?php echo e($meterId); ?>/<?php echo e($key); ?>/<?php echo e($machineId); ?>">
                                                <?php echo e(date('d-m-Y', strtotime($key))); ?></a>
                                        </td>



                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flowName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            ?>
                                            <?php if($flowName->meter_type == 'Steam Flow Meter'): ?>
                                                <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flowMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id): ?>

                                                        <?php
                                                            $steamTotal = $steamTotal + floatval($flowMeter->total_consumption);
                                                            $val = floatval($flowMeter->total_consumption);
                                                        ?>
                                                    <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $grandSteamTotal += $steamTotal - $val;
                                                ?>

                                                <td><?php echo e(number_format($steamTotal - $val, 2)); ?>

                                                </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            ?>
                                            <?php if($gasName->meter_type == 'Gas Flow Meter'): ?>
                                                <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                        <?php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $grandGasTotal += $gassTotal - $val;
                                                ?>
                                                
                                                <td><?php echo e(number_format($gassTotal - $val)); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            ?>
                                            <?php if($gasName->meter_type == 'Energy Meter'): ?>
                                                <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                        <?php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $grandEnergyTotal += $gassTotal - $val;
                                                ?>
                                                
                                                <td><?php echo e(number_format($gassTotal - $val)); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            ?>
                                            <?php if($gasName->meter_type == 'Water Flow Meter'): ?>
                                                <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                        <?php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $grandWaterTotal += $gassTotal - $val;
                                                ?>
                                                
                                                <td><?php echo e(number_format($gassTotal - $val)); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $steamTotal = 0;
                                                $gassTotal = 0;
                                                $count = 0;
                                            ?>
                                            <?php if($gasName->meter_type == 'Production Meter'): ?>
                                                <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                        <?php

                                                            $gassTotal += str_replace(',', '', $gasMeter->total_consumption);
                                                            $val = str_replace(',', '', $gasMeter->total_consumption);

                                                        ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $grandProductionTotal += $gassTotal - $val;
                                                ?>
                                                
                                                <td><?php echo e(number_format($gassTotal - $val)); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $hourCount = 0;
                                        ?>
                                        <?php $__currentLoopData = $dailyRuningHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php if($hour['date'] == $key): ?>
                                                <td><?php echo e($hour['run_hours']); ?></td>
                                                <?php
                                                    $hourCount = $hourCount + 1;
                                                    $totalRunningHours += $hour['run_hours'];
                                                ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($hourCount == 0): ?>
                                            <td>0</td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="background-color: #32CD32;color:white">Total</td>
                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($name->meter_type == 'Steam Flow Meter'): ?>
                                            <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                    <td style="background-color: #32CD32;color:white">
                                                        <?php echo e(number_format($grandSteamTotal, 2)); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($name->meter_type == 'Gas Flow Meter'): ?>
                                            <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                    <td style="background-color: #32CD32;color:white">
                                                        <?php echo e(number_format($grandGasTotal)); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($name->meter_type == 'Energy Meter'): ?>
                                            <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                    <td style="background-color: #32CD32;color:white">
                                                        <?php echo e(number_format($grandEnergyTotal)); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($name->meter_type == 'Water Flow Meter'): ?>
                                            <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                    <td style="background-color: #32CD32;color:white">
                                                        <?php echo e(number_format($grandWaterTotal)); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($name->meter_type == 'Production Meter'): ?>
                                            <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                    <td style="background-color: #32CD32;color:white">
                                                        <?php echo e(number_format($grandProductionTotal)); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td style="background-color: #32CD32;color:white"><?php echo e($totalRunningHours); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hunch_machines\resources\views/admin/layouts/samedatefilterdata.blade.php ENDPATH**/ ?>