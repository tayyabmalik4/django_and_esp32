<?php

namespace App\Exports;

use Carbon\Carbon;
use App\Models\User;
use Dotenv\Util\Str;
use App\Models\Meter;
use App\Models\Machine;
use App\Models\MachineStatus;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\FromView;
use Symfony\Component\VarDumper\Cloner\Data;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class dataByDates implements FromView, ShouldAutoSize
{
    public function __construct(string $meterid, string $from, string $to, string $areaid)
    {
        $this->meterid = $meterid;
        $this->from = $from;
        $this->to = $to;
        $this->areaId = $areaid;
    }
    public function view(): View
    {
        if ($this->areaId != 0) {
            $currentDate = Carbon::now();
            $machine = Machine::with(['building'])->where('id', $this->areaId)->first();
            if (Auth::user()->is_admin) {
                $user = User::find($machine->user_id);
                $logo = $user->logo;
                $companyName = $user->name;
            } else {
                $logo = Auth::user()->logo;
                $companyName = Auth::user()->name;
            }
            $meters = Meter::where('machine_id', $this->areaId)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }
            if ($this->from == $this->to) {
                $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereDate('created_at',  $this->from)->whereIn('meter_id', $meterIds)->where('machine_id', $this->areaId)->get();
                $meters = $meters->groupBy(function ($date) {
                    return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
                });


                $dailyRuningHours = [];
                foreach ($meters as $key => $meter) {

                    $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                    // dd($status->count());
                    if (!$status->isEmpty()) {
                        $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                    }
                }


                $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at',  $this->from)->distinct()->get();

                $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereDate('created_at',  $this->from)->whereIn('meter_id', $meterIds)->where('machine_id', $this->areaId)->get();

                $totalMeters = $totalMeters->groupBy(function ($data) {
                    return $data->meter_id;
                });

                $totalConsumption = [];
                foreach ($totalMeters as $meter) {
                    $first = $meter->first();
                    $last = $meter->last();
                    if ($first->meter_type != "Machine Status") {
                        $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                    }
                }

                // dd($metersName);
                $meterId = 0;
            }
            $end = date('Y-m-d', strtotime('+1 day', strtotime($this->to)));


            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereBetween('created_at', [$this->from, $end])->whereIn('meter_id', $meterIds)->where('machine_id', $this->areaId)->get();
            $meters = $meters->groupBy(function ($date) {
                return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
            });

            $dailyRuningHours = [];
            foreach ($meters as $key => $meter) {

                $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                // dd($status->count());
                if (!$status->isEmpty()) {
                    $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                }
            }
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [$this->from, $end])->distinct()->get();
            // dd($metersName);
            $meterId = 0;
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereBetween('created_at', [$this->from, $end])->whereIn('meter_id', $meterIds)->where('machine_id', $this->areaId)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });

            $totalConsumption = [];
            foreach ($totalMeters as $meter) {
                $first = $meter->first();
                $last = $meter->last();
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }
        }
        $count = $totalMeters->count();
        // dd($count);
        // dd($logo);
        return view('admin.partials.databydates', [
            'meters' => $meters,
            'metersName' => $metersName,
            'logo' => $logo,
            'currentDate' => $currentDate,
            'companyName' => $companyName,
            'totalConsumption' => $totalConsumption,
            'dailyRuningHours' => $dailyRuningHours,
            'count' => $count + 2,
            'reporttype' => 'Daily Report',
            'area' => $machine->machine_name,
            'report' => "MRS-9000 Metering Reporting System",
        ]);
    }
}
