<?php

use App\Models\Building;

if (!function_exists("sideBarBuildings")) {

    function sideBarBuildings()
    {
        $data = Building::with('machines')->where('user_id', auth()->user()->id)->get();
        // dd($data);
        return $data;
    }
}
