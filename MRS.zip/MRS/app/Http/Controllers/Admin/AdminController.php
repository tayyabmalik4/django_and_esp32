<?php

namespace App\Http\Controllers\Admin;

use App\Models\Meter;
use App\Models\Machine;
use App\Models\GasFlowMeter;
use Illuminate\Http\Request;
use App\Models\SteamFlowMeter;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\MachineStatus;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{

    public function metters($id)
    {
        // dd($id);
        $machine = Machine::with(['building'])->where('id', $id)->first();
        // dd($machine->building->building_area);
        $meters = Meter::where('machine_id', $id)->get();
        // dd($meters);
        $allmeters = $meters;
        $meterIds = [];
        foreach ($meters as $meter) {
            $meterIds[] = $meter->meter_id;
        }

        $result = json_encode($meterIds);

        $meters = DB::table('recent_meters')->where('machine_id', $id)->where('user_id', $machine->user_id)->orderBy('meter_type', 'desc')->get();


        // dd($metersStatus);
        $meters1 = json_encode($meters);
        $userId = $machine->building->user_id;
        $currentDate = date('m/d/Y');
        $meterStatus = MachineStatus::whereIn('meter_id', $meterIds)->orderBy('meter_type', 'desc')->latest()->first();
        // dd($meterStatus);

        return view('admin.adminside.machinemeters', compact('machine', 'meters', 'meters1', 'id', 'userId', 'allmeters', 'currentDate', 'meterStatus'));
        dd($meters);
    }

    public function search(Request $request)
    {
        $meterId = $request->meter_id;
        $from = $request->from;
        $to = $request->to;

        if ($request->to < $request->from) {
            return redirect()->back()->withInput()->with('error', '(To Date Can Not Less Than From Date)');
        }

        $machineId = $request->areaID;
        $machine = Machine::with(['building'])->where('id', $request->areaID)->first();
        $meters = Meter::where('machine_id', $request->areaID)->get();
        $meterIds = [];
        foreach ($meters as $meter) {
            $meterIds[] = $meter->meter_id;
        }

        // dd($meterIds);

        if ($request->from == $request->to) {
            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereDate('created_at', date('Y-m-d H:i:s', strtotime($request->from)))->where('machine_id',  $request->areaID)->whereIn('meter_id', $meterIds)->get();
            // dd($meters);
            $meters = $meters->groupBy(function ($date) {
                return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
            });

            $dailyRuningHours = [];
            foreach ($meters as $key => $meter) {

                $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                // dd($status->count());
                if (!$status->isEmpty()) {
                    $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                }
            }
            // dd($meters);
            // dd($meterIds);
            // dd($dailyRuningHours);

            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at',  $request->from)->distinct()->get();

            // foreach ($meters as $meter) {
            //     // dd($meter);

            //     // dd($meter);
            //     $total = 0;
            //     $count = 0;
            //     foreach ($meter as $m1) {
            //         if ($m1->meter_type == "Water Flow Meter") {
            //             $count++;
            //             $total = $total + str_replace(',', '', $m1->total_consumption);
            //             $steamMeters[] = ['meter_type' => $m1->meter_type, 'total' => $m1->total, 'date' => $m1->created_at, 'consumption' => str_replace(',', '', $m1->total_consumption)];
            //         }
            //     }
            // }
            // dd($count);
            // dd($steamMeters);


            // dd($metersName);
            $meterId = 0;

            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereDate('created_at',  $request->from)->whereIn('meter_id', $meterIds)->where('machine_id',  $request->areaID)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            // dd($totalMeters);
            $totalConsumption = [];
            foreach ($totalMeters as $meter) {

                // dd($meter);
                $first = $meter->first();
                $last = $meter->last();
                if ($first->meter_type == "Gas Flow Meter" && $last->meter_type == "Gas Flow Meter") {
                    // dd(str_replace(',', '', $last->total));
                    // dd($last->total . 'Create_at ' . $last->created_at . ' - ' . 'Create_at ' . $first->created_at . '  ' . $first->total);
                }
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => round(str_replace(',', '', $last->total) - str_replace(',', '', $first->total), 2)];
                }
                // dd($totalConsumption);
            }
            // dd($meters);

            return view('admin.adminside.databydate', compact('meters', 'meterId', 'from', 'to', 'machineId', 'meterIds', 'machine',  'metersName', 'totalConsumption', 'dailyRuningHours'));
        }
        $end = date('Y-m-d', strtotime('+1 day', strtotime($to)));


        $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereBetween('created_at', [$request->from, $end])->whereIn('meter_id', $meterIds)->where('machine_id',  $request->areaID)->get();

        $meters = $meters->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
        });

        $dailyRuningHours = [];
        foreach ($meters as $key => $meter) {

            $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

            // dd($status->count());
            if (!$status->isEmpty()) {
                $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
            }
        }

        // dd($dailyRuningHours);

        $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [$request->from, $end])->distinct()->get();

        $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereBetween('created_at', [$request->from, $end])->whereIn('meter_id', $meterIds)->where('machine_id',  $request->areaID)->get();

        $totalMeters = $totalMeters->groupBy(function ($data) {
            return $data->meter_id;
        });

        $totalConsumption = [];
        foreach ($totalMeters as $meter) {

            // dd($meter);
            $first = $meter->first();
            $last = $meter->last();
            if ($first->meter_type == "Steam Flow Meter" && $last->meter_type == "Steam Flow Meter") {
                // dd(str_replace(',', '', $last->total));
                // dd($last->total . 'Create_at ' . $last->created_at . ' - ' . 'Create_at ' . $first->created_at . '  ' . $first->total);
            }
            if ($first->meter_type != "Machine Status") {
                $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => round(str_replace(',', '', $last->total) - str_replace(',', '', $first->total), 2)];
            }
            // dd($totalConsumption);
        }

        // dd($meters);
        $meterId = 0;

        $num = 2;
        return view('admin.adminside.databydate', compact('meters', 'meterId', 'from', 'to', 'machineId', 'meterIds', 'machine',  'metersName', 'totalConsumption', 'dailyRuningHours'));
    }

    public function currentDateDetails($meterId, $date, $areaId)
    {
        if ($areaId != 0) {
            $machine = Machine::with(['building'])->where('id', $areaId)->first();
            $building = Machine::find($areaId);
            $meters = Meter::where('machine_id', $areaId)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }

            // dd($meterIds);

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $date)->where('machine_id', $areaId)->get();


            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });

            $endDay = date('d-m-Y H:i:s', strtotime($date) + (24 * 60 * 60 - 1));
            // dd(date('d-m-y H:i:s', strtotime($date)) . ' ' . $endDay);
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [date('Y-m-d H:i:s', strtotime($date)), date('Y-m-d H:i:s', strtotime($endDay))])->where('machine_id', $areaId)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            $machineStatus = DB::table('meters_view')->whereIn('meter_id', $meterIds)->where('meter_type', 'Machine Status')->whereDate('created_at', $date)->where('machine_id', $areaId)->get();

            $machineStatus = $machineStatus->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });
            // dd($machineStatus);
            // $metters->last()  ;
            // dd($meters);





            // foreach ($meters as $value) {
            //     ++$i;
            //     if ($i < $varToal) {
            //     }
            // }

            // dd($meters->count());
            $totalConsumption = [];
            foreach ($totalMeters as $meter) {

                // dd($meter);
                $first = $meter->first();
                $last = $meter->last();
                if ($first->meter_type == "Steam Flow Meter" && $last->meter_type == "Steam Flow Meter") {
                    // dd(str_replace(',', '', $last->total));
                    // dd($last->total . 'Create_at ' . $last->created_at . ' - ' . 'Create_at ' . $first->created_at . '  ' . $first->total);
                }
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => round(str_replace(',', '', $last->total) - str_replace(',', '', $first->total), 2)];
                }
                // dd($totalConsumption);
            }

            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at', $date)->distinct()->get();


            return view('admin.adminside.databycurrentdate', compact('meters', 'meterId', 'date', 'areaId', 'meterIds', 'building', 'metersName', 'machine', 'totalConsumption', 'machineStatus'));
        }

        $meters = SteamFlowMeter::orderBy('created_at', 'desc')->whereDate('created_at', $date)->where('meter_id', $meterId)->where('user_id', Auth::user()->id)->paginate(15);
        $meters1 = SteamFlowMeter::whereDate('created_at', $date)->where('meter_id', $meterId)->where('user_id', Auth::user()->id)->get();

        if ($meters->isEmpty()) {
            $meters = GasFlowMeter::orderBy('created_at', 'desc')->whereDate('created_at', $date)->where('meter_id', $meterId)->where('user_id', Auth::user()->id)->paginate(15);

            $meters1 = GasFlowMeter::whereDate('created_at', $date)->where('meter_id', $meterId)->where('user_id', Auth::user()->id)->get();
        }

        // dd($meters1);
        $total = 0;
        $total1 = 0;
        foreach ($meters1 as $meter) {
            $total1 += floatval($meter->total_consumption);
        }

        $total = number_format($total1, 2);
        $meterIds = [];
        $building = null;
        // dd($total);
        // $meterId = intval($meterId);
        // dd($meterId);

        return view('admin.filterdata', compact('meters', 'meterId', 'date', 'total', 'areaId', 'meterIds', 'building'));
        dd($meters);
    }
}
