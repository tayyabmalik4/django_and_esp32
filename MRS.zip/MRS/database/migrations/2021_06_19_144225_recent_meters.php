<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class RecentMeters extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        \DB::statement("
        CREATE OR REPLACE VIEW recent_meters AS
        (
            SELECT
            format( `steam_flow_meters`.`flow`,0) AS `flow`,
            `steam_flow_meters`.`flow_unit` AS `flow_unit`,
            format(`steam_flow_meters`.`temp`,0) AS `temp`,
            `steam_flow_meters`.`temp_unit` AS `temp_unit`,
            format(`steam_flow_meters`.`pressure`,0) AS `pressure`,
            `steam_flow_meters`.`pressure_unit` AS `pressure_unit`,
            NULL AS `power`,
            NULL AS `power_unit`,
            NULL AS `current`,
            NULL AS `current_unit`,
            NULL AS `voltage`,
            NULL AS `voltage_unit`,
            format(`steam_flow_meters`.`total`,0) AS `total`,
            `steam_flow_meters`.`total_unit` AS `total_unit`,
            `steam_flow_meters`.`updated_at` AS `updated_at`,
            `steam_flow_meters`.`meter_id` AS `meter_id`,
            `steam_flow_meters`.`meter_type` AS `meter_type`,
            `steam_flow_meters`.`id` AS `id`,
            `meters`.`machine_id` AS `machine_id`,
            `meters`.`user_id` AS `user_id`
            FROM
            (
            `steam_flow_meters`
            JOIN `meters` ON
            (
            (
            (
            `steam_flow_meters`.`meter_id` = `meters`.`meter_id`
            ) AND ISNULL(
            `meters`.`deleted_at`
            )
            )
            )
            )
            WHERE
            `steam_flow_meters`.`id` IN(
            SELECT
            MAX(
            `steam_flow_meters`.`id`
            ) AS `id`
            FROM
            `steam_flow_meters`
            GROUP BY
            `steam_flow_meters`.`meter_id`
            )
            GROUP BY
            `steam_flow_meters`.`meter_id`
            )
            UNION ALL
            (
            SELECT
            format(`gas_flow_meters`.`flow`,0) AS `flow`,
            `gas_flow_meters`.`flow_unit` AS `flow_unit`,
            format(`gas_flow_meters`.`temp`,0) AS `temp`,
            `gas_flow_meters`.`temp_unit` AS `temp_unit`,
            NULL AS `pressure`,
            NULL AS `pressure_unit`,
            format(`gas_flow_meters`.`power`,0) AS `power`,
            `gas_flow_meters`.`power_unit` AS `power_unit`,
            NULL AS `current`,
            NULL AS `current_unit`,
            NULL AS `voltage`,
            NULL AS `voltage_unit`,
            format(`gas_flow_meters`.`total`,0) AS `total`,
            `gas_flow_meters`.`total_unit` AS `total_unit`,
            `gas_flow_meters`.`updated_at` AS `updated_at`,
            `gas_flow_meters`.`meter_id` AS `meter_id`,
            `gas_flow_meters`.`meter_type` AS `meter_type`,
            `gas_flow_meters`.`id` AS `id`,
            `meters`.`machine_id` AS `machine_id`,
            `meters`.`user_id` AS `user_id`
            FROM
            (
            `gas_flow_meters`
            JOIN `meters` ON
            (
            (
            (
            `gas_flow_meters`.`meter_id` = `meters`.`meter_id`
            ) AND ISNULL(
            `meters`.`deleted_at`
            )
            )
            )
            )
            WHERE
            `gas_flow_meters`.`id` IN(
            SELECT
            MAX(
            `gas_flow_meters`.`id`
            ) AS `id`
            FROM
            `gas_flow_meters`
            GROUP BY
            `gas_flow_meters`.`meter_id`
            )
            GROUP BY
            `gas_flow_meters`.`meter_id`
            )
            UNION ALL
            (
            SELECT
            format(`energy_flow_meters`.`flow`,0) AS `flow`,
            `energy_flow_meters`.`flow_unit` AS `flow_unit`,
            NULL AS `temp`,
            NULL AS `temp_unit`,
            NULL AS `pressure`,
            NULL AS `pressure_unit`,
            NULL AS `power`,
            NULL AS `power_unit`,
            format(`energy_flow_meters`.`current`,0) AS `current`,
            `energy_flow_meters`.`current_unit` AS `current_unit`,
            format(`energy_flow_meters`.`voltage`,0) AS `voltage`,
            `energy_flow_meters`.`voltage_unit` AS `voltage_unit`,
            format(`energy_flow_meters`.`total`,0) AS `total`,
            `energy_flow_meters`.`total_unit` AS `total_unit`,
            `energy_flow_meters`.`updated_at` AS `updated_at`,
            `energy_flow_meters`.`meter_id` AS `meter_id`,
            `energy_flow_meters`.`meter_type` AS `meter_type`,
            `energy_flow_meters`.`id` AS `id`,
            `meters`.`machine_id` AS `machine_id`,
            `meters`.`user_id` AS `user_id`
            FROM
            (
            `energy_flow_meters`
            JOIN `meters` ON
            (
            (
            (
            `energy_flow_meters`.`meter_id` = `meters`.`meter_id`
            ) AND ISNULL(
            `meters`.`deleted_at`
            )
            )
            )
            )
            WHERE
            `energy_flow_meters`.`id` IN(
            SELECT
            MAX(
            `energy_flow_meters`.`id`
            ) AS `id`
            FROM
            `energy_flow_meters`
            GROUP BY
            `energy_flow_meters`.`meter_id`
            )
            GROUP BY
            `energy_flow_meters`.`meter_id`
            )
            UNION ALL
            (
            SELECT
            format( `water_flow_meters`.`flow`,0) AS `flow`,
            `water_flow_meters`.`flow_unit` AS `flow_unit`,
            NULL AS `temp`,
            NULL AS `temp_unit`,
            NULL AS `pressure`,
            NULL AS `pressure_unit`,
            NULL AS `power`,
            NULL AS `power_unit`,
            NULL AS `current`,
            NULL AS `current_unit`,
            NULL AS `voltage`,
            NULL AS `voltage_unit`,
            format(`water_flow_meters`.`total`,0) AS `total`,
            `water_flow_meters`.`total_unit` AS `total_unit`,
            `water_flow_meters`.`updated_at` AS `updated_at`,
            `water_flow_meters`.`meter_id` AS `meter_id`,
            `water_flow_meters`.`meter_type` AS `meter_type`,
            `water_flow_meters`.`id` AS `id`,
            `meters`.`machine_id` AS `machine_id`,
            `meters`.`user_id` AS `user_id`
            FROM
            (
            `water_flow_meters`
            JOIN `meters` ON
            (
            (
            (
            `water_flow_meters`.`meter_id` = `meters`.`meter_id`
            ) AND ISNULL(
            `meters`.`deleted_at`
            )
            )
            )
            )
            WHERE
            `water_flow_meters`.`id` IN(
            SELECT
            MAX(
            `water_flow_meters`.`id`
            ) AS `id`
            FROM
            `water_flow_meters`
            GROUP BY
            `water_flow_meters`.`meter_id`
            )
            GROUP BY
            `water_flow_meters`.`meter_id`
            )
            UNION ALL
            (
            SELECT
            format(`production_meters`.`flow`,0) AS `flow`,
            `production_meters`.`flow_unit` AS `flow_unit`,
            NULL AS `temp`,
            NULL AS `temp_unit`,
            NULL AS `pressure`,
            NULL AS `pressure_unit`,
            NULL AS `power`,
            NULL AS `power_unit`,
            NULL AS `current`,
            NULL AS `current_unit`,
            NULL AS `voltage`,
            NULL AS `voltage_unit`,
            format(`production_meters`.`total`,0) AS `total`,
            `production_meters`.`total_unit` AS `total_unit`,
            `production_meters`.`updated_at` AS `updated_at`,
            `production_meters`.`meter_id` AS `meter_id`,
            `production_meters`.`meter_type` AS `meter_type`,
            `production_meters`.`id` AS `id`,
            `meters`.`machine_id` AS `machine_id`,
            `meters`.`user_id` AS `user_id`
            FROM
            (
            `production_meters`
            JOIN `meters` ON
            (
            (
            (
            `production_meters`.`meter_id` = `meters`.`meter_id`
            ) AND ISNULL(
            `meters`.`deleted_at`
            )
            )
            )
            )
            WHERE
            `production_meters`.`id` IN(
            SELECT
            MAX(
            `production_meters`.`id`
            ) AS `id`
            FROM
            `production_meters`
            GROUP BY
            `production_meters`.`meter_id`
            )
            GROUP BY
            `production_meters`.`meter_id`
            )
        ");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        // Schema::drop('meters_view');

    }
}
