@extends('admin.layouts.master')
@section('css')
    <link rel="stylesheet" href="{{ asset('admin/css/dataTables.bootstrap4.min.css') }}">

@endsection
@section('page-title')

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="/admin/companies">Company</a></li>
            <li class="breadcrumb-item active" aria-current="page">
                @if (!empty($company))
                    Update Company Data
                @else
                    Add Company Data
                @endif
            </li>
        </ol>
    </nav>
@endsection
@section('page-title-action')

@endsection

@section('content')
    <div class="container">
        <div class="card mb-3 ml-3 mr-3">
            <div class="card-body">
                @if (session()->has('success'))
                    <div class="alert alert-success alert-dismissible fade show mt-2 mb-2" role="alert">
                        <strong>{{ session()->get('success') }}</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @elseif (session()->has('error'))
                    <div class="alert alert-info alert-dismissible fade show mt-2 mb-2" role="alert">
                        <strong>{{ session()->get('error') }}</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                <h3 class="card-title text-primary">
                    Company Data
                </h3>
                <form action="/admin/company-add" method="post" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id" @if (!empty($company)) value="{{ $company->id }}" @endif>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Company Name <span class="text-danger"><small>@error('name')
                                                {{ $message }}
                                            @enderror</small></span></label>
                                <input type="text" name="name" id="" class="form-control" placeholder="Enetr Company Name"
                                    aria-describedby="helpId" @if (old('name')) value="{{ old('name') }}" @elseif (!empty($company)) value="{{ $company->name }}" @endif>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Company Email <span class="text-danger"><small>@error('email')
                                                {{ $message }}
                                            @enderror</small></span></label>
                                <input type="email" name="email" id="" class="form-control"
                                    placeholder="Enter Company Email" aria-describedby="helpId" @if (old('email')) value="{{ old('email') }}" @elseif (!empty($company)) value="{{ $company->email }}" @endif>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Company Logo <span class="text-danger"><small>@error('file')
                                                {{ $message }}
                                            @enderror</small></span></label>
                                <input type="file" name="file" id="" class="form-control" placeholder=""
                                    aria-describedby="helpId">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Company Address <span class="text-danger"><small>@error('address')
                                                {{ $message }}
                                            @enderror</small></span></label>
                                <input type="text" name="address" id="" class="form-control"
                                    placeholder="Enter Company Address" aria-describedby="helpId" @if (old('address')) value="{{ old('address') }}" @elseif (!empty($company)) value="{{ $company->address }}" @endif>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Company Phone <span class="text-danger"><small>@error('phone')
                                                {{ $message }}
                                            @enderror</small></span></label>
                                <input type="text" name="phone" id="" class="form-control" placeholder="Enter Company Phone"
                                    aria-describedby="helpId" @if (old('phone')) value="{{ old('phone') }}" @elseif (!empty($company)) value="{{ $company->phone }}" @endif>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Company Password <span class="text-danger"><small>@error('password')
                                                {{ $message }}
                                            @enderror</small></span></label>
                                <input type="password" name="password" id="" class="form-control"
                                    placeholder="Enter Company Password" aria-describedby="helpId" @if (old('password')) value="{{ old('password') }}" @endif min="8">
                            </div>
                        </div>
                    </div>



                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            @if (!empty($company))
                                Update Data
                            @else
                                Add Data
                            @endif
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('js')

@endsection
