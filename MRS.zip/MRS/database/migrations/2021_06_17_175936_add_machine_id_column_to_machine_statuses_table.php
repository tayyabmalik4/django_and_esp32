<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMachineIdColumnToMachineStatusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('machine_statuses', function (Blueprint $table) {
            //
            $table->unsignedBigInteger('machine_id')->default(null);
            // $table->foreign('machine_id')->references('id')->on('machine_statuses')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('machine_statuses', function (Blueprint $table) {
            //
            $table->dropColumn('machine_id');
        });
    }
}
