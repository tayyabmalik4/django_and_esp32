<?php

namespace App\Http\Controllers\Admin;

use PDF;
use App\Models\User;
use App\Models\Meter;
use App\Models\Machine;
use App\Models\Building;
use App\Exports\dataByDates;
use App\Exports\MultiExport;
use App\Models\GasFlowMeter;
use Illuminate\Http\Request;
use App\Exports\SingleExport;
use App\Models\MachineStatus;
use App\Models\SteamFlowMeter;
use Illuminate\Support\Carbon;
use App\Exports\dataByCurrentDate;
use App\Exports\dataByDatesExport;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;

class FilePrintController extends Controller
{
    public function exportSingleExcel($meterid, $from, $to, $areaId)
    {
        // dd($areaId);
        $machine = Machine::with(['building'])->where('id', $areaId)->first();
        $currentdate = date('d-m-Y');
        $date = Carbon::now();

        return Excel::download(new dataByDates($meterid, $from, $to, $areaId), $machine->building->building_area . '-' . $machine->machine_name . '-' . date('d-m-Y', strtotime($date)) . '.xlsx');
    }


    public function exportSinglePDF($meterid, $from, $to, $areaId)
    {
        $date = date('d-m-Y');

        if ($areaId != 0) {
            $machine = Machine::with(['building'])->where('id', $areaId)->first();
            if (Auth::user()->is_admin) {
                $user = User::find($machine->user_id);
                $logo = $user->logo;
                $companyName = $user->name;
            } else {
                $logo = Auth::user()->logo;
                $companyName = Auth::user()->name;
            }
            // dd($areaId);
            $area = Building::find($machine->building_id);
            $meters = Meter::where('machine_id', $areaId)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }
            // dd($meterIds);
            if ($from == $to) {
                $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->where('machine_id', $areaId)->get();

                $meters = $meters->groupBy(function ($date) {
                    return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
                });

                $dailyRuningHours = [];
                foreach ($meters as $key => $meter) {

                    $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                    // dd($status->count());
                    if (!$status->isEmpty()) {
                        $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                    }
                }
                // dd($meterIds);
                // dd($meters);
                // dd($dailyRuningHours);
                $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->where('user_id', $machine->user_id)->distinct()->get();


                $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereDate('created_at', $from)->whereIn('meter_id', $meterIds)->where('machine_id', $areaId)->get();

                $totalMeters = $totalMeters->groupBy(function ($data) {
                    return $data->meter_id;
                });

                $totalConsumption = [];
                foreach ($totalMeters as $meter) {
                    $first = $meter->first();
                    $last = $meter->last();
                    if ($first->meter_type != "Machine Status") {
                        $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                    }
                }
                $date = Carbon::now();

                $pdf = PDF::loadView('admin.layouts.datePdfGenerate', compact('meters', 'metersName', 'area', 'date', 'logo', 'companyName', 'totalConsumption', 'machine', 'dailyRuningHours'));
                return $pdf->download($machine->building->building_arae . '-' . $machine->machine_name . '-' . date('d-m-Y', strtotime($date)) . ' ' . $meterid . '.pdf');
            }
            $end = date('Y-m-d', strtotime('+1 day', strtotime($to)));
            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [$from, $end])->where('machine_id', $areaId)->get();

            $meters = $meters->groupBy(function ($date) {
                return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
            });

            $dailyRuningHours = [];
            foreach ($meters as $key => $meter) {

                $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                // dd($status->count());
                if (!$status->isEmpty()) {
                    $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                }
            }

            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [$from, $end])->where('user_id', $machine->user_id)->distinct()->get();

            // dd($metersName);

            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereBetween('created_at', [$from, $end])->whereIn('meter_id', $meterIds)->where('machine_id', $areaId)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });

            $totalConsumption = [];
            foreach ($totalMeters as $meter) {
                $first = $meter->first();
                $last = $meter->last();
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }



            $date = Carbon::now();
            // dd($machine);
            $pdf = PDF::loadView('admin.layouts.datePdfGenerate', compact('meters', 'metersName', 'area', 'date', 'logo', 'companyName', 'totalConsumption', 'machine', 'dailyRuningHours'));
            return $pdf->download($machine->building->building_area . '-' . $machine->machine_name . '-' . date('d-m-Y', strtotime($date)) . ' ' . $meterid . '.pdf');
        }


        // with specific meter id
        if ($from == $to) {
            $meters = SteamFlowMeter::whereDate('created_at', $from)->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();
            if ($meters->isEmpty()) {
                $meters = GasFlowMeter::whereDate('created_at', $from)->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();
            }

            $total = 0;
            foreach ($meters as $meter) {
                $total += floatval($meter->total_consumption);
            }

            $total = number_format($total, 2);
            $excelArray[] = ['date' => $from, 'consumption' => $total];

            // dd($excelArray);
            $date = Carbon::now();

            $pdf = PDF::loadView('admin.layouts.datePdfGenerate', compact('excelArray'));
            return $pdf->download($date . ' ' . $meterid . '.pdf');
        }

        $meters = SteamFlowMeter::whereBetween('created_at', [$from, $to])->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();
        $meters = $meters->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
        });
        if ($meters->isEmpty()) {
            $meters = GasFlowMeter::whereBetween('created_at', [$from, $to])->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();
            $meters = $meters->groupBy(function ($date) {
                return \Carbon\Carbon::parse($date->created_at)->format('d-M-y');
            });
        }

        $excelArray = [];
        foreach ($meters as $key => $meter) {
            $total = 0;
            foreach ($meter as $data) {
                $total = $total + $data->total_consumption;
            }
            $excelArray[] = ['date' => $key, 'consumption' => $total];
        }

        $date = Carbon::now();

        $pdf = PDF::loadView('admin.layouts.datePdfGenerate', compact('excelArray'));
        return $pdf->download($date . ' ' . $meterid . '.pdf');
    }

    public function exportRangeExcel($meterid, $from, $areaId)
    {
        $machine = Machine::with(['building'])->where('id', $areaId)->first();
        $date = Date('d-m-Y');
        return Excel::download(new dataByCurrentDate($meterid, $from, $areaId, $date), $machine->building->building_area . '-' . $machine->machine_name . '-' . date('d-m-Y', strtotime($date)) . '.xlsx');
    }


    public function exportRangePDF($meterid, $from, $areaId)
    {
        ini_set('max_execution_time', -1);

        if ($areaId != 0) {

            $machine = Machine::with(['building'])->where('id', $areaId)->first();
            // dd($machine->machine_name);
            if (Auth::user()->is_admin) {
                $user = User::find($machine->user_id);
                $logo = $user->logo;
                $companyName = $user->name;
            } else {
                $logo = Auth::user()->logo;
                $companyName = Auth::user()->name;
            }
            $meters = Meter::where('machine_id', $areaId)->where('user_id', $machine->user_id)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->where('machine_id', $areaId)->get();

            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });

            $machineStatus = DB::table('meters_view')->whereIn('meter_id', $meterIds)->where('meter_type', 'Machine Status')->whereDate('created_at', $from)->where('machine_id', $areaId)->get();

            $machineStatus = $machineStatus->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });
            // dd($meters);
            // dd($machineStatus);
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->distinct()->get();

            $endDay = date('d-m-Y H:i:s', strtotime($from) + (24 * 60 * 60 - 1));
            // dd(date('d-m-y H:i:s', strtotime($date)) . ' ' . $endDay);
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [date('Y-m-d H:i:s', strtotime($from)), date('Y-m-d H:i:s', strtotime($endDay))])->where('user_id', $machine->user_id)->where('machine_id', $areaId)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            $totalConsumption = [];
            foreach ($totalMeters as $key => $meterData) {
                $first = $meterData->first();
                $last = $meterData->last();
                // dd(str_replace(',', '', $last->total));
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }

            $date = Carbon::now();
            $pdf = PDF::loadView('admin.layouts.hourlyPdfGenerate', compact('meters', 'metersName', 'machine', 'date', 'logo', 'companyName', 'totalMeters', 'totalConsumption', 'machineStatus'));
            return $pdf->download($machine->building->building_area . '-' . $machine->machine_name . '-' . $date . '.pdf');
        }

        $meters = SteamFlowMeter::whereDate('created_at', $from)->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();

        if ($meters->isEmpty()) {
            $meters = GasFlowMeter::whereDate('created_at', $from)->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();
        }

        // dd($meters);
        $excelArray = [];
        $total = 0;
        foreach ($meters as $meter) {
            // dd($meter->created_at);
            $excelArray[] = ['date' => $meter->created_at, 'time' => date('g:ia', strtotime($meter->updated_at)), 'consumption' => $meter->total_consumption, 'total' => $meter->total];
        }

        $date = Carbon::now();
        $pdf = PDF::loadView('admin.layouts.hourlyPdfGenerate', compact('excelArray'));
        return $pdf->download($date . ' ' . $meterid . '.pdf');
    }
}
