<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSteamFlowMetersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('steam_flow_meters', function (Blueprint $table) {
            $table->id();
            $table->string('meter_type');
            $table->string('flow');
            $table->string('total');
            $table->string('temp');
            $table->string('pressure');
            $table->unsignedBigInteger('user_id');
            // $table->unsignedBigInteger('building_id');
            $table->string('meter_id');
            $table->string('total_consumption')->nullable();
            $table->timestamps();

            // $table->foreign('building_id')->references('id')->on('buildings')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('steam_flow_meters');
    }
}
