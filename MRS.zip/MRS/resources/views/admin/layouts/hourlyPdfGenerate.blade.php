<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    {{-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> --}}
    <style>
        body {
            /* background-color: #000 */
        }

        .padding {
            padding: 2rem !important
        }

        .card {
            margin-bottom: 30px;
            border: none;
            -webkit-box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22);
            -moz-box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22);
            box-shadow: 0px 1px 2px 1px rgba(154, 154, 204, 0.22)
        }

        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e6e6f2
        }

        h3 {
            font-size: 20px
        }

        h5 {
            font-size: 15px;
            line-height: 26px;
            color: #3d405c;
            margin: 0px 0px 15px 0px;
            font-family: 'Circular Std Medium'
        }

        .text-dark {
            color: #3d405c !important
        }

        table.table-bordered {
            border: 1px solid #0714a0;
            margin-top: 20px;
        }

        table.table-bordered>thead>tr>th {
            border: 1px solid #0714a0;
            /* padding: 0px; */
        }

        table.table-bordered>tbody>tr>td {
            border: 1px solid #7FFF00;
            /* padding: 0px; */
            white-space: nowrap;
        }


        #tableHead {
            background-color: #0714a0;
        }

        #tableRow {
            color: white;
        }

        #tableFooter {
            background-color: #7CFC00;
        }

        .particulars {
            background-color: #32CD32;
            color: white;
            font-weight: bold;
        }

        #report {
            border-style: none;
            color: #0714a0;
            font-size: medium;
            font-weight: bold;
        }

        img {
            height: 100px !important;
        }


        p {
            text-align: center;
        }

    </style>
</head>

<body>




    <table width="100%">
        <tr>
            <td><img src="{{ public_path('admin/company/images/' . $logo) }}" alt="" width="150"
                    style="text-align: left !important;" /></td>
            <td style="padding-righ:250px;font-weight:bold">
                {{ $companyName }}
            </td>
            <td style="padding-righ:250px;font-weight:bold">
                {{ date('d-m-Y', strtotime($date)) }}
            </td>

        </tr>
    </table>


    <table width="100%" style="margin-top: 15px">
        <tr>

            <td style="padding-left:20px; font-weight:bold">
                HOURLY REPORT
            </td>
            <td style="font-weight: bold">MRS-9000 Metering Reporting System</td>
            <td style=" font-weight:bold;padding-right:50px" align="right">
                {{ $machine->machine_name }}
            </td>
        </tr>
    </table>

    {{-- <div class="card-body"> --}}
    <table class="table text-center table-bordered" cellpadding="" cellspacing="0" width="100%">
        <thead id="tableHead">
            <tr id="tableRow">
                <th align="center" style="font-size: x-small">Date</th>
                <th align="center" style="font-size: x-small">Time</th>
                @if (!$metersName->isEmpty())
                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Steam Flow Meter')
                            <th style="font-size: x-small" align="center">{{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Gas Flow Meter')
                            <th style="font-size: x-small" align="center">{{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Energy Meter')
                            <th style="font-size: x-small" align="center">{{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Water Flow Meter')
                            <th style="font-size: x-small" align="center">{{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach

                    @foreach ($metersName as $steamMeter)
                        @if ($steamMeter->meter_type == 'Production Meter')
                            <th style="font-size: x-small" align="center">{{ $steamMeter->meter_type }}
                                <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                            </th>
                        @endif
                    @endforeach
                @endif
                @if (!$machineStatus->isEmpty())
                    <th align="center" style="font-size: x-small"> Machine <br> Status</th>
                @endif
            </tr>
        </thead>
        <tbody>
            @if (!$meters->isEmpty())
                {{-- @dd($meters) --}}
                @php
                    $varToal = $meters->count();
                    $decrement = -1;
                @endphp
                @foreach ($meters as $key => $meter)
                    @php
                        ++$decrement;
                    @endphp
                    @if ($decrement < $varToal)
                        <tr>
                            <td scope="row" align="center" style="font-size: smaller">
                                {{ date('d-m-Y', strtotime($key)) }}
                            </td>
                            <td align="center" style="font-size: smaller">{{ date('ga', strtotime($key)) }}</td>

                            @foreach ($metersName as $flowName)
                                @if ($flowName->meter_type == 'Steam Flow Meter')
                                    @php
                                        $i = 0;
                                    @endphp
                                    @foreach ($meter as $flowMeter)
                                        @if ($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id)
                                            <td align="center">{{ round($flowMeter->total_consumption, 2) }}
                                            </td>
                                            @php
                                                $i = $i + 1;
                                            @endphp
                                        @endif
                                    @endforeach
                                    @if ($i == 0)
                                        <td align="center">0</td>
                                    @endif
                                @endif
                            @endforeach

                            @foreach ($metersName as $gasName)
                                @if ($gasName->meter_type == 'Gas Flow Meter')
                                    @php
                                        $i = 0;
                                    @endphp
                                    @foreach ($meter as $gasMeter)
                                        @if ($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                            <td align="center">{{ $gasMeter->total_consumption }}
                                            </td>
                                            @php
                                                $i = $i + 1;
                                            @endphp
                                        @endif
                                    @endforeach
                                    @if ($i == 0)
                                        <td align="center">0</td>
                                    @endif
                                @endif
                            @endforeach

                            @foreach ($metersName as $gasName)
                                @if ($gasName->meter_type == 'Energy Meter')
                                    @php
                                        $i = 0;
                                    @endphp
                                    @foreach ($meter as $gasMeter)
                                        @if ($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                            <td align="center">{{ $gasMeter->total_consumption }}
                                            </td>
                                            @php
                                                $i = $i + 1;
                                            @endphp
                                        @endif
                                    @endforeach
                                    @if ($i == 0)
                                        <td align="center">0</td>
                                    @endif
                                @endif
                            @endforeach

                            @foreach ($metersName as $gasName)
                                @if ($gasName->meter_type == 'Water Flow Meter')
                                    @php
                                        $i = 0;
                                    @endphp
                                    @foreach ($meter as $gasMeter)
                                        @if ($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                            <td align="center">{{ $gasMeter->total_consumption }}
                                            </td>
                                            @php
                                                $i = $i + 1;
                                            @endphp
                                        @endif
                                    @endforeach
                                    @if ($i == 0)
                                        <td align="center">0</td>
                                    @endif
                                @endif
                            @endforeach

                            @foreach ($metersName as $gasName)
                                @if ($gasName->meter_type == 'Production Meter')
                                    @php
                                        $i = 0;
                                    @endphp
                                    @foreach ($meter as $gasMeter)
                                        @if ($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                            <td align="center">{{ $gasMeter->total_consumption }}
                                            </td>
                                            @php
                                                $i = $i + 1;
                                            @endphp
                                        @endif
                                    @endforeach
                                    @if ($i == 0)
                                        <td align="center">0</td>
                                    @endif
                                @endif
                            @endforeach
                            @if (!$machineStatus->isEmpty())
                                @php
                                    $count = 0;
                                @endphp
                                @foreach ($machineStatus as $key1 => $status)
                                    @if (date('ga', strtotime($key)) == date('ga', strtotime($key1)))

                                        @foreach ($status as $machine)
                                            <td align="center">{{ $machine->machine_status }}</td>
                                            @php
                                                $count = $count + 1;
                                            @endphp
                                        @endforeach
                                    @endif

                                @endforeach
                                @if ($count == 0)
                                    <td align="center">-</td>
                                @endif
                            @endif
                        </tr>
                    @endif
                @endforeach
                @if (!empty($totalConsumption))


                    <tr>
                        <td colspan="2" align="center" style="background-color: #32CD32;color:white">Total</td>
                        @foreach ($metersName as $name)
                            @if ($name->meter_type == 'Steam Flow Meter')
                                @foreach ($totalConsumption as $meter)
                                    @if ($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                        <td align="center" style="background-color: #32CD32;color:white">
                                            {{ number_format($meter['total'], 2) }}</td>
                                    @endif
                                @endforeach
                            @endif
                        @endforeach

                        @foreach ($metersName as $name)
                            @if ($name->meter_type == 'Gas Flow Meter')
                                @foreach ($totalConsumption as $meter)
                                    @if ($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                        <td align="center" style="background-color: #32CD32;color:white">
                                            {{ number_format($meter['total']) }}</td>
                                    @endif
                                @endforeach
                            @endif
                        @endforeach

                        @foreach ($metersName as $name)
                            @if ($name->meter_type == 'Energy Meter')
                                @foreach ($totalConsumption as $meter)
                                    @if ($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id)
                                        <td align="center" style="background-color: #32CD32;color:white">
                                            {{ number_format($meter['total']) }}</td>
                                    @endif
                                @endforeach
                            @endif
                        @endforeach

                        @foreach ($metersName as $name)
                            @if ($name->meter_type == 'Water Flow Meter')
                                @foreach ($totalConsumption as $meter)
                                    @if ($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                        <td align="center" style="background-color: #32CD32;color:white">
                                            {{ number_format($meter['total']) }}</td>
                                    @endif
                                @endforeach
                            @endif
                        @endforeach

                        @foreach ($metersName as $name)
                            @if ($name->meter_type == 'Production Meter')
                                @foreach ($totalConsumption as $meter)
                                    @if ($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id)
                                        <td align="center" style="background-color: #32CD32;color:white">
                                            {{ number_format($meter['total']) }}</td>
                                    @endif
                                @endforeach
                            @endif
                        @endforeach
                        @if (!$machineStatus->isEmpty())
                            <td align="center" style="background-color: #32CD32;color:white">-</td>
                        @endif
                    </tr>
                @endif
            @endif
        </tbody>
    </table>


</body>

</html>
