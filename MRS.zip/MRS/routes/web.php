<?php

use App\Models\Building;
use App\Models\GasFlowMeter;
use App\Models\MachineStatus;
use App\Models\SteamFlowMeter;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome');
    return redirect('login');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Route::get('/dashboard', function () {
//     return view('admin.layouts.master');
// });


// Route::get('admin/login', function () {
//     return view('admin.login');
// });

// Route::get('steam', function () {
//     $meters = SteamFlowMeter::all();
//     foreach ($meters as $meter) {
//         $meter->flow_unit = "kg/h";
//         $meter->total_unit = "Ton";
//         $meter->save();
//     }
//     dd($meters);
// });


// Route::get('gass', function () {
//     $meters = GasFlowMeter::all();
//     foreach ($meters as $meter) {
//         $meter->flow_unit = "m3/hr";
//         $meter->total_unit = "m3";
//         $meter->save();
//     }
//     dd($meters);
// });


// Route::get('runhours', function () {
//     $meters = MachineStatus::all();
//     foreach ($meters as $meter) {
//         $status = MachineStatus::find($meter->id);
//         if ($status->status == "Run") {
//             $status->status = "ON";
//             $status->save();
//         }
//     }

//     dd($meters);
// });

Route::get('login', [App\Http\Controllers\Admin\LoginController::class, 'index'])->name('user.login');
Route::get('logout', [App\Http\Controllers\Admin\LoginController::class, 'logout']);

Route::prefix('user')->group(function () {

    Route::middleware('auth')->group(function () {
        Route::get('dashboard', [App\Http\Controllers\Admin\LoginController::class, 'dashboard']);

        Route::get('machine-meters/{id}', [\App\Http\Controllers\MachineController::class, 'meters']);
        Route::get('search', [\App\Http\Controllers\AreaController::class, 'search']);
        Route::get('current-date-details/{meter}/{date}/{areaId}', [\App\Http\Controllers\AreaController::class, 'currentDateDetails']);

        Route::get('printExcelSingle/{meterid}/{from}/{to}/{areaId}', [\App\Http\Controllers\SteamFlowMeterController::class, 'exportSingleExcel']);
        Route::get('printPDFSingle/{meterid}/{from}/{to}/{areaId}', [\App\Http\Controllers\SteamFlowMeterController::class, 'exportSinglePDF']);

        Route::get('printExcelMultiples/{meterid}/{date}/{areaId}', [\App\Http\Controllers\SteamFlowMeterController::class, 'exportRangeExcel']);
        Route::get('printPDFMultiples/{meterid}/{date}/{areaId}', [\App\Http\Controllers\SteamFlowMeterController::class, 'exportRangePDF']);
    });
});


Route::prefix('admin')->group(function () {

    Route::get('signin', [App\Http\Controllers\Admin\LoginController::class, 'signin']);

    Route::middleware('auth')->group(function () {
        Route::get('dashboard', [App\Http\Controllers\Admin\LoginController::class, 'dashboard']);
        Route::get('area/{id}', [\App\Http\Controllers\AreaController::class, 'index']);
        Route::get('area-details/{id}', [\App\Http\Controllers\AreaController::class, 'details']);

        Route::get('steamflow/{meter}', [\App\Http\Controllers\SteamFlowMeterController::class, 'export']);
        Route::get('steamflowpdf/{meter}', [\App\Http\Controllers\SteamFlowMeterController::class, 'exportPDF']);


        Route::get('printExcelMultiGraph/{id}', [\App\Http\Controllers\SteamFlowMeterController::class, 'exportMultiGraphExcel']);
        Route::get('prinPDFMultiGraph/{id}', [\App\Http\Controllers\SteamFlowMeterController::class, 'exportMultiGraphPDF']);

        //------------Companies---------------//
        Route::get('companies', [\App\Http\Controllers\CompanyController::class, 'index']);
        Route::get('company-add/{id?}', [\App\Http\Controllers\CompanyController::class, 'addCompany']);
        Route::post('company-add', [\App\Http\Controllers\CompanyController::class, 'store']);
        Route::get('company-delete/{id}', [\App\Http\Controllers\CompanyController::class, 'delete']);


        //---------------Machines--------------//

        Route::get('user-machine-meters/{id}', [\App\Http\Controllers\Admin\AdminController::class, 'metters']);
        Route::get('machine-search/', [\App\Http\Controllers\Admin\AdminController::class, 'search']);



        //-----------------Files Print By Admin------------------////
        Route::get('printExcelDataByDates/{meterid}/{from}/{to}/{areaId}', [\App\Http\Controllers\Admin\FilePrintController::class, 'exportSingleExcel']);
        Route::get('printPDFDataByDates/{meterid}/{from}/{to}/{areaId}', [\App\Http\Controllers\Admin\FilePrintController::class, 'exportSinglePDF']);


        Route::get('printExcelDataByCurrentDate/{meterid}/{date}/{areaId}', [\App\Http\Controllers\Admin\FilePrintController::class, 'exportRangeExcel']);
        Route::get('printPDFDataByCurrentDate/{meterid}/{date}/{areaId}', [\App\Http\Controllers\Admin\FilePrintController::class, 'exportRangePDF']);

        Route::get('dataByCurrentDate/{meter}/{date}/{areaId}', [\App\Http\Controllers\Admin\AdminController::class, 'currentDateDetails']);
    });
});
