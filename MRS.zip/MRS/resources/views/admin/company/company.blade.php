@extends('admin.layouts.adminmaster')
@section('css')
    <link rel="stylesheet" href="{{ asset('admin/css/dataTables.bootstrap4.min.css') }}">

@endsection
@section('page-title')
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Companies</li>
        </ol>
    </nav>
@endsection
@section('page-title-action')
    @if (Auth::user()->is_admin)
        <a href="/admin/company-add" class="btn btn-primary" id="myBtn">Add New Company</a>
    @endif

@endsection

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-body">


                @if (session()->has('success'))
                    <div class="alert alert-success alert-dismissible fade show mt-2 mb-2" role="alert">
                        <strong>{{ session()->get('success') }}</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @elseif (session()->has('error'))
                    <div class="alert alert-info alert-dismissible fade show mt-2 mb-2" role="alert">
                        <strong>{{ session()->get('error') }}</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Phone</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if (!$companies->isEmpty())
                            @foreach ($companies as $company)
                                <tr>
                                    <td>{{ $company->name }}</td>
                                    <td>{{ $company->email }}</td>
                                    <td>{{ $company->address }}</td>
                                    <td>{{ $company->phone }}</td>
                                    <td><a href="/admin/company-add/{{ $company->id }}" class="btn btn-primary"><i
                                                class="far fa-edit"></i></a> <button
                                            onclick="deleteCompany({{ $company->id }})" class="btn btn-danger"><i
                                                class="far fa-trash-alt"></i></button></td>
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('admin/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('admin/js/dataTables.bootstrap4.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });

        function deleteCompany(id) {
            // console.log(id);
            // href="/admin/company-delete/{{ $company->id }}"
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "get",
                        url: "/admin/company-delete/" + id,
                        data: "data",
                        dataType: "json",
                        success: function(response) {
                            if (response.status == 'success') {
                                toastr.success(response.msg);
                                location.reload();

                            } else if (response.status == 'error') {
                                $('#mettererror').html(response.msg);
                            }
                        }
                    });
                }
            })
        }

    </script>
@endsection
