<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// Route::post('meter-data', [\App\Http\Controllers\SteamFlowMeterController::class, 'index']);

Route::post('steam-flow-meter', [\App\Http\Controllers\SteamFlowMeterController::class, 'index']);

Route::get('add-new-area', [App\Http\Controllers\AreaController::class, 'store']);
Route::get('all-areas', [App\Http\Controllers\AreaController::class, 'getdata']);
Route::get('editarea', [App\Http\Controllers\AreaController::class, 'editArea']);
Route::delete('delete-area/{id}', [App\Http\Controllers\AreaController::class, 'deleteArea']);

Route::get('add-meter', [App\Http\Controllers\AreaController::class, 'addMeter']);
Route::get('editmeter', [App\Http\Controllers\AreaController::class, 'editMeter']);
Route::delete('delete-meter/{id}', [App\Http\Controllers\AreaController::class, 'deleteMeter']);

Route::get('add-new-machine', [App\Http\Controllers\AreaController::class, 'addMachine']);
Route::get('editmachine', [App\Http\Controllers\AreaController::class, 'updateMachine']);
Route::delete('delete-machine/{id}', [App\Http\Controllers\AreaController::class, 'deleteMachine']);
Route::get('getChartData/{id}/{meter}', [App\Http\Controllers\AreaController::class, 'chartData']);
// Route::get('admin/area-details/{id?}/{meter?}', [\App\Http\Controllers\AreaController::class, 'details']);
