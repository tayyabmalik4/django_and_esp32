<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class MetersView extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \DB::statement("
        CREATE OR REPLACE VIEW meters_view AS
            SELECT
                `sm`.`meter_type` AS `meter_type`,
                FORMAT(`sm`.`flow`, 2) AS `flow`,
                FORMAT(`sm`.`total`, 2) AS `total`,
                `sm`.`meter_id` AS `meter_id`,
                `sm`.`user_id` AS `user_id`,
                `sm`.`total_consumption` AS `total_consumption`,
                `sm`.`flow_unit` AS `flow_unit`,
                `sm`.`total_unit` AS `total_unit`,
                `sm`.`created_at` AS `created_at`,
                `sm`.`updated_at` AS `updated_at`,
            `meters`.`machine_id` AS `machine_id`,
                NULL as machine_status
            FROM
                (
                `steam_flow_meters` `sm`
                JOIN `meters` ON
                    (
                        (
                            `meters`.`meter_id` = `sm`.`meter_id` AND meters.deleted_at IS NULL
                        )
                    )
                )
            UNION ALL
            SELECT
                `gm`.`meter_type` AS `meter_type`,
                FORMAT(ROUND(`gm`.`flow`, 0),
                0) AS `flow`,
                FORMAT(ROUND(`gm`.`total`, 0),
                0) AS `total`,
                `gm`.`meter_id` AS `meter_id`,
                `gm`.`user_id` AS `user_id`,
                FORMAT(
                    ROUND(`gm`.`total_consumption`, 0),
                    0
                ) AS `total_consumption`,
                `gm`.`flow_unit` AS `flow_unit`,
                `gm`.`total_unit` AS `total_unit`,
                `gm`.`created_at` AS `created_at`,
                `gm`.`updated_at` AS `updated_at`,
                `meters`.`machine_id` AS `machine_id`,
                NULL as machine_status
            FROM
                (
                `gas_flow_meters` `gm`
                JOIN `meters` ON
                    (
                        (
                            `meters`.`meter_id` = `gm`.`meter_id` AND meters.deleted_at IS NULL
                        )
                    )
                )
            UNION ALL
            SELECT
                `em`.`meter_type` AS `meter_type`,
                FORMAT(ROUND(`em`.`flow`, 0),
                0) AS `flow`,
                FORMAT(ROUND(`em`.`total`, 0),
                0) AS `total`,
                `em`.`meter_id` AS `meter_id`,
                `em`.`user_id` AS `user_id`,
                FORMAT(
                    ROUND(`em`.`total_consumption`, 0),
                    0
                ) AS `total_consumption`,
                `em`.`flow_unit` AS `flow_unit`,
                `em`.`total_unit` AS `total_unit`,
                `em`.`created_at` AS `created_at`,
                `em`.`updated_at` AS `updated_at`,
                `meters`.`machine_id` AS `machine_id`,
                NULL as machine_status
            FROM
                (
                    `energy_flow_meters` `em`
                JOIN `meters` ON
                    (
                        (
                            `meters`.`meter_id` = `em`.`meter_id` AND meters.deleted_at IS NULL
                        )
                    )
                )
            UNION ALL
            SELECT
                `pm`.`meter_type` AS `meter_type`,
                FORMAT(ROUND(`pm`.`flow`, 0),
                0) AS `flow`,
                FORMAT(ROUND(`pm`.`total`, 0),
                0) AS `total`,
                `pm`.`meter_id` AS `meter_id`,
                `pm`.`user_id` AS `user_id`,
                FORMAT(
                    ROUND(`pm`.`total_consumption`, 0),
                    0
                ) AS `total_consumption`,
                `pm`.`flow_unit` AS `flow_unit`,
                `pm`.`total_unit` AS `total_unit`,
                `pm`.`created_at` AS `created_at`,
                `pm`.`updated_at` AS `updated_at`,
                `meters`.`machine_id` AS `machine_id`,
                NULL as machine_status
            FROM
                (
                    `production_meters` `pm`
                JOIN `meters` ON
                    (
                        (
                            `meters`.`meter_id` = `pm`.`meter_id` AND meters.deleted_at IS NULL
                        )
                    )
                )
            UNION ALL
            SELECT
                `wm`.`meter_type` AS `meter_type`,
                FORMAT(ROUND(`wm`.`flow`, 0),
                0) AS `flow`,
                FORMAT(ROUND(`wm`.`total`, 0),
                0) AS `total`,
                `wm`.`meter_id` AS `meter_id`,
                `wm`.`user_id` AS `user_id`,
                FORMAT(
                    ROUND(`wm`.`total_consumption`, 0),
                    0
                ) AS `total_consumption`,
                `wm`.`flow_unit` AS `flow_unit`,
                `wm`.`total_unit` AS `total_unit`,
                `wm`.`created_at` AS `created_at`,
                `wm`.`updated_at` AS `updated_at`,
                `meters`.`machine_id` AS `machine_id`,
                NULL as machine_status
            FROM
                (
                `water_flow_meters` `wm`
                JOIN `meters` ON
                    (
                        (
                            `meters`.`meter_id` = `wm`.`meter_id` AND meters.deleted_at IS NULL
                        )
                    )
                )
            UNION ALL

            SELECT
                'Machine Status' AS `meter_type`,
                NULL AS `flow`,
                NULL AS `total`,
                ms.meter_id AS `meter_id`,
                NULL AS `user_id`,
                NULL AS `total_consumption`,
                NULL AS `flow_unit`,
                NULL AS `total_unit`,
                ms.created_at AS `created_at`,
                ms.updated_at AS `updated_at`,
                meters.`machine_id` AS `machine_id`,
            ms.status as machine_status
            FROM (
            machine_statuses ms
            JOIN `meters` ON
                    (
                        (
                            `meters`.`meter_id` = `ms`.`meter_id` AND meters.deleted_at IS NULL
                        )
                    )
                )
        ");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        // Schema::drop(' Drop VIEW meters_view');
    }
}
