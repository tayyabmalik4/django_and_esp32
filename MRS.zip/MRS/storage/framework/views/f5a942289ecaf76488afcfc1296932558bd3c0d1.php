<?php $__env->startSection('title', 'Hourly Report'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/user/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item">
                <?php if(!empty($machine)): ?>
                    <?php echo e($machine->building->building_area); ?>

                <?php endif; ?>
            </li>
            <li class="breadcrumb-item active">
                <?php if(!empty($building)): ?>
                    <?php echo e(strtoupper($building->machine_name)); ?>

                <?php endif; ?>
            </li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title-action'); ?>
    <?php if(!empty($meterId)): ?>
        <?php echo e($meterId); ?>

    <?php elseif(!empty($building)): ?>
        
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="conatiner">
        <div class="container">
            <div class="main-card mb-3 card">
                <div class="card-body" id="dataTable">



                    <?php if(!$meters->isEmpty()): ?>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger float-right ml-1 mb-3">Close</a>
                        <a href="/user/printPDFMultiples/<?php echo e($meterId); ?>/<?php echo e($date); ?>/<?php echo e($areaId); ?>"
                            class="btn btn-info float-right ml-1 mb-3" target=”_blank”>Print Pdf</a>
                        <a href="/user/printExcelMultiples/<?php echo e($meterId); ?>/<?php echo e($date); ?>/<?php echo e($areaId); ?>"
                            class="btn btn-primary float-right ml-1 mb-3">Export to
                            Excel</a>
                    <?php endif; ?>
                    <h5 class="card-title">Hourly Report</h5>

                    <table class="table text-center table-bordered">
                        <thead id="tableHead">
                            <tr id="tableRow">
                                <th>Date</th>
                                <th>Time</th>
                                <?php if(!$metersName->isEmpty()): ?>
                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Steam Flow Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?>

                                                <br><?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Gas Flow Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?>

                                                <br><?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Energy Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?>

                                                <br><?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Water Flow Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?>

                                                <br><?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steamMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($steamMeter->meter_type == 'Production Meter'): ?>
                                            <th><?php echo e($steamMeter->meter_type); ?>

                                                <br><?php echo e($steamMeter->meter_id); ?>

                                                <br><?php echo e(' (' . $steamMeter->total_unit . ')'); ?>

                                            </th>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(!$machineStatus->isEmpty()): ?>
                                    <th> Machine <br> Status</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!$meters->isEmpty()): ?>
                                
                                <?php
                                    $varToal = $meters->count();
                                    $decrement = -1;
                                ?>
                                <?php $__currentLoopData = $meters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        ++$decrement;
                                    ?>
                                    <?php if($decrement < $varToal): ?>
                                        <tr>
                                            <td scope="row"><?php echo e(date('d-m-Y', strtotime($key))); ?>

                                            </td>
                                            <td><?php echo e(date('ga', strtotime($key))); ?></td>

                                            <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flowName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($flowName->meter_type == 'Steam Flow Meter'): ?>
                                                    <?php
                                                        $i = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flowMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id): ?>
                                                            <td><?php echo e(round($flowMeter->total_consumption, 2)); ?>

                                                            </td>
                                                            <?php
                                                                $i = $i + 1;
                                                            ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($i == 0): ?>
                                                        <td>0</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($gasName->meter_type == 'Gas Flow Meter'): ?>
                                                    <?php
                                                        $i = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                            <td><?php echo e($gasMeter->total_consumption); ?>

                                                            </td>
                                                            <?php
                                                                $i = $i + 1;
                                                            ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($i == 0): ?>
                                                        <td>0</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($gasName->meter_type == 'Energy Meter'): ?>
                                                    <?php
                                                        $i = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                            <td><?php echo e($gasMeter->total_consumption); ?>

                                                            </td>
                                                            <?php
                                                                $i = $i + 1;
                                                            ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($i == 0): ?>
                                                        <td>0</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($gasName->meter_type == 'Water Flow Meter'): ?>
                                                    <?php
                                                        $i = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                            <td><?php echo e($gasMeter->total_consumption); ?>

                                                            </td>
                                                            <?php
                                                                $i = $i + 1;
                                                            ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($i == 0): ?>
                                                        <td>0</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($gasName->meter_type == 'Production Meter'): ?>
                                                    <?php
                                                        $i = 0;
                                                    ?>
                                                    <?php $__currentLoopData = $meter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id): ?>
                                                            <td><?php echo e($gasMeter->total_consumption); ?>

                                                            </td>
                                                            <?php
                                                                $i = $i + 1;
                                                            ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($i == 0): ?>
                                                        <td>0</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$machineStatus->isEmpty()): ?>
                                                <?php
                                                    $count = 0;
                                                ?>
                                                <?php $__currentLoopData = $machineStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(date('ga', strtotime($key)) == date('ga', strtotime($key1))): ?>

                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td><?php echo e($machine->machine_status); ?></td>
                                                            <?php
                                                                $count = $count + 1;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($count == 0): ?>
                                                    <td>-</td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($totalConsumption)): ?>
                                    <tr>

                                        <td colspan="2" style="background-color: #32CD32;color:white">Total</td>
                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($name->meter_type == 'Steam Flow Meter'): ?>
                                                <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                        <td style="background-color: #32CD32;color:white">
                                                            <?php echo e(number_format($meter['total'], 2)); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($name->meter_type == 'Gas Flow Meter'): ?>
                                                <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                        <td style="background-color: #32CD32;color:white">
                                                            <?php echo e(number_format($meter['total'])); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($name->meter_type == 'Energy Meter'): ?>
                                                <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                        <td style="background-color: #32CD32;color:white">
                                                            <?php echo e(number_format($meter['total'])); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($name->meter_type == 'Water Flow Meter'): ?>
                                                <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                        <td style="background-color: #32CD32;color:white">
                                                            <?php echo e(number_format($meter['total'])); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $metersName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($name->meter_type == 'Production Meter'): ?>
                                                <?php $__currentLoopData = $totalConsumption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id): ?>
                                                        <td style="background-color: #32CD32;color:white">
                                                            <?php echo e(number_format($meter['total'])); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$machineStatus->isEmpty()): ?>
                                            <td style="background-color: #32CD32;color:white">-</td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hunch_machines\resources\views/admin/filterdata.blade.php ENDPATH**/ ?>