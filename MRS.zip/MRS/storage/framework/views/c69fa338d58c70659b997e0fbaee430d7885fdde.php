<?php $__env->startSection('title', 'MRS-9000'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/user/dashboard">Dashboard</a></li>
            <li class="breadcrumb-item">
                <?php if(!empty($machine)): ?>
                    <?php echo e($machine->building->building_area); ?>

                <?php endif; ?>
            </li>
            <li class="breadcrumb-item active">
                <?php if(!empty($machine)): ?>
                    <?php echo e(strtoupper($machine->machine_name)); ?>

                <?php endif; ?>
            </li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title-action'); ?>
    <?php if(!empty($machine)): ?>
        <div class="container">
            
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <input type="hidden" id="meter1" <?php if($userId): ?> value="<?php echo e($userId); ?>" <?php endif; ?>>
    <input type="hidden" id="meter2" <?php if($meters1): ?> value="<?php echo e($meters1); ?>" <?php endif; ?>>
    <div class="container mt-2">
        <div class="card">
            <div class="card-body">
                <?php
                    $i = 0;
                ?>
                <div class="text-center text-primary">
                    
                </div>
                <div class="text-center text-danger">
                    <?php if(session()->has('error')): ?>
                        <p> <?php echo e(session()->get('error')); ?></p>
                    <?php endif; ?>
                </div>
                <form action="/user/search" method="GET">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="areaID" <?php if($id): ?> value="<?php echo e($id); ?>" <?php endif; ?>>
                    <table class="table text-center table-bordered">
                        <thead id="tableHead">
                            <tr id="tableRow">
                                <th colspan="2" style="font-size: smaller">REPORTING</th>
                                <th style="font-size: smaller">PARTICULARS</th>
                                <?php if(!empty($meters)): ?>
                                    <?php $__currentLoopData = $meters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th style="font-size: smaller"> <?php echo e($meter->meter_type); ?>

                                            <br><?php echo e($meter->meter_id); ?>

                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(!empty($meterStatus)): ?>
                                    <th style="font-size: smaller">Machine <br> Status</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="particulars"
                                    style="border:1px solid #32CD32;font-size: smaller;font-weight: normal">FROM:</td>
                                <td><input type="date" name="from" id="dpd1" class="form-control" placeholder=""
                                        aria-describedby="helpId" required <?php if(old('from')): ?> value="<?php echo e(old('from')); ?>" <?php else: ?> value="<?php echo e(date('Y-m-d')); ?>" <?php endif; ?> style="font-size: x-small"></td>
                                <td class="particulars" scope="row"
                                    style="border:1px solid #32CD32;font-size: smaller;font-weight: normal">FLOW
                                </td>
                                <?php if(!empty($meters)): ?>
                                    <?php $__currentLoopData = $meters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td style="font-size: x-small">
                                            <?php echo e($meter->flow . ' ' . $meter->flow_unit); ?>

                                            <?php if($meter->temp): ?>
                                                <?php echo e(' | ' . $meter->temp . ' ' . $meter->temp_unit); ?>

                                            <?php endif; ?>
                                            <?php if($meter->pressure): ?>
                                                <?php echo e(' | ' . $meter->pressure . ' ' . $meter->pressure_unit); ?>

                                            <?php endif; ?>
                                            <?php if($meter->power): ?>
                                                <?php echo e(' | ' . $meter->power . ' ' . $meter->power_unit); ?>

                                            <?php endif; ?>
                                            <?php if($meter->current): ?>
                                                <?php echo e(' | ' . $meter->current . ' ' . $meter->current_unit); ?>

                                            <?php endif; ?>
                                            <?php if($meter->voltage): ?>
                                                <?php echo e(' | ' . $meter->voltage . ' ' . $meter->voltage_unit); ?>

                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(!empty($meterStatus)): ?>
                                    <td style="font-size: small;" rowspan="2">

                                        <?php if($meterStatus->status == 'ON'): ?>
                                            <span style="background-color: #32CD32;color:white;margin-left:1px;padding:5px">
                                                <?php echo e($meterStatus->status); ?>

                                            </span>
                                        <?php elseif($meterStatus->status == 'OFF'): ?>
                                            <span style="background-color: red;color:white;margin-left:1px;padding:5px">
                                                <?php echo e($meterStatus->status); ?>

                                            </span>
                                        <?php elseif($meterStatus->status == 'STANDBY'): ?>
                                            <span style="background-color: Orange;color:white;margin-left:1px;padding:5px">
                                                <?php echo e($meterStatus->status); ?>

                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>

                                <?php endif; ?>

                            </tr>
                            <tr>
                                <td class="particulars"
                                    style="border:1px solid #32CD32;font-size: smaller;font-weight: normal">TO:</td>
                                <td> <input type="date" name="to" id="dpd2" class="form-control" placeholder=""
                                        aria-describedby="helpId" required <?php if(old('to')): ?> value="<?php echo e(old('to')); ?>" <?php else: ?> value="<?php echo e(date('Y-m-d')); ?>" <?php endif; ?> style="font-size: x-small"></td>
                                <td class="particulars" scope="row"
                                    style="border:1px solid #32CD32;font-size: smaller;font-weight: normal">
                                    TOTAL</td>
                                <?php if($meters): ?>
                                    <?php $__currentLoopData = $meters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td style="font-size: x-small">
                                            <?php echo e($meter->total); ?> <br> <?php echo e($meter->total_unit); ?> </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </tr>
                            <tr>
                                <td colspan="2">

                                    <button class="btn btn-primary mt-2 mb-1" type="submit" id="">REPORT</button>

                                </td>
                                <td class="particulars" scope="row"
                                    style="border:1px solid #32CD32;font-size: smaller;font-weight: normal">
                                    UPDATED</td>

                                <?php if($meters): ?>
                                    <?php $__currentLoopData = $meters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td style="font-size: x-small">
                                            <?php echo e(date('d-m-Y', strtotime($meter->updated_at))); ?> <br>
                                            <?php echo e(date('g:ia', strtotime($meter->updated_at))); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(!empty($meterStatus)): ?>
                                    <td style="font-size:x-small">
                                        <?php if(!empty($meterStatus->status)): ?>
                                            <?php echo e(date('d-m-Y', strtotime($meterStatus->updated_at))); ?> <br>
                                            <?php echo e(date('g:ia', strtotime($meterStatus->updated_at))); ?>

                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>

    <div class="container mt-3">
        <div id="graphs">


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.2.0/chart.min.js"
        integrity="sha512-VMsZqo0ar06BMtg0tPsdgRADvl0kDHpTbugCBBrL55KmucH6hP9zWdLIWY//OTfMnzz6xWQRxQqsUFefwHuHyg=="
        crossorigin="anonymous"></script>
    <script>
        //chart

        $(document).ready(function() {
            loadchart();
        });

        window.setTimeout(function() {
            window.location.reload();
        }, 80000);

        function loadchart() {
            userid = JSON.parse($('#meter1').val());
            meters2 = JSON.parse($('#meter2').val());
            // console.log(meters2);
            meters2.forEach(function(data) {
                var chartId = data.meter_id;
                $.ajax({
                    type: "get",
                    url: "/api/getChartData/" + userid + '/' + data.meter_id,
                    data: "data",
                    dataType: "json",
                    success: function(response) {
                        // console.log(response);
                        var dev = '';
                        dev +=
                            '<div class="mb-3 card"><div class="card-header-tab card-header-tab-animation card-header"><div class="card-header-title"><i class="header-icon lnr-apartment icon-gradient bg-love-kiss"></i>' +
                            data.meter_type + ' (' +
                            chartId +
                            ')</div></div><div class="card-body"><div class="tab-content"><div class="tab-pane fade show active" id="tabs-eg-77"><div class="card mb-3 widget-chart widget-chart2 text-left w-100"><div class="widget-chat-wrapper-outer"><div class="widget-chart-wrapper widget-chart-wrapper-lg opacity-10 m-0"><canvas id="' +
                            chartId +
                            '" style="height: 400px; width: 100%;"></canvas></div></div></div></div></div ></div></div>';

                        // console.log(response);
                        $('#graphs').append(dev);
                        unit = data.total_unit;
                        setChartValue(chartId, response, unit);
                    }
                });
            })
        }

        function setChartValue(chartId, response, unit) {
            // console.log(response);
            const labels = response.labels;
            const dataValues = response.yAxisData;
            const data = {
                labels: labels,
                datasets: [{
                    label: 'Data',
                    data: dataValues,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                    ],
                    borderWidth: 1
                }]
            };

            const config = {
                type: 'line',
                data: data,


                options: {
                    responsive: false,
                    scales: {
                        x: {
                            display: true,
                            title: {
                                display: true,
                                text: "Time"
                            }
                        },
                        y: {
                            display: true,
                            title: {
                                display: true,
                                text: unit
                            }
                        },
                    }
                },
            };
            new Chart(
                document.getElementById(chartId),
                config
            );
        }
    </script>>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hunch_machines\resources\views/admin/machinemeters.blade.php ENDPATH**/ ?>