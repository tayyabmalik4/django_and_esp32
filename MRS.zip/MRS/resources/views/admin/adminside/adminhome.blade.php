@extends('admin.layouts.master')
@section('title', 'Admin Dashboard')
@section('css')

@endsection
@section('page-title')
    <div class="container">
        Dashboard
    </div>
@endsection
@section('page-title-action')


@endsection

@section('content')

    <div class="container">
        @if (!$areas->isEmpty())
            @foreach ($areas as $key => $area)
                <div class="container">
                    <h5 class="">{{ $key }} @if (Auth::user()->is_admin)
                            @foreach ($companyIds as $companyid)
                                @if ($companyid->name == $key)
                                    <button class="btn btn-primary float-right mr-2"
                                        onclick="addNewArea('{{ $companyid->id }}')">Add New Area</button>
                                @endif
                            @endforeach

                        @endif
                    </h5>
                </div>
                <br>
                <div class="row">
                    @foreach ($area as $building)
                        @foreach ($building->buildings as $data)
                            {{-- @dd($data); --}}
                            <div class="col-md-6">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <h5 class="card-title">{{ $data->building_area }}<button
                                                class="btn btn-sm btn-primary float-right ml-1"
                                                onclick="updateArea({{ $data->id }},'{{ $data->building_area }}')"><i
                                                    class="far fa-edit"
                                                    title="Update Area {{ $data->building_area }}"></i></button><button
                                                class="btn btn-sm btn-danger float-right"
                                                onclick="deleteArea({{ $data->id }})"><i class="far fa-trash-alt"
                                                    title="Delete Area {{ $data->building_area }}"></i></button> <button
                                                class="btn btn-success btn-sm float-right mr-2"
                                                onclick="addNewMachine({{ $data->id }},{{ $data->user_id }})">Add
                                                Machine</button>
                                        </h5>
                                        <div id="exampleAccordion{{ $data->id }}" data-children=".item">

                                            <div class="item">
                                                <button type="button" aria-expanded="false"
                                                    aria-controls="exampleAccordion{{ $data->id }}"
                                                    data-toggle="collapse" href="#collapse-{{ $data->id }}"
                                                    class="m-0 p-0 btn btn-link">Machines</button>
                                                <div data-parent="#exampleAccordion{{ $data->id }}"
                                                    id="collapse-{{ $data->id }}" class="collapse">
                                                    @if (!$data->machines->isEmpty())
                                                        <div class="row ">
                                                            @foreach ($data->machines as $machine)
                                                                <div class="col-md-6">
                                                                    <p class="mb-1 mt-3"><a
                                                                            href="/admin/user-machine-meters/{{ $machine->id }}"
                                                                            class="badge badge-focus">{{ $machine->machine_name }}
                                                                        </a>
                                                                        <span>
                                                                            <a href="function:void"
                                                                                class="badge badge-danger mt-1"
                                                                                onclick="deleteMAchine({{ $machine->id }})"
                                                                                title="Delete Machine {{ $machine->machine_name }}">
                                                                                <i class="far fa-trash-alt"></i></a>
                                                                        </span>
                                                                        <span>
                                                                            <a href="function:void"
                                                                                class="badge badge-primary mt-1"
                                                                                onclick="editMachine({{ Auth::user()->id }},{{ $machine->id }},
                                                                                                                                                                                                                                                                                                                                                                                                            '{{ $machine->machine_name }}',{{ $data->id }})"
                                                                                title="Edit Machine {{ $machine->machine_name }}">
                                                                                <i class="far fa-edit"></i></a>
                                                                        </span>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    @else
                                                        <div class="row">
                                                            <div class="col-md-8">
                                                                <p class="mb-3 mt-3">No Data Available
                                                                </p>
                                                            </div>

                                                        </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @endforeach
                </div>
            @endforeach
        @endif
    </div>

    <!---------------- Add New Area ----------->
    <div id="myModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">

            <h5 class="text-primary mt-2 pb-4">Add New Area <span class="close float-right">&times;</span></h5>
            <form action="" method="get" id="addnewarea">
                <input type="hidden" name="companyId" id="companyId">
                <div class="form-group">
                    <label for="">Area/Building Name <span class="text-danger"><small id="areaerror"></small></span></label>
                    {{-- <input type="hidden" value="{{ Auth::user()->id }}" id="id" name="id"> --}}
                    <input type="text" name="name" id="name" class="form-control" placeholder="Area/Building"
                        aria-describedby="helpId" required>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </div>
    </div>


    <!---------------- Update Area Data----------->
    <div id="updatearea" class="modal">
        <!-- Modal content -->
        <div class="modal-content">

            <h5 class="text-primary mt-2 pb-4">Update Area <span class="close5 float-right cross">&times;</span></h5>
            <form action="" method="get" id="editarea">
                <input type="hidden" name="areaId" id="areaEditId">
                <div class="form-group">
                    <label for="">Area/Building Name <span class="text-danger"><small
                                id="areaediterror"></small></span></label>
                    {{-- <input type="hidden" value="{{ Auth::user()->id }}" id="id" name="id"> --}}
                    <input type="text" name="name" id="areadEditName" class="form-control" placeholder="Area/Building"
                        aria-describedby="helpId" required>
                </div>
                <button type="submit" class="btn btn-primary">Update Data</button>
            </form>
        </div>
    </div>


    {{-- -----------------Add New Machine------------------- --}}

    <div id="machineModel" class="modal">
        <!-- Modal content -->
        <div class="modal-content">

            <h5 class="text-primary mt-2 pb-4">Add New Machine <span class="close3 float-right cross">&times;</span></h5>
            <form action="" method="get" id="addnewmachine">
                <input type="hidden" name="areaId" id="areaId">
                <input type="hidden" value="" id="userId" name="userId">
                <div class="form-group">
                    <label for="">Machine Name <span class="text-danger"><small id="machineerror"></small></span></label>

                    <input type="text" name="name" id="name" class="form-control" placeholder="Machine Name"
                        aria-describedby="helpId" required>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </div>
    </div>


    {{-- ------------Edit Machine------------ --}}
    <div id="machineeditModel" class="modal">
        <!-- Modal content -->
        <div class="modal-content">

            <h5 class="text-primary mt-2 pb-4">Edit Machine Data <span class="close4 float-right cross">&times;</span></h5>
            <form action="" method="get" id="editmachine">
                <input type="hidden" name="areaId" id="machineEditAreaId">
                <input type="hidden" value="" id="machineEditUserId" name="userId">
                <input type="hidden" value="" id="machineEditId" name="machineId">
                <div class="form-group">
                    <label for="">Machine Name <span class="text-danger"><small
                                id="machineediterror"></small></span></label>

                    <input type="text" name="name" id="machineEditName" class="form-control" placeholder="Machine Name"
                        aria-describedby="helpId" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>

@endsection

@section('js')
    <script>
        $(document).ready(function() {
            @if (Auth::user())
                var id={{ Auth::user()->id }}
                // console.log(id);
                getChartData(id);
            @endif

        });

        function addNewArea(id) {
            // console.log(id);
            var modal = document.getElementById("myModal");

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks the button, open the modal
            $('#companyId').val(id);
            modal.style.display = "block";


            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                $('#name').val('');
                modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    $('#name').val('');
                    modal.style.display = "none";
                }
            }
        }
        // Get the modal

        function addNewMachine(areaId, userId) {
            // console.log(areaId);
            var machineModal = document.getElementById("machineModel");

            // Get the button that opens the modal
            // var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close3")[0];

            // When the user clicks the button, open the modal
            $('#areaId').val(areaId);
            $('#userId').val(userId);
            machineModal.style.display = "block";


            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                $('#name').val('');
                machineModal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == machineModal) {
                    $('#name').val('');
                    machineModal.style.display = "none";
                }
            }
        }


        function getChartData(id) {
            dev = '';
            $.ajax({
                type: "get",
                url: "/api/all-areas",
                data: {
                    id: id
                },
                dataType: "json",
                success: function(response) {
                    // console.log(response);
                    if (response.status == 'success') {
                        console.log(response.data);
                        @if (Auth::user())
                            var is_admin={{ Auth::user()->is_admin }}
                            // console.log(id);
                            // getChartData(id);
                        @endif
                        response.data.forEach(function(areas) {
                            if (is_admin == 1) {

                                dev +=
                                    '<div class="col-md-3"><div class="main-card mb-3 card"><div class="card-body"><a href="/admin/area/' +
                                    areas.id +
                                    '"><h5 class = "card-title">Area/Building Name</h5><p>' +
                                    areas.building_area +
                                    '</p></a><button  id="" class="btn newMeter btn-secondary float-right" onClick="addNewMeter(' +
                                    areas.id + ')">Add Meter</button></div></div></div>';
                            } else {
                                dev +=
                                    '<div class="col-md-3"><div class="main-card mb-3 card"><div class="card-body"><a href="/admin/area/' +
                                    areas.id +
                                    '"><h5 class = "card-title">Area/Building Name</h5><p>' +
                                    areas.building_area +
                                    '</p></a></div></div></div>';
                            }

                        });
                        $('#areaData').html(dev);
                    }
                }
            });
        }

        function addNewMeter(id) {
            // console.log(id);

            // $('#exampleModal').show();
            // Get the modal
            var modal1 = document.getElementById("meterModal");
            modal1.style.display = "block";
            $('#building_id').val(id);
            // Get the button that opens the modal
            //var btn1 = document.getElementsByClassName("newMeter");

            // Get the <span> element that closes the modal
            var span1 = document.getElementsByClassName("close1")[0];

            // When the user clicks the button, open the modal
            // btn1.onclick = function() {
            //     modal1.style.display = "block";
            // }

            // When the user clicks on <span> (x), close the modal
            span1.onclick = function() {
                $('#name').val('');
                $('#building_id').val('');
                modal1.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal1) {
                    $('#name').val('');
                    $('#building_id').val('');
                    modal1.style.display = "none";
                }
            }
        }

        $("#addnewarea").submit(function(e) {
            e.preventDefault();
            $('#areaerror').html('');
            $.ajax({
                type: "get",
                url: "/api/add-new-area",
                data: $('#addnewarea').serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status == 'error') {
                        $('#areaerror').html(response.msg);
                    } else if (response.status == 'success') {

                        toastr.success(response.msg);
                        @if (Auth::user())
                            var id={{ Auth::user()->id }}
                            // console.log(id);
                            // getData(id);
                        @endif
                        location.reload();
                        modal.style.display = "none";
                        $('#addnewarea')[0].reset();
                    }
                }
            });

        });

        //-------------------Add new Machine By ajax-------//
        $("#addnewmachine").submit(function(e) {
            e.preventDefault();
            $('#machineerror').html('');
            $.ajax({
                type: "get",
                url: "/api/add-new-machine",
                data: $('#addnewmachine').serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status == 'error') {
                        $('#machineerror').html(response.msg);
                    } else if (response.status == 'success') {

                        toastr.success(response.msg);

                        location.reload();
                        modal.style.display = "none";
                        $('#addnewachine')[0].reset();
                    }
                }
            });

        });

        $('#addNewMeter').submit(function(e) {
            e.preventDefault();
            $('#areaerror').html('');
            $.ajax({
                type: "get",
                url: "/api/add-meter",
                data: $('#addNewMeter').serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status == 'success') {
                        toastr.success(response.msg);
                        modal.style.display = "none";
                        $('#addNewMeter')[0].reset();
                        location.reload();
                    } else if (response.status == 'error') {
                        $('#mettererror').html(response.msg);
                    }
                }
            });

        });


        //----------------Delete Area-------///
        function deleteArea(id) {
            // console.log(id);

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "delete",
                        url: "/api/delete-area/" + id,
                        data: "data",
                        dataType: "json",
                        success: function(response) {
                            if (response.status == 'success') {
                                toastr.success(response.msg);

                                location.reload();
                            } else if (response.status == 'error') {
                                toastr.error(response.msg);
                            }
                        }
                    });
                }
            })


        }

        // ----------- Delete Machine---------------//

        function deleteMAchine(id) {

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "delete",
                        url: "/api/delete-machine/" + id,
                        data: "data",
                        dataType: "json",
                        success: function(response) {
                            if (response.status == 'success') {
                                toastr.success(response.msg);

                                location.reload();
                            } else if (response.status == 'error') {
                                toastr.error(response.msg);
                            }
                        }
                    });
                }
            })
        }

        function editMachine(userid, machineid, machinename, areaid) {
            // console.log(userid + ' ' + machineid + ' ' + machinename + ' ' + areaid);

            var machineModal = document.getElementById("machineeditModel");

            // Get the button that opens the modal
            // var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close4")[0];

            // When the user clicks the button, open the modal
            $('#machineEditAreaId').val(areaid);
            $('#machineEditUserId').val(userid);
            $('#machineEditName').val(machinename);
            $('#machineEditId').val(machineid);
            machineModal.style.display = "block";


            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                $('#name').val('');
                machineModal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == machineModal) {
                    $('#name').val('');
                    machineModal.style.display = "none";
                }
            }
        }

        $('#editmachine').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: "You want to update data!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, update it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "get",
                        url: "/api/editmachine",
                        data: $('#editmachine').serialize(),
                        dataType: "json",
                        success: function(response) {
                            if (response.status == 'success') {
                                toastr.success(response.msg);
                                location.reload();
                            } else if (response.status == 'error') {
                                $('#machineediterror').html(response.msg);
                            }
                        }
                    });
                }
            })

        });

        function updateArea(areaid, areaname) {
            // console.log(areaid + ' ' + areaname);

            var updateAreaModal = document.getElementById("updatearea");

            // Get the button that opens the modal
            // var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close5")[0];

            // When the user clicks the button, open the modal
            $('#areaEditId').val(areaid);
            $('#areadEditName').val(areaname);

            updateAreaModal.style.display = "block";


            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                $('#araeEditName').val('');
                updateAreaModal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == updateAreaModal) {
                    $('#araeEditName').val('');
                    updateAreaModal.style.display = "none";
                }
            }
        }

        $('#editarea').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: "You want to update data!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, update it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "get",
                        url: "/api/editarea",
                        data: $('#editarea').serialize(),
                        dataType: "json",
                        success: function(response) {
                            if (response.status == 'success') {
                                toastr.success(response.msg);
                                location.reload();
                            } else if (response.status == 'error') {
                                $('#areaediterror').html(response.msg);
                            }
                        }
                    });
                }
            })

        });

    </script>

@endsection
