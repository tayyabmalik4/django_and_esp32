<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use App\Models\Building;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    //
    public function index()
    {
        if (Auth::user()) {
            if (Auth::user()->is_admin) {
                return redirect('/admin/dashboard');
            } else {
                return redirect('/user/dashboard');
            }
        }
        return view('admin.login');
    }

    public function signin(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);

        $remember_me  = (!empty($request->check)) ? TRUE : FALSE;

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $user = User::where(["email" => $request->email])->first();

            Auth::login($user, $remember_me);
            if (Auth::user()->is_admin) {
                return redirect('/admin/dashboard');
            } else {
                return redirect('/user/dashboard');
            }
        } else {
            return redirect()->back()->with('error', 'Email or Password Incorrect');
        }
    }

    public function dashboard()
    {
        if (!Auth::user()->is_admin) {
            $areas = User::with(['buildings'])->where('id', Auth::user()->id)->get();
            // dd($areas);
            $areas = $areas->groupBy(function ($result) {
                return $result->name;
            });

            return view('admin.home', compact('areas'));
        } else {
            $areas = User::with(['buildings'])->where('is_admin', '!=', 1)->get();
            $companyIds = User::select('id', 'name')->where('is_admin', '!=', 1)->distinct()->get();
            // dd($buildings);
            $areas = $areas->groupBy(function ($result) {
                return $result->name;
            });
            // dd($areas);

            return view('admin.adminside.adminhome', compact('areas', 'companyIds'));
        }
    }

    public function logout()
    {
        Auth::logout();

        return redirect('login');
    }
}
