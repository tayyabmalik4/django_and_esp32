<?php

namespace App\Http\Controllers;

use App\Models\Meter;
use App\Models\Machine;
use Illuminate\Http\Request;
use App\Models\MachineStatus;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class MachineController extends Controller
{
    //
    public function meters($id)
    {
        // dd($id);
        $machine = Machine::with(['building'])->where('id', $id)->first();
        // dd($machine->building);
        $meters = Meter::where('machine_id', $id)->get();
        // dd($meters);
        $meterIds = [];
        foreach ($meters as $meter) {
            $meterIds[] = $meter->meter_id;
        }

        $result = json_encode($meterIds);

        $meters = DB::table('recent_meters')->where('machine_id', $id)->where('user_id', Auth::user()->id)->orderBy('meter_type', 'desc')->get();
        // dd($meters);

        $meters1 = json_encode($meters);
        $userId = $machine->building->user_id;
        $meterStatus = MachineStatus::whereIn('meter_id', $meterIds)->orderBy('meter_type', 'desc')->latest()->first();
        // dd($meters);
        return view('admin.machinemeters', compact('machine', 'meters', 'meters1', 'id', 'userId', 'meterStatus'));
    }
}
