<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SteamFlowMeter extends Model
{
    use HasFactory;

    protected $table = "steam_flow_meters";

    public function getCreatedAtAttribute($key)
    {
        return Carbon::parse($key)->format('d-m-Y');
    }
}
