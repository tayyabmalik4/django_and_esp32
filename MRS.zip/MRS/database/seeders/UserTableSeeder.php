<?php

namespace Database\Seeders;

use App\Models\Building;
use App\Models\SteamFlowMeter;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        User::create([
            'name' => 'Amin',
            'email' => 'admin@test.com',
            'is_admin' => 1,
            'password' => Hash::make('123456')
        ]);

        User::create([
            'name' => 'User1',
            'email' => 'user1@test.com',
            'password' => Hash::make('123456'),
        ]);

        // Building::create([
        //     'building_area' => 'ABC',
        //     'user_id' => 2
        // ]);

        // SteamFlowMeter::create([
        //     'meter_type' => 'Steam Flow Meter',
        //     'flow' => 'XYZ',
        //     'total' => 12,
        //     'temp' => 30,
        //     'pressure' => 60,
        //     'user_id' => 2,
        //     'meter_id' => 1
        // ]);
    }
}
