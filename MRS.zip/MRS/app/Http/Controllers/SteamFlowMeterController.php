<?php

namespace App\Http\Controllers;

use App\Exports\dataByMachine;
use PDF;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Meter;
use App\Models\Building;
use App\Exports\MultiExport;
use App\Models\GasFlowMeter;
use Illuminate\Http\Request;
use App\Exports\SingleExport;
use App\Models\SteamFlowMeter;

// use App\Exports\UsersExport;
use App\Exports\MultiGraphExport;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\SteamFlowMeterExport;
use App\Models\EnergyFlowMeter;
use App\Models\Machine;
use App\Models\MachineStatus;
use App\Models\ProductionMeter;
use App\Models\WaterFlowMeter;

class SteamFlowMeterController extends Controller
{
    public function index(Request $request)
    {
        // dd($request->all());
        // dd($request->server()['QUERY_STRING']);
        $user = User::where('name', $request->client_name)->first();

        if (!empty($user)) {
            // dd($request->all());
            $previousConsumption = SteamFlowMeter::where('meter_id', $request->meter_id)->where('user_id', $user->id)->latest()->first();

            if ($request->meter_type == "Steam Flow Meter" && !empty($request->total)) {
                // dd('steam');
                $steamFlowMeter = new SteamFlowMeter();
                $steamFlowMeter->meter_type = $request->meter_type;
                $steamFlowMeter->flow = $request->flow;
                $steamFlowMeter->flow_unit = $request->flow_unit;
                $steamFlowMeter->total = $request->total;
                $steamFlowMeter->total_unit = $request->total_unit;
                $steamFlowMeter->temp = $request->temp;
                $steamFlowMeter->temp_unit = $request->temp_unit;
                $steamFlowMeter->pressure = $request->pressure;
                $steamFlowMeter->pressure_unit = $request->pressure_unit;
                $steamFlowMeter->user_id = $user->id;
                $steamFlowMeter->meter_id = $request->meter_id;
                if (!empty($previousConsumption)) {
                    $consumption = floatval($request->total) - floatval($previousConsumption->total);
                    if ($consumption > 0) {
                        $steamFlowMeter->total_consumption = $consumption;
                    } else {
                        $steamFlowMeter->total_consumption = 0;
                    }
                } else {
                    $steamFlowMeter->total_consumption = 0;
                }
                $steamFlowMeter->save();
                if ($steamFlowMeter) {
                    return json_encode(['status' => 'success', 'msg' => 'Steam Meter Data Add Successfully']);
                } else {
                    return json_encode(['status' => 'error', 'msg' => 'Something Went Wrong']);
                }
            } else if ($request->meter_type == "Gas Flow Meter" && !empty($request->total)) {
                // dd('gas');
                $previousConsumption = GasFlowMeter::where('meter_id', $request->meter_id)->where('user_id', $user->id)->latest()->first();
                $gasFlowMeter = new GasFlowMeter();
                $gasFlowMeter->meter_type = $request->meter_type;
                $gasFlowMeter->flow = $request->flow;
                $gasFlowMeter->flow_unit = $request->flow_unit;
                $gasFlowMeter->total = $request->total;
                $gasFlowMeter->total_unit = $request->total_unit;
                $gasFlowMeter->temp = $request->temp;
                $gasFlowMeter->temp_unit = $request->temp_unit;
                $gasFlowMeter->power = $request->power;
                $gasFlowMeter->power_unit = $request->power_unit;
                $gasFlowMeter->user_id = $user->id;
                $gasFlowMeter->meter_id = $request->meter_id;
                if (!empty($previousConsumption)) {
                    $consumption = floatval($request->total) - floatval($previousConsumption->total);
                    if ($consumption > 0) {
                        $gasFlowMeter->total_consumption = $consumption;
                    } else {
                        $gasFlowMeter->total_consumption = 0;
                    }
                } else {
                    $gasFlowMeter->total_consumption = 0;
                }
                $gasFlowMeter->save();
                if ($gasFlowMeter) {
                    return json_encode(['status' => 'success', 'msg' => 'Gas Meter Data Add Successfully']);
                } else {
                    return json_encode(['status' => 'error', 'msg' => 'Something Went Wrong']);
                }
            } else if ($request->meter_type == "Energy Meter" && !empty($request->voltage)) {
                // dd('energy');
                $previousConsumption = EnergyFlowMeter::where('meter_id', $request->meter_id)->where('user_id', $user->id)->latest()->first();
                $energyMeter = new EnergyFlowMeter();
                $energyMeter->meter_type = $request->meter_type;
                $energyMeter->meter_id = $request->meter_id;
                $energyMeter->total = $request->energy;
                $energyMeter->flow = $request->power;
                $energyMeter->current = $request->current;
                $energyMeter->voltage = $request->voltage;
                $energyMeter->total_unit = $request->energy_unit;
                $energyMeter->flow_unit = $request->power_unit;
                $energyMeter->voltage_unit = $request->voltage_unit;
                $energyMeter->current_unit = $request->current_unit;
                $energyMeter->status = $request->status;
                $energyMeter->user_id = $user->id;
                if (!empty($previousConsumption)) {
                    $consumption = floatval($request->energy) - floatval($previousConsumption->total);
                    if ($consumption > 0) {
                        $energyMeter->total_consumption = $consumption;
                    } else {
                        $energyMeter->total_consumption = 0;
                    }
                } else {
                    $energyMeter->total_consumption = 0;
                }
                $energyMeter->save();
                if ($energyMeter) {
                    return json_encode(['status' => 'success', 'msg' => 'Energy Meter Data Add Successfully']);
                } else {
                    return json_encode(['status' => 'error', 'msg' => 'Something Went Wrong']);
                }
            } elseif ($request->meter_type == "Water Flow Meter" && !empty($request->total)) {
                // dd('water');
                $previousConsumption = WaterFlowMeter::where('meter_id', $request->meter_id)->where('user_id', $user->id)->latest()->first();
                // dd('ok');
                $waterFlowMeter = new WaterFlowMeter();
                $waterFlowMeter->meter_type = $request->meter_type;
                $waterFlowMeter->meter_id = $request->meter_id;
                $waterFlowMeter->flow = $request->flow;
                $waterFlowMeter->total = $request->total;
                $waterFlowMeter->flow_unit = $request->flow_unit;
                $waterFlowMeter->total_unit = $request->total_unit;
                $waterFlowMeter->user_id = $user->id;
                if (!empty($previousConsumption)) {
                    $consumption = floatval($request->total) - floatval($previousConsumption->total);
                    if ($consumption > 0) {
                        $waterFlowMeter->total_consumption = $consumption;
                    } else {
                        $waterFlowMeter->total_consumption = 0;
                    }
                } else {
                    $waterFlowMeter->total_consumption = 0;
                }
                $waterFlowMeter->save();
                if ($waterFlowMeter) {
                    return json_encode(['status' => 'success', 'msg' => 'Water Meter Data Add Successfully']);
                } else {
                    return json_encode(['status' => 'error', 'msg' => 'Something Went Wrong']);
                }
            } elseif ($request->meter_type == "Production Meter" && !empty($request->total)) {
                // dd("prod");
                $previousConsumption = ProductionMeter::where('meter_id', $request->meter_id)->where('user_id', $user->id)->latest()->first();
                $produtionMeter = new ProductionMeter();
                $produtionMeter->meter_type = $request->meter_type;
                $produtionMeter->meter_id = $request->meter_id;
                $produtionMeter->flow = $request->flow;
                $produtionMeter->total = $request->total;
                $produtionMeter->flow_unit = $request->flow_unit;
                $produtionMeter->total_unit = $request->total_unit;
                $produtionMeter->user_id = $user->id;
                if (!empty($previousConsumption)) {
                    $consumption = floatval($request->total) - floatval($previousConsumption->total);
                    if ($consumption > 0) {
                        $produtionMeter->total_consumption = $consumption;
                    } else {
                        $produtionMeter->total_consumption = 0;
                    }
                } else {
                    $produtionMeter->total_consumption = 0;
                }
                $produtionMeter->save();
                if ($produtionMeter) {
                    return json_encode(['status' => 'success', 'msg' => 'Production Meter Data Add Successfully']);
                } else {
                    return json_encode(['status' => 'error', 'msg' => 'Something Went Wrong']);
                }
            } else if ($request->status) {
                // dd($request->status);
                // dd('status');
                // $machineId = Meter::where('meter_id', $request->meter_id)->first();
                // dd($machineId);
                $machineStatus = new MachineStatus();
                $machineStatus->meter_type = $request->meter_type;
                $machineStatus->meter_id = $request->meter_id;
                $machineStatus->user_id = $user->id;
                $machineStatus->status = $request->status;
                $machineStatus->machine_id = 0;
                $machineStatus->save();
                if ($machineStatus) {
                    return json_encode(['status' => 'success', 'msg' => 'Status Data Add Successfully']);
                } else {
                    return json_encode(['status' => 'error', 'msg' => 'Something Went Wrong']);
                }
            }
        } else {
            return json_encode(['status' => 'error', 'msg' => 'Incorrect Name']);
        }
    }

    public function export($meter)
    {
        $date = Carbon::now();
        $meters = DB::table('meters_view')->orderBy('updated_at', 'desc')->where('meter_id', $meter)->where('user_id', Auth::user()->id)->get();
        foreach ($meters as $data) {
            $excelArray[] = ['date' => date('d-m-Y g:ia', strtotime($data->updated_at)), 'flow' => round(str_replace(',', '', $data->flow)), 'total' => round(str_replace(',', '', $data->total_consumption))];
        }

        return Excel::download(new dataByMachine($excelArray, $date, $meter), $date . '.xlsx');
        // return Excel::download(new SteamFlowMeterExport($meter), $date . ' ' . $meter . '.xlsx');
    }

    public function exportPDF($meter)
    {
        $date = Carbon::now();


        $data = SteamFlowMeter::where('meter_id', $meter)->where('user_id', Auth::user()->id)->get();

        if ($data->isEmpty()) {
            $data = GasFlowMeter::where('meter_id', $meter)->where('user_id', Auth::user()->id)->get();
        }

        $pdf = PDF::loadView('admin.layouts.pdfgenerate', compact('data'));
        return $pdf->download($date . ' ' . $meter . '.pdf');
        dd($data);
    }

    //-------------Priting excel data of selected date-----------//
    public function exportRangeExcel($meterid, $from, $areaId)
    {
        $machine = Machine::with(['building'])->where('id', $areaId)->first();
        $date = Carbon::now();
        // $meter = strval ($meter);
        return Excel::download(new MultiExport($meterid, $from, $date, $areaId), $machine->building->building_area . '-' . $machine->machine_name . '-' . date('d-m-Y', strtotime($date)) . '.xlsx');
    }



    //----------------Printing pdf file of selected date------//
    public function exportRangePDF($meterid, $from, $areaId)
    {
        set_time_limit(300);
        if ($areaId != 0) {
            $machine = Machine::with(['building'])->where('id', $areaId)->first();
            if (Auth::user()->is_admin) {
                $user = User::find($machine->user_id);
                $logo = $user->logo;
                $companyName = $user->name;
            } else {
                $logo = Auth::user()->logo;
                $companyName = Auth::user()->name;
            }
            $meters = Meter::where('machine_id', $areaId)->where('user_id', Auth::user()->id)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->where('machine_id', $areaId)->get();

            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });

            $machineStatus = DB::table('meters_view')->whereIn('meter_id', $meterIds)->where('meter_type', 'Machine Status')->whereDate('created_at', $from)->where('machine_id', $areaId)->get();

            $machineStatus = $machineStatus->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });

            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->distinct()->get();

            $previousDay = date('d-m-Y g:i:sa', strtotime($from) + (24 * 60 * 60 - 1));
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [date('Y-m-d H:i:s', strtotime($from)), date('Y-m-d H:i:s', strtotime($previousDay))])->where('user_id', $machine->user_id)->where('machine_id', $areaId)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            $totalConsumption = [];
            foreach ($totalMeters as $key => $meterData) {
                $first = $meterData->first();
                $last = $meterData->last();
                // dd(str_replace(',', '', $last->total));
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }

            $date = Carbon::now();
            $pdf = PDF::loadView('admin.layouts.hourlyPdfGenerate', compact('meters', 'metersName', 'machine', 'from', 'date', 'logo', 'companyName', 'totalConsumption', 'machineStatus'));
            return $pdf->download($machine->building->building_area . '-' . $machine->machine_name . '-' . date('d-m-Y', strtotime($date)) . '.pdf');
        }

        $meters = DB::table('meters_view')->orderBy('updated_at', 'desc')->whereDate('created_at', $from)->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();

        $meters = $meters->groupBy(function ($data) {
            return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d g:ia');
        });

        $metersName = DB::table('meters_view')->select('meter_type', 'meter_id')->where('meter_id', $meterid)->whereDate('created_at', $from)->where('user_id', Auth::user()->id)->distinct()->get();



        // dd($meters);
        $date = Carbon::now();
        $pdf = PDF::loadView('company.partials.databycurrentdatepdf', compact('meters', 'metersName', 'date', 'meterid'));
        return $pdf->download($date . ' ' . $meterid . '.pdf');
    }


    //--------Total Data of same date search-------///

    public function exportSingleExcel($meterid, $from, $to, $areaId)
    {
        $machine = Machine::with(['building'])->where('id', $areaId)->first();
        $date = Carbon::now();
        return Excel::download(new SingleExport($meterid, $from, $to, $date, $areaId), $machine->building->building_area . '-' . $machine->machine_name . '-' . date('d-m-Y' . '-' . strtotime($date)) . '.xlsx');
    }


    //////////////---------------printing pdf report by date--------///////////

    public function exportSinglePDF($meterid, $from, $to, $areaId)
    {
        // pdf file of all meters of specific area
        $date = date('D-M-Y');
        if ($areaId != 0) {
            // dd('ok');

            $machine = Machine::with(['building'])->where('id', $areaId)->first();
            if (Auth::user()->is_admin) {
                $user = User::find($machine->user_id);
                $logo = $user->logo;
                $companyName = $user->name();
            } else {
                $logo = Auth::user()->logo;
                $companyName = Auth::user()->name;
            }
            $area = Building::find($machine->building_id);
            $meters = Meter::where('machine_id', $areaId)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }
            // dd($meterIds);
            if ($from == $to) {
                $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->where('machine_id', $areaId)->get();

                $meters = $meters->groupBy(function ($date) {
                    return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
                });

                $dailyRuningHours = [];
                foreach ($meters as $key => $meter) {

                    $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                    // dd($status->count());
                    if (!$status->isEmpty()) {
                        $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                    }
                }

                $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at', $from)->distinct()->get();

                $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereDate('created_at', $from)->whereIn('meter_id', $meterIds)->where('machine_id', $areaId)->get();

                $totalMeters = $totalMeters->groupBy(function ($data) {
                    return $data->meter_id;
                });

                $totalConsumption = [];
                foreach ($totalMeters as $meter) {
                    $first = $meter->first();
                    $last = $meter->last();
                    if ($first->meter_type != "Machine Status") {
                        $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                    }
                }


                $meterId = 0;
                // dd($metersName);

                $date = Carbon::now();

                $pdf = PDF::loadView('admin.layouts.datePdfGenerate', compact('meters', 'metersName', 'area', 'date', 'logo', 'companyName', 'totalConsumption', 'machine', 'dailyRuningHours'));
                return $pdf->download($machine->building->building_area . '-' . $machine->machine_name . '-' . $date . '.pdf');
            }

            $end = date('Y-m-d', strtotime('+1 day', strtotime($to)));

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [$from, $end])->where('machine_id', $areaId)->get();

            $meters = $meters->groupBy(function ($date) {
                return \Carbon\Carbon::parse($date->created_at)->format('Y-m-d');
            });

            $dailyRuningHours = [];
            foreach ($meters as $key => $meter) {

                $status = MachineStatus::whereDate('created_at', $key)->whereIn('meter_id', $meterIds)->where('status', 'ON')->get();

                // dd($status->count());
                if (!$status->isEmpty()) {
                    $dailyRuningHours[] = ['date' => $key, 'run_hours' => $status->count()];
                }
            }
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereBetween('created_at', [$from, $end])->whereIn('meter_id', $meterIds)->where('machine_id', $areaId)->get();

            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });

            $totalConsumption = [];
            foreach ($totalMeters as $meter) {
                $first = $meter->first();
                $last = $meter->last();
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }

            // dd($meters);
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [$from, $end])->distinct()->get();
            // dd($metersName);
            $date = Carbon::now();
            // dd($area);
            $pdf = PDF::loadView('admin.layouts.datePdfGenerate', compact('meters', 'metersName',  'date', 'logo', 'companyName', 'totalConsumption', 'machine', 'dailyRuningHours'));
            return $pdf->download($machine->building->building_area . '-' . $machine->machine_name . '-' . $date . '.pdf');
        }


        // with specific meter id
        if ($from == $to) {
            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereDate('created_at', $from)->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();

            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d');
            });
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id')->where('meter_id', $meterid)->whereDate('created_at', $from)->where('user_id', Auth::user()->id)->distinct()->get();
        } else {
            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereBetween('created_at', [$from, $to])->where('meter_id', $meterid)->where('user_id', Auth::user()->id)->get();

            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('Y-m-d');
            });
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id')->where('meter_id', $meterid)->whereBetween('created_at', [$from, $to])->where('user_id', Auth::user()->id)->distinct()->get();
        }
        // dd($meters);
        $date = Carbon::now();

        $pdf = PDF::loadView('company.partials.databydatesofmeterpdf', compact('meters', 'metersName', 'meterid', 'date'));
        return $pdf->download($date . ' ' . $meterid . '.pdf');
    }



    // -------Priting hourly excel report--------------///
    public function exportMultiGraphExcel($buidling_id)
    {
        $building = Building::find($buidling_id);

        $date = Carbon::now();
        // $meter = strval ($meter);
        return Excel::download(new MultiGraphExport($buidling_id), $date . ' ' . $building->buidling_area . '.xlsx');
    }

    public function exportMultiGraphPDF($buidling_id)
    {
        ini_set('max_execution_time', '-1');
        $building = Building::find($buidling_id);
        // dd($building);
        $meters = Meter::where('building_id', $buidling_id)->get();

        $meterIds = [];
        foreach ($meters as $meter) {
            $meterIds[] = $meter->meter_id;
        }


        $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->where('user_id', Auth::user()->id)->get();

        // dd($meters);

        $date = Carbon::now();

        $pdf = PDF::loadView('admin.layouts.multiGraphPDFGenerate', compact('meters'));
        return $pdf->download($date . ' ' . $building->building_area . '.pdf');
    }
}
