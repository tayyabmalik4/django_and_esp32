<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class dataByMachine implements FromView, ShouldAutoSize
{

    public function __construct(array $excelArray, string $date, string $meter)
    {
        $this->excelArray = $excelArray;
        $this->date = $date;
        $this->meter = $meter;
        // dd($this->excelArray);
    }
    public function view(): View
    {
        return view('admin.partials.databymeter', [
            'meters' =>  $this->excelArray,
            'meterName' => $this->meter,
            'currentDate' => $this->date,
            'report' => 'ENERGY & PRODUCTION COST ANALYSIS WITH REPORTING',
        ]);
    }
}
