<table>
    <thead>
        <tr>
            <th align="center"><img src="{{ public_path('admin/company/images/' . $logo) }}" alt="" width="300"
                    height="100" /></th>
            <th align="center" style="font-weight: bold">{{ $companyName }}</th>
            <th align="center" style="font-weight: bold">{{ date('d-m-Y', strtotime($currentDate)) }}</th>
            <th align="center" style="font-weight: bold">{{ strtoupper($reporttype) }}</th>
        </tr>

    </thead>
</table>

<table>
    <thead>
        <tr>
            <th colspan="3" align="center" style="font-weight: bold">{{ $report }}</th>
        </tr>
    </thead>
</table>



<table class="table text-center table-bordered">
    <thead id="tableHead">
        <tr id="tableRow">
            <th style="background-color: #0714a0;color:white" align="center">Date</th>
            <th style="background-color: #0714a0;color:white" align="center">Time</th>
            @if (!$metersName->isEmpty())
                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Steam Flow Meter')
                        <th style="background-color: #0714a0;color:white" align="center">{{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Gas Flow Meter')
                        <th style="background-color: #0714a0;color:white" align="center">{{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Energy Meter')
                        <th style="background-color: #0714a0;color:white" align="center">
                            {{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Water Flow Meter')
                        <th style="background-color: #0714a0;color:white" align="center">
                            {{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach

                @foreach ($metersName as $steamMeter)
                    @if ($steamMeter->meter_type == 'Production Meter')
                        <th style="background-color: #0714a0;color:white" align="center">
                            {{ $steamMeter->meter_type }}
                            <br>{{ $steamMeter->meter_id }} <br>{{ ' (' . $steamMeter->total_unit . ')' }}
                        </th>
                    @endif
                @endforeach
            @endif
        </tr>
    </thead>
    <tbody>
        @if (!$meters->isEmpty())
            @foreach ($meters as $key => $meter)
                <tr>
                    <td scope="row" align="center">{{ date('d-m-Y', strtotime($key)) }}
                    </td>
                    <td align="center">{{ date('ga', strtotime($key)) }}</td>

                    @foreach ($metersName as $flowName)
                        @if ($flowName->meter_type == 'Steam Flow Meter')
                            @php
                                $i = 0;
                            @endphp
                            @foreach ($meter as $flowMeter)
                                @if ($flowMeter->meter_type == 'Steam Flow Meter' && $flowMeter->meter_id == $flowName->meter_id)
                                    <td align="center">
                                        {{ $flowMeter->total_consumption }}
                                    </td>
                                    @php
                                        $i = $i + 1;
                                    @endphp
                                @endif
                            @endforeach
                            @if ($i == 0)
                                <td align="center">0</td>
                            @endif
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @if ($gasName->meter_type == 'Gas Flow Meter')
                            @php
                                $i = 0;
                            @endphp
                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Gas Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    <td align="center">
                                        {{ round($gasMeter->total_consumption) }}
                                    </td>
                                    @php
                                        $i = $i + 1;
                                    @endphp
                                @endif
                            @endforeach
                            @if ($i == 0)
                                <td align="center">0</td>
                            @endif
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @if ($gasName->meter_type == 'Energy Meter')
                            @php
                                $i = 0;
                            @endphp
                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Energy Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    <td align="center">
                                        {{ round($gasMeter->total_consumption) }}
                                    </td>
                                    @php
                                        $i = $i + 1;
                                    @endphp
                                @endif
                            @endforeach
                            @if ($i == 0)
                                <td align="center">0</td>
                            @endif
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @if ($gasName->meter_type == 'Water Flow Meter')
                            @php
                                $i = 0;
                            @endphp
                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Water Flow Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    <td align="center">
                                        {{ round($gasMeter->total_consumption) }}
                                    </td>
                                    @php
                                        $i = $i + 1;
                                    @endphp
                                @endif
                            @endforeach
                            @if ($i == 0)
                                <td align="center">0</td>
                            @endif
                        @endif
                    @endforeach

                    @foreach ($metersName as $gasName)
                        @if ($gasName->meter_type == 'Production Meter')
                            @php
                                $i = 0;
                            @endphp
                            @foreach ($meter as $gasMeter)
                                @if ($gasMeter->meter_type == 'Production Meter' && $gasMeter->meter_id == $gasName->meter_id)
                                    <td align="center">
                                        {{ round($gasMeter->total_consumption) }}
                                    </td>
                                    @php
                                        $i = $i + 1;
                                    @endphp
                                @endif
                            @endforeach
                            @if ($i == 0)
                                <td align="center">0</td>
                            @endif
                        @endif
                    @endforeach

                </tr>
            @endforeach
            <tr>
                <td colspan="2" align="center">Total</td>
                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Steam Flow Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Steam Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Gas Flow Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Gas Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Energy Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Energy Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Water Flow Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Water Flow Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach

                @foreach ($metersName as $name)
                    @if ($name->meter_type == 'Production Meter')
                        @foreach ($totalConsumption as $meter)
                            @if ($meter['meter_type'] == 'Production Meter' && $meter['meter_id'] == $name->meter_id)
                                <td align="center">{{ number_format($meter['total']) }}</td>
                            @endif
                        @endforeach
                    @endif
                @endforeach
            </tr>
        @endif
    </tbody>
</table>
