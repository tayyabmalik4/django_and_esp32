<?php

namespace App\Exports;

use App\Models\User;
use App\Models\Meter;

use App\Models\Machine;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class dataByCurrentDate implements FromView, ShouldAutoSize
{
    public function __construct(string $meterId, string $from, string $areaId, $date)
    {
        $this->meterId = $meterId;
        $this->from = $from;
        $this->areaId = $areaId;
        $this->currentDate = $date;
    }
    public function view(): View
    {
        // dd($this->from);
        if ($this->areaId != 0) {
            $machine = Machine::with(['building'])->where('id', $this->areaId)->first();
            if (Auth::user()->is_admin) {
                $user = User::find($machine->user_id);
                $logo = $user->logo;
                $companyName = $user->name;
            } else {
                $logo = Auth::user()->logo;
                $companyName = Auth::user()->name;
            }
            $building = Machine::find($this->areaId);
            $meters = Meter::where('machine_id', $this->areaId)->get();
            // dd($meters);
            $meterIds = [];
            foreach ($meters as $meter) {
                $meterIds[] = $meter->meter_id;
            }

            // dd($meterIds);

            $meters = DB::table('meters_view')->orderBy('created_at', 'desc')->whereIn('meter_id', $meterIds)->whereDate('created_at', $this->from)->where('machine_id', $this->areaId)->get();
            // dd($meters);
            $meters = $meters->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });
            $metersName = DB::table('meters_view')->select('meter_type', 'meter_id', 'total_unit')->whereIn('meter_id', $meterIds)->whereDate('created_at',  $this->from)->distinct()->get();

            $machineStatus = DB::table('meters_view')->where('meter_type', 'Machine Status')->whereIn('meter_id', $meterIds)->whereDate('created_at',  $this->from)->where('machine_id', $this->areaId)->get();

            $machineStatus = $machineStatus->groupBy(function ($data) {
                return \Carbon\Carbon::parse($data->created_at)->format('d-m-Y ga');
            });
            // dd($meters);

            $previousDay = date('d-m-Y g:i:sa', strtotime($this->from) + (24 * 60 * 60 - 1));
            $totalMeters = DB::table('meters_view')->select('meter_type', 'meter_id', 'total', 'created_at')->whereIn('meter_id', $meterIds)->whereBetween('created_at', [date('Y-m-d H:i:s', strtotime($this->from)), date('Y-m-d H:i:s', strtotime($previousDay))])->where('machine_id', $this->areaId)->get();



            $totalMeters = $totalMeters->groupBy(function ($data) {
                return $data->meter_id;
            });
            $totalConsumption = [];
            foreach ($totalMeters as $key => $meterData) {
                $first = $meterData->first();
                $last = $meterData->last();
                // dd(str_replace(',', '', $last->total));
                if ($first->meter_type != "Machine Status") {
                    $totalConsumption[] = ['meter_type' => $first->meter_type, 'meter_id' => $first->meter_id, 'total' => floatval(str_replace(',', '', $last->total)) - floatval(str_replace(',', '', $first->total))];
                }
            }
        }
        $count = $totalMeters->count();
        return view('admin.partials.databycurrentdate', [
            'meters' => $meters,
            'metersName' => $metersName,
            'logo' => $logo,
            'currentDate' => $this->currentDate,
            'companyName' => $companyName,
            'totalConsumption' => $totalConsumption,
            'reporttype' => 'Hourly Report',
            'area' => $machine->machine_name,
            'machineStatus' => $machineStatus,
            'count' => $count + 2,
            'report' => "MRF-9000 Metering Reporting System",
        ]);
    }
}
